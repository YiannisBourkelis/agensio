# Configuration keys

Generated from the table in `src/control/reference.cpp` by `agensio keys --markdown`; the
integration suite fails when this file and the binary disagree. The MCP tool
`config_reference` and `agensio ctl reference` serve the same table, with the running values.
The loader reads its keys from it too: a key this table does not give its table is refused
when the configuration loads, with the nearest key named (`unknown key 'refsue' (did you
mean 'refuse'?)`), so a misspelt key never passes unnoticed (0.1.0-alpha.61).
*applies*: whether a change takes effect on `agensio reload` or needs
`systemctl restart agensio`. *via*: who changes it: **file** = root, in the main configuration
file; **site file** = a site file under `sites.d` (a hand-written one, or a managed one after
its marker is removed); **site-create** = a field of `site-create` / `site-update`;
**settings** = `site-update --set`, within `[control] site_limits`. *doc* points at the
section of `docs/configuration.md` that explains the key.

## `[server]`

| key | type | default | meaning | applies | via | doc |
|---|---|---|---|---|---|---|
| `workers` | int | 0: one per CPU the process may run on | Worker threads; each owns an event loop and, on Linux, its own accepting socket (SO_REUSEPORT). 0 counts the CPUs of the affinity mask, so a container's cpuset or a taskset gives its own count. Fewer workers than cores leave room for PHP and the database on the same machine; one worker already serves hundreds of thousands of requests a second on static files. | restart | file | 1 |
| `idle_timeout` | seconds | 15 | How long a keep-alive connection may sit idle before the server closes it; for HTTP/2 idle means no frame completed and nothing written, and a write the client does not take closes the connection after four of them, and over HTTP/3 it is also the longest a handshake may take. | reload | file | 1 |
| `max_connections` | int | 0 = (open-file limit - 2048) / workers, at least 128 | Connections one worker holds at most, TCP and QUIC together: above it a plain listener answers 503 with Retry-After and closes, a TLS listener closes before any handshake work, a new HTTP/3 connection gets QUIC's CONNECTION_REFUSED before any handshake work; server_status shows the ceiling and the refusals, health reports refusals. The descriptor budget's guard, not a per-address limit: those belong to the firewall and fail2ban (docs/configuration.md 18). | reload | file | 18 |
| `max_requests_per_connection` | int | 1000 | Requests served on one connection before the server answers Connection: close (0 = unlimited). | reload | file | 1 |
| `max_header_size` | size | 16KB | The request head (request line and headers) may not exceed this: 431 above it. | reload | file | 1 |
| `max_body_size` | size | 1MB | The request-body limit every site takes unless it sets its own (413 above it); it also drives the generated php-fpm pools' upload sizes. Per site: the site's max_body_size, settable through the control plane. | reload | file | 7 |
| `body_timeout` | seconds | 60 | Longest wait between two reads of a request body before the request fails. | reload | file | 1 |
| `reuse_port` | enum: auto \| on \| off | auto | Whether every worker gets its own accepting socket (SO_REUSEPORT; Linux) or one worker accepts for all. auto picks the platform's best. | restart | file | 1 |
| `tcp_nodelay` | bool | true | TCP_NODELAY on client sockets (no Nagle delay on small writes). | restart | file | 1 |
| `sendfile` | bool | true | Zero-copy sendfile() for files on plain sockets; off makes the server copy through user space (useful only when a filesystem misbehaves with sendfile). | restart | file | 1 |
| `sendfile_max_chunk` | size | 1MB | Bytes per sendfile() call, so one huge file cannot hold a worker. | restart | file | 1 |
## `[[site.location]]`

| key | type | default | meaning | applies | via | doc |
|---|---|---|---|---|---|---|
| `httparena` | table { dataset } | { dataset = "/data/dataset.json" } | With handler = "httparena" (builds with -DAGENSIO_HTTPARENA=ON only): the HttpArena benchmark endpoints answered in-process from this dataset. | reload | site file | 6 |
## `httparena = {}`

| key | type | default | meaning | applies | via | doc |
|---|---|---|---|---|---|---|
| `dataset` | path | /data/dataset.json | The arena's dataset (a JSON array of items) the /json/{count} endpoint serializes; read at load. | reload | site file | 6 |
## `[[site]]`

| key | type | default | meaning | applies | via | doc |
|---|---|---|---|---|---|---|
| `protocols` | list of "h2", "h1", "h2c", "h3" | the [server] list | This site's listeners' protocols when they differ from the server's (a TLS port kept at HTTP/1.1 next to one offering h2, or h3 on one site's port); sites sharing an address must agree; "h3" needs a TLS site. | reload | site file | 16 |
## `[server]`

| key | type | default | meaning | applies | via | doc |
|---|---|---|---|---|---|---|
| `protocols` | list of "h2", "h1", "h2c", "h3" | ["h2", "h1"] | What TLS listeners offer through ALPN, in order of preference ("http/1.1" is accepted for "h1"); "h2c" in the list also accepts prior-knowledge HTTP/2 on plain listeners (benchmarks and backends; browsers never use it); "h3" opens HTTP/3 over QUIC on every TLS listener's port number (UDP; needs a build with OpenSSL 3.5.1 on Linux; every worker has its own socket with reuse_port; a reload that adds h3 on a privileged port, which the server can no longer bind once it dropped root, applies the rest and serves that port without h3 until a restart; one whose UDP port another process holds waits for a reload once the port is free, never a restart, since a start that cannot bind serves no site). ["h1"] alone switches HTTP/2 off, for instance during an incident. "hq-interop" exists only in a build made with -DAGENSIO_INTEROP=ON, for the QUIC interop runner (bench/quic-interop/). | reload | file | 16 |
## `http2 = {}`

| key | type | default | meaning | applies | via | doc |
|---|---|---|---|---|---|---|
| `max_concurrent_streams` | int | 128 | Streams a client may have open at once on one HTTP/2 connection (SETTINGS_MAX_CONCURRENT_STREAMS); more are refused. Every other HTTP/2 limit derives from max_header_size, max_requests_per_connection, idle_timeout, body_timeout and the body limits. | reload | file | 16 |
## `http3 = {}`

| key | type | default | meaning | applies | via | doc |
|---|---|---|---|---|---|---|
| `retry` | "auto" \| "always" \| "never" | "auto" | Whether a new HTTP/3 client must prove its address with a Retry round trip before it gets a connection (RFC 9000 8.1.2; the token is bound to the address and valid ten seconds). "auto" sends Retry once a worker has 512 handshakes in progress and drops further Initials at 1024; "always" is for a host under a handshake flood; "never" for a benchmark that must not pay the round trip. Everything else HTTP/3 derives from the HTTP/2 and connection limits. | reload | file | 17 |
| `alt_svc` | bool | true | Whether every HTTP/1 and HTTP/2 answer of a TLS listener that also speaks h3 carries alt-svc (h3=":port"; ma=86400), which is how browsers learn to switch to HTTP/3 on their next connection; off, clients that know the port (curl --http3-only, h2load) still connect over QUIC. | reload | file | 17 |
## `[server]`

| key | type | default | meaning | applies | via | doc |
|---|---|---|---|---|---|---|
| `server_header` | string | agensio | The Server response header; "" sends none. | reload | file | 1 |
| `trusted_proxies` | list of addresses, ranges or @sets | [] (headers ignored) | Proxies or load balancers in front of agensio whose X-Forwarded-For and X-Forwarded-Proto are believed (a site narrows the list with its own trusted_proxies; the [addresses] sets are accepted, @cdn): the client address in logs and REMOTE_ADDR, and the scheme for PHP (HTTPS, REQUEST_SCHEME), come from them. Several X-Forwarded-For lines are one list read from the end of the last line (the rightmost hop not on this list is the client); an IPv4 client of a [::] listener is recorded as IPv4; zone ids are refused. The fail2ban jails agensio renders never ban them (ignoreip). | reload | file | 10 |
| `user` | string | "" (stay the starting account) | Start as root, bind the ports and open the logs, then run as this account. Required for hosting with per-site users and for the provisioning helper. | restart | file | 11 |
| `group` | string | the user's primary group | The group the server runs as; per-site sockets and directories grant it access. | restart | file | 11 |
| `php_version` | string (major.minor) | the newest installed | The PHP version of every site that names none (php = { version }). Without it such sites follow the newest PHP installed, so installing a newer one moves them at the next reload; health's php_default_unpinned says so. | reload + agensio pools | file | 7b |
| `pools_run` | path | /run/php (Linux) | Where the generated pools listen (agensio-<user>-<8 hex of the domain>-<version>.sock). | reload | file | 11 |
| `state_dir` | path | /var/lib/agensio | Per-site PHP state (<user>/php/<domain>/tmp and sessions), the ACME storage, the uploads store, and .server/served: the record of the site files served, which a start ranks conflicts by. | reload | file | 11 |
| `strict_users` | bool | false | Every site must name a user; a site without one is a configuration error, except one that only redirects. For hosts where isolation is mandatory. | reload | file | 11 |
| `pid_file` | path | /run/agensio.pid (Linux) | Written at start; agensio reload signals it. "" disables it. | restart | file | 12b |
## `[server] acme`

| key | type | default | meaning | applies | via | doc |
|---|---|---|---|---|---|---|
| `email` | string | (none) | The ACME account contact; the CA sends expiry warnings there. Setting acme = { email } enables automatic certificates for sites with tls = "auto". | reload | file | 14 |
| `directory` | string | https://acme-v02.api.letsencrypt.org/directory | The ACME v2 directory URL: Let's Encrypt by default, any RFC 8555 CA. | reload | file | 14 |
| `ca` | path | "" (system store) | A PEM bundle to verify the CA's own TLS with (test beds, private CAs). | reload | file | 14 |
| `storage` | path | <state_dir>/acme | Where the account key and every site's key.pem and fullchain.pem live. | reload | file | 14 |
## `top level`

| key | type | default | meaning | applies | via | doc |
|---|---|---|---|---|---|---|
| `include` | list of globs | [] | Further configuration files, relative to this one: include = ["sites.d/*.toml"] is what site-create needs. | reload | file | 15 |
| `mime_types` | table: ending or path = type \| { type, encoding } | {} (the built-in table alone) | Root's Content-Type for the files every site serves, over the built-in table (nginx's mime.types): mime_types = { "sh" = "text/plain; charset=utf-8", "js.gzip" = { type = "text/javascript; charset=utf-8", encoding = "gzip" } }, by ending (any case, the longest of a file's name first; quote one with a dot) or by exact path; a site's own mime_types decide over it. A type browsers run scripts in (HTML, XML, SVG, JavaScript) for an ending that has none built in is noted (mime_type_scriptable). An application's answers keep their own type. At most 256. | reload | file | 6c |
| `php` | table: runtimes | {} (the versions discovered) | Root's table for the PHP versions agensio gives pools to: [php.runtimes."X.Y"] for one its discovery of the distributions' layouts does not find (Debian and Ubuntu /etc/php/X.Y, Remi, Alpine, Homebrew). php_versions lists what is installed. | reload | file | 7b |
## `[php]`

| key | type | default | meaning | applies | via | doc |
|---|---|---|---|---|---|---|
| `runtimes` | table: version = { fpm, conf, pools, unit, cli } | {} | A PHP version by its major.minor, quoted ([php.runtimes."8.5"]), with its php-fpm's files: a build under /opt, a second instance; it replaces a discovered version of the same number. | reload | file | 7b |
## `[php.runtimes.VERSION]`

| key | type | default | meaning | applies | via | doc |
|---|---|---|---|---|---|---|
| `fpm` | absolute path | (required) | The version's FPM binary (php-fpm -v, -m, -i and, as root, -tt are run on it). | reload | file | 7b |
| `conf` | absolute path | (required) | Its php-fpm.conf (process_control_timeout is read from it). | reload | file | 7b |
| `pools` | absolute path | (required) | The directory its php-fpm.conf includes pool files from. | reload | file | 7b |
| `unit` | systemd unit name | none | Its service, for its state and its reload (php8.5-fpm); none for one systemd does not start. | reload | file | 7b |
| `cli` | absolute path | none | Its command-line binary, for site tasks. | reload | file | 7b |
## `top level`

| key | type | default | meaning | applies | via | doc |
|---|---|---|---|---|---|---|
| `response_compression` | table: enabled, compress_signed_in, compress_event_streams, offload, codings, levels, min_size, extra_types | {} (the defaults below) | Every site's response compression defaults and the encoders' tuning (docs/design-compression.md 3): whether sites compress (enabled, false when absent, so no CPU is spent unless asked), the signed-in guard, the codings offered and their order, the levels, the minimum size and media types beyond the built-in list. A site's own response_compression overrides the fields it names. Every field applies at a reload. | reload | file | 20 |
| `addresses` | table of address lists | {} | Named address sets: [addresses] office = ["203.0.113.7", "2001:db8:5::/64"], named "@office" in the sites' access rules, so one edit reaches every site that names it. Addresses and ranges only, at most 64 a set. | reload | file | 19 |
## `[cache]`

| key | type | default | meaning | applies | via | doc |
|---|---|---|---|---|---|---|
| `max_file_size` | size | 4MB | Files up to this size are held in memory; larger ones keep an open descriptor and stream. | restart | file | 1 |
| `max_size` | size | 256MB | Total bytes of file content the cache may hold before it evicts. | restart | file | 1 |
| `evict_fraction` | float | 0.2 | How much of the cache an eviction pass frees. | restart | file | 1 |
| `revalidate_interval` | seconds | 1 | A cached file is stat()ed at most this often; a change on disk shows within this interval. | restart | file | 1 |
| `stream_chunk_size` | size | 64KB | Read size when a large file is streamed without sendfile (TLS). | restart | file | 1 |
| `sendfile_min_size` | size | 48KB | Cached files at least this large are sent with sendfile on plain sockets (0 = never); below it the memory copy is cheaper. | restart | file | 1 |
| `max_open_files` | int | 1024 | How many streamed files may keep an open descriptor in the cache (0 = none). | restart | file | 1 |
| `precompressed` | bool | true | Serve name.br or name.gz beside a cached file to a client whose Accept-Encoding takes it (Content-Encoding, Vary), cached with the file and revalidated with it; a twin older than the file is ignored. | restart | file | 1 |
## `[log]`

| key | type | default | meaning | applies | via | doc |
|---|---|---|---|---|---|---|
| `access` | path or "off" | logs/access.log next to the configuration | The access log every site uses unless it sets access_log, and the log of a request no site took (421 on a listener without a catch-all); "off" logs nothing. | reload | file | 8 |
| `format` | enum: vhost_combined \| combined \| json | vhost_combined | The access logs' line. vhost_combined: Apache's, the combined line with the requested host and the listener's port in front (host:port), so a file several sites share, and the 421 lines of a scan by bare address, say which name was asked (GoAccess reads it as VCOMBINED); combined: the classic Apache/nginx line, for a pipeline that expects it; json: one object per line with host and the upstream outcome. The shipped fail2ban filters read both combined forms, not JSON. | reload | file | 8 |
| `error` | path or "stderr" | stderr | Where the error log goes. | reload | file | 8 |
| `level` | enum: error \| warn \| info | warn | Error-log verbosity; info logs reloads, certificate work, the helper's start. | reload | file | 8 |
## `[control]`

| key | type | default | meaning | applies | via | doc |
|---|---|---|---|---|---|---|
| `socket` | path | /run/agensio/control.sock | The unix socket of the control API; its presence enables the control plane (agensio ctl, agensio mcp). Never a TCP port. | restart | file | 15 |
| `admins` | string (group) | "" | Members of this group are admins (create and change sites, install, copy). root and the server's user always are. | reload | file | 15 |
| `operators` | string (group) | "" | Members may reload, reopen logs, renew certificates, upload archives. | reload | file | 15 |
| `viewers` | string (group) | "" | Members may read: status, sites, logs, health, presets, settings, this reference. | reload | file | 15 |
| `audit` | path | audit.log next to the error log | One line per mutating command or refusal: time, uid, gid, role, command, outcome. | reload | file | 15 |
| `sites_root` | path | /var/www | Where site-create lays out sites and the helper may create directories; installs and copies stay below it. | reload | file | 15 |
| `provision` | bool | true | Fork the root provisioning helper at start (accounts, directories, logs, pools, install, copy, tasks on request), and beside it its reader, which answers the reads (environment files, services, host protection, the trash, PHP versions) and checks approval codes apart from tasks. false hands root work back as commands. | restart | file | 15 |
| `install` | bool | true | site-install may download archives from https URLs. false keeps only uploads. | reload | file | 15 |
| `install_private` | bool | false | Let site-install fetch from loopback, private and link-local addresses (internal mirrors, test beds). | reload | file | 15 |
| `install_ca` | path | "" (system store) | A PEM bundle site-install trusts instead of the system store. | reload | file | 15 |
| `upload_max` | size | 512MB | The largest archive agensio ctl upload may store. | reload | file | 15 |
| `site_limits` | table | { max_body_size = "512MB", memory_limit = "512M", max_execution_time = 300, max_input_time = 300, children = 32, max_requests = 1000000 } | The ceilings a site's settings may be raised to through the control plane; root moves them here. | reload | file | 15 |
| `runtimes` | table { ruby, node, php, python3 } of directories | { ruby = "/usr/bin", node = "/usr/bin", php = "/usr/bin", python3 = "/usr/bin" } | Where site tasks find their interpreters (ruby, gem and bundle for app = "rails"). The program, the file it resolves to and every directory above both must be root's and writable by root alone, outside sites_root, or the task is refused: a site never supplies its own interpreter. Point it at a root-owned installation under /opt when the distribution's is too old or an application pins another version (a Gemfile with ruby file: ".ruby-version"); docs/configuration.md 15 shows the build. A reload applies it. | reload | file | 15 |
| `task_limits` | table { timeout, processes } | { timeout = 1200, processes = 512 } | The bounds of every site task; the two keys are below. | reload | file | 15 |
| `trash_keep` | days | 60 | How long a site deleted with its files (site-delete --files) stays in <sites_root>/.trash before the hourly expiry removes it; 0 keeps entries until trash-delete. The account is never removed. | reload | file | 15 |
| `file_history` | table { versions, days } | { versions = 5, days = 30 } | What a change to a site's files through the control plane (site_file_write, site_file_edit, site_path_move, site_path_delete, site_file_restore) replaced or removed, kept in <sites_root>/.history (root's alone, never served) for an undo: site_file_history lists a path's versions, site_file_restore puts one back. A replaced file is hard-linked there, a removed path renamed there whole, so nothing is copied. The two keys are below. | reload | file | 15 |
## `file_history = {}`

| key | type | default | meaning | applies | via | doc |
|---|---|---|---|---|---|---|
| `versions` | int | 5 | Versions of one path kept, the oldest going first; 0 keeps nothing, so a delete removes for good (at most 10,000 entries a call). 0 to 100. | reload | file | 15 |
| `days` | days | 30 | How long a version stays before the hourly expiry removes it. 1 to 3650. | reload | file | 15 |
## `[control]`

| key | type | default | meaning | applies | via | doc |
|---|---|---|---|---|---|---|
| `host_protection` | enum: check \| external \| off | check | Whether health looks for the host's protection when a listener is public: per-address limits on the web ports in the kernel's firewall and a fail2ban jail over the access logs (agensio ctl protection and the MCP tool protection_show render both for this host and say what is in place). check warns when either is missing; external says a panel or the administrator manages them, so the findings are informational; off skips the probe. | reload | file | 18 |
| `task_downloads` | bool | true | Site tasks that download packages (gem_install_rails, rails_new, bundle_install, pip_install, pip_install_requirements, npm_ci, npm_run) may run; false refuses them, for a host that installs archives carrying their dependencies (vendor/bundle, node_modules) instead. Other tasks are not limited: what they run may use the network. | reload | file | 15 |
## `task_limits = {}`

| key | type | default | meaning | applies | via | doc |
|---|---|---|---|---|---|---|
| `timeout` | seconds | 1200 | Wall-clock limit of one site task: SIGTERM to its process group, SIGKILL ten seconds later; a task's own limit is capped by it. 5 to 86400. | reload | file | 15 |
| `processes` | int | 512 | RLIMIT_NPROC of the site's account while a task runs, so a runaway build stops there. 16 to 65536. | reload | file | 15 |
## `[[site]]`

| key | type | default | meaning | applies | via | doc |
|---|---|---|---|---|---|---|
| `server_name` | list of host names | ["*"] | The names this site answers; "*" makes it the listener's catch-all. A name no site lists answers 421. | reload | site-create (domain, aliases) | 1b |
| `listen` | list of host:port | the server's listen_tls (a site with tls) or listen_plain | The addresses this site listens on when it has its own, replacing the server's whole (a specific address of a host with several, a loopback-only or odd-port site); one site per name per address. A site on 0.0.0.0:P beside sites on the server's [::]:P takes every IPv4 connection of the port (listen_family_split). An address below 1024 the server does not hold cannot be added by a reload once it dropped root: put it in [server] listen_tls or listen_plain and restart. | reload | site-create (listen_plain, listen_tls; omitted: the server's) | 1c |
## `[server]`

| key | type | default | meaning | applies | via | doc |
|---|---|---|---|---|---|---|
| `listen_tls` | list of host:port | ["[::]:443"] (0.0.0.0 without IPv6) | The addresses a site with tls listens on when its file names no listen; its plain redirect listeners are listen_plain. Bound at start as root, before the privilege drop, so no reload has to bind a privileged port; the key in the file opens the addresses at start whether or not a site uses them yet, so a site created later attaches by a reload. [::] takes both families where the host allows it (health ipv6_unavailable says when it falls back to 0.0.0.0). | restart | file | 1c |
| `listen_plain` | list of host:port | ["[::]:80"] (0.0.0.0 without IPv6) | The addresses a site without tls listens on when its file names no listen, and the plain redirect addresses of a site with tls on the server's listen_tls. Bound at start as root like listen_tls. | restart | file | 1c |
## `[[site]]`

| key | type | default | meaning | applies | via | doc |
|---|---|---|---|---|---|---|
| `root` | path | (required unless app = proxy) | The document root, or for a preset the project directory (Laravel's public/, Drupal's web/ are served; for app = rails the application's directory, where site tasks run and nothing is served). | reload | site-create (root) | 1 |
| `app` | enum: static \| php \| laravel \| drupal \| wordpress \| grav \| proxy \| rails \| redmine \| django \| wagtail \| node | static | The preset: routing, which .php runs, what is refused; presets_list explains each. | reload | site-create (app) | 2 |
| `entry` | string | (none; the unit needs it) | app = node: the file node runs, relative to the project directory (server/server.js); .js, .mjs or .cjs, a plain path. The rendered unit starts it; site_install's facts guess it from package.json. | reload | site-create (entry) | 4f |
| `env_file` | string | app = laravel: .env; app = php: (none) | A Laravel application's .env, relative to the project (shared/.env beside the releases): what site_env lists and site_env_set writes, root's with the site's group, 0640, so the application reads it and cannot change it, and a secret never passes through an agent. Outside the served directory (on app = php, a served_dir is needed); a credential of the file tools. After a change, the optimize task, since a cached configuration does not read .env again. | reload | site-create (env_file) | 3 |
| `served_dir` | string | (none: the root itself) | app = php: the directory of the project that is served (public, web/public), relative to root, which stays the project directory: PHP's open_basedir and site_install's target. A plain relative path inside the project; it may be missing until site_install fills the project (health: served_dir_missing). | reload | site-create (served_dir) | 2 |
| `project` | string | (none; required for django and wagtail) | app = django or wagtail: the project's Python package (NAME/settings, NAME/wsgi.py), which the tasks and the rendered unit load; lower-case letters, digits and _. | reload | site-create (project) | 4e |
| `mime_types` | table: ending or path = type \| { type, encoding } | {} (root's [mime_types], then the built-in table) | The Content-Type of the files this site serves, by ending (sh, js.gzip) or exact path (/.well-known/apple-app-site-association), over root's [mime_types] and the built-in table; encoding (gzip or br) for a file stored compressed, never on an archive's ending. A type browsers run scripts in (HTML, XML, SVG, JavaScript) only for an ending or path whose built-in type is one already. An application's answers keep their own type. At most 64. | reload | site-create (mime_types) | 6c |
| `public_archives` | list of paths as served | none | Archives and database dumps the site publishes for download on purpose (a dataset, a sample database, a release archive), as served from its root: /downloads/world.sql.gz, or a directory ending in / for all below it (/datasets/). Health's archives_in_root counts them as public instead of naming them; it serves, refuses and moves nothing. A file kept in the tree that nobody downloads goes in refuse instead, which answers 404 for it and silences the finding. Exact paths and directories only: no wildcards (* ? [), never / alone, at most 64; a directory needs its trailing / (the finding names one written without it). | reload | site-create (public_archives) | 1 |
| `login_paths` | list of URL paths | (the preset's own) | Where the application's login form or authenticating API is posted to (/login, /api/token), on top of the preset's known paths (wordpress /wp-login.php and /xmlrpc.php, drupal /user/login, laravel /login and /cp/auth/login, grav /admin, redmine /login, django and wagtail /admin/login/). Nothing is served or refused by it: the fail2ban jail agensio ctl protection renders counts attempts there (ten in ten minutes bans for an hour). A login routed through the query string is written with it, matched from the query's start: /?controller=AuthController&action=check (Kanboard), /?_task=login (Roundcube), /ucp.php?mode=login (phpBB). Plain paths, a query of letters, digits and ._~/=&+:-, at most 16. | reload | site-create (login_paths) | 18 |
| `index` | list | ["index.html"] (presets set their own) | Files tried for a directory request. | reload | site file | 1 |
| `try_files` | list | preset-dependent | What to try for a path: $uri, $uri/, a fallback such as /index.php?$query_string, or =404. | reload | site file | 6 |
| `user` | string | "" | The account the site's PHP runs as, in its own pool; also who owns its files. What makes a shared host safe. | reload (agensio pools / the helper writes the pool) | site-create (user, no_user) | 11 |
| `group` | string | the user's primary group | The site's group. | reload | site-create (group) | 11 |
| `access_log` | path | [log] access | This site's own access log, or "off"; a site with a user gets <log directory>/sites/<domain>.log, readable by it. A site file the server's account can write (a managed one) may name only sites/<name>.log there; a file of the main configuration's owner any path (8c). | reload | site file | 8c |
| `access_log_exclude_paths` | list of URL paths | none | Requests under these paths write no line in the site's access log, and the error log's lines about them name no client address: for a promise such as a privacy notice's ("the server keeps no record of these requests"). Prefixes from /: /healthz covers itself and whole segments below it (never /healthzx), /api/notices/ everything below it, in the capitalisation written, on every method; matched on the cleaned path, so /api/notices/../../wp-login.php is still logged. Never / (access_log = "off" for that) and never a path the fail2ban jails count: a login path (the preset's and the site's own), a path a [[site.auth]] password protects or a [[site.access]] rule restricts. At most 16. On a managed site a change that adds or widens one waits for approval. | reload | site-create (access_log_exclude_paths) | 8b |
| `access_log_keep_days` | days, 1 to 14 | none (logrotate keeps 14) | No rotated file of the site's access log that holds a line older than this many days is kept: agensio deletes them hourly, through the root helper when started as root. A ceiling, never more than logrotate keeps (14 as shipped); the current file is logrotate's, rotated daily. Needs the site's own access_log in sites/ of agensio's log directory (the [log] access file's), named *.log; a file another site writes too is refused. On a managed site a change that sets or lowers it waits for approval. | reload | site-create (access_log_keep_days) | 8b |
| `max_body_size` | size | [server] max_body_size | This site's request-body limit; drives the pool's upload_max_filesize and post_max_size. | reload (and a php-fpm reload for the pool) | settings | 7 |
| `tls` | "auto" or { cert, key } | (plain HTTP) | A certificate obtained and renewed automatically (needs [server] acme and port 80 reachable) or files you manage. | reload | site-create (https) | 14 |
| `hsts` | lifetime \| "application" \| "none" \| { max_age, subdomains } | (none sent, not decided) | Strict-Transport-Security on every answer the site gives over HTTPS (or that a trusted proxy marks https): pages, files, PHP, proxied applications, errors and redirects, replacing a value the application sends itself, so browsers see one. The value is the lifetime browsers commit to HTTPS for: seconds or a duration ("1w", "1y"; at most ten years, two on a managed site), 0 to make them forget it. "application": agensio sends none and the application's own field goes out unchanged, as with no line; "none": none on any answer, an application's own removed; either records the decision. true and false are refused (false did what "application" does). Set a lifetime once HTTPS works. A location's add_headers cannot send it. | reload | site-create (hsts) | 14 |
## `hsts = {}`

| key | type | default | meaning | applies | via | doc |
|---|---|---|---|---|---|---|
| `max_age` | seconds or a duration ("2y") | 31536000 (a year) | How long browsers keep the site HTTPS-only: seconds (63072000) or a number with s, m, h, d, w or y, at most ten years; 0 tells them to forget it (send it for as long as the old max_age before removing hsts). | reload | site file | 14 |
| `subdomains` | bool | false | includeSubDomains: every subdomain of the site's names becomes HTTPS-only in browsers that saw it, including ones on other servers; a subdomain without TLS becomes unreachable. | reload | site file | 14 |
## `[[site]]`

| key | type | default | meaning | applies | via | doc |
|---|---|---|---|---|---|---|
| `http` | "redirect" \| "serve" \| "off" \| { listen, mode } | "redirect" for a TLS site on port 443, "off" for one elsewhere, "serve" without TLS | What a request over plain HTTP gets. A TLS site on port 443 also listens on port 80 at the same addresses and answers there with a 308 to the same name and path over HTTPS (kept a day); the ACME challenge and /.well-known/pki-validation/ are served from the site first. "serve" serves plain HTTP too (refused with hsts), "off" opens no plain listener. Without TLS, "redirect" is for a proxy in front that holds the certificate: requests a trusted proxy does not mark https are redirected. | reload (a new privileged port needs a restart) | site-create (redirect_http) | 14 |
## `http = {}`

| key | type | default | meaning | applies | via | doc |
|---|---|---|---|---|---|---|
| `listen` | list of host:port | (required in the table) | The plain addresses of a TLS site on another port than 443, or other than port 80 beside it; the redirect names the site's TLS port. | reload (a new privileged port needs a restart) | site-create (listen_plain) | 14 |
| `mode` | "redirect" \| "serve" | "redirect" | What the plain addresses of the table answer: the 308 to HTTPS, or the site itself. | reload | site-create (redirect_http) | 14 |
## `[[site]]`

| key | type | default | meaning | applies | via | doc |
|---|---|---|---|---|---|---|
| `canonical` | string, one of server_name | (none: every name serves) | The one of the site's names its other listed names redirect to: a 308, path and query kept, a day; over plain HTTP scheme and host in one hop (with hsts, the name's own HTTPS first, so it learns HSTS too). Certificate validation over plain HTTP is answered on every name; a name the site does not list is not redirected. Set the application's own address to it. | reload | site-create (canonical) | 14 |
| `default` | bool | false | This site is its listener's catch-all (like server_name = ["*"]). | reload | site file | 1b |
| `hidden_files` | bool | false | Serve dot-files (.env, .git) instead of answering 404; /.well-known/ at the root is served either way. | reload | site file | 1 |
| `refuse` | list of path patterns | (none) | Paths the site answers 404 whichever location would serve them, gitignore-style: /vendor/ from the root (the directory and everything below), composer.json or *.yaml a name in any directory, '*' any run of characters within one segment (/ext/*/Resources/Private/), '**' any number of directories (/fileadmin/templates/**/*.ts). No regex and no order: a match is a 404, so no location can step around it. Case and trailing dots are ignored; checked before the locations, on every internal redirect and on a directory's index file. A pattern that would refuse the site's index, a try_files fallback or an exact location that runs something is an error. At most 64 patterns of 200 characters. For an application without a preset, its official server configuration's denials go here (rules.refuse on a managed site). | reload | site file, site-create (rules.refuse) | 6b |
| `encoded_slashes` | enum: deny \| allow | deny | A path that spells a slash or a backslash as a percent escape (%2F, %5C): deny answers 404 on every location served from disk (Apache's AllowEncodedSlashes Off; /x%2F..%2Fwp-login.php never reaches the script), allow decodes and looks it up as before, for an application behind a front controller that encodes a slash inside a path segment and reads REQUEST_URI (Apache's NoDecode in effect). A proxy location passes the raw target to its origin either way, as nginx does. | reload | site-create (encoded_slashes) | 1 |
| `trusted_proxies` | list of addresses, ranges or @sets | (the server's list) | Which of [server] trusted_proxies speak for this site: from them X-Forwarded-For and X-Forwarded-Proto are believed for its requests; a request from another proxy of the server's list is the peer's own (its address, its scheme), so a CDN in front of one site cannot speak for another. Each entry must lie within the server's list, which only root widens; [] believes no proxy, for a site whose visitors connect directly. Takes the [addresses] sets (@cdn). | reload | site-create (trusted_proxies) | 10 |
| `symlinks` | enum: allow \| deny | allow | deny refuses a file whose real path leaves the root. | reload | site file | 1 |
| `php` | table | (none) | php = { socket = ... } names an existing php-fpm; with user and no socket the pool is generated and the keys below size it. | reload | site-create (php_socket, php_children, php_version) and settings | 7 |
| `proxy` | table | (none) | Defaults for the site's proxy locations (host, forwarded, headers, hide, redirects, tls, timeouts). | reload | site file | 12 |
| `upstream` | URL or list | (none) | app = proxy, rails, redmine, django, wagtail or node: where the application listens; a list balances round-robin with passive health. | reload | site-create (upstream) | 4b |
| `response_headers` | array of tables | none | [[site.response_headers]] rules: fields the site sets, defaults or removes by path, on every answer it gives (files, PHP, a proxied application, its own error pages and redirects); per field the most specific rule naming it decides. | reload | site-create (response_headers) | 14c |
| `response_compression` | bool \| { enabled, exclude_paths, compress_signed_in, compress_event_streams, offload, codings, levels, min_size, extra_types } | the main file's [response_compression] | This site's response compression. true or false sets its enabled alone; the table form overrides the main file's [response_compression] field by field (codings replaces the list, extra_types adds to it) and adds exclude_paths; what it leaves out comes from the main file, and a site without the key follows the main file whole. In a site file it is response_compression = { ... } inside the [[site]] table or [site.response_compression] below it; a bare [response_compression] there is refused. agensio -t --explain prints each site's values and which are its own. On a managed site site_update sets enabled, exclude_paths, compress_signed_in and codings (ctl --compression, --compression-codings, --compression-exclude, --compression-signed-in); the other fields are the main file's. | reload | site-create (response_compression) | 20 |
## `response_compression = {}`

| key | type | default | meaning | applies | via | doc |
|---|---|---|---|---|---|---|
| `enabled` | bool | the main file's | This site's switch, over the main file's enabled; response_compression = true or false says the same alone. | reload | site-create (response_compression) | 20 |
| `exclude_paths` | list of URL paths | [] | Path prefixes never compressed, whoever asks: an account or checkout page that reflects input beside a token (BREACH), an API an odd client reads. At most 32, "/"-rooted. A site's alone: the main file has none. | reload | site-create (response_compression) | 20 |
| `compress_signed_in` | bool | the main file's | As the main file's compress_signed_in, for this site: true compresses the answers of its own [[site.auth]] paths, of address-rule admissions and of browser-replayed Authorization too. | reload | site-create (response_compression) | 20 |
| `compress_event_streams` | bool | the main file's | As the main file's compress_event_streams, for this site: true compresses its text/event-stream answers, each event sent as it comes. | reload | site-create (response_compression) | 20 |
| `offload` | bool | the main file's | As the main file's offload, for this site: true keeps the browser's Accept-Encoding from its application, so agensio compresses. | reload | site-create (response_compression) | 20 |
| `codings` | list | the main file's | This site's codings and their order, replacing the main file's list: a site behind Cloudflare, CloudFront or Fastly puts br first while the host's others keep zstd first. The copies of its cached files follow it. | reload | site-create (response_compression) | 20 |
| `levels` | { zstd, br, gzip } | the main file's | This site's levels for answers compressed per request, each one named over the main file's. | reload | site file | 20 |
| `min_size` | size | the main file's | This site's minimum size, over the main file's. | reload | site file | 20 |
| `extra_types` | list of media types | [] | Media types compressed for this site beyond the built-in list and the main file's extra_types, which it adds to (application/x-ndjson, application/yaml: the built-in list has every +json and +xml type already). At most 32. | reload | site file | 20 |
## `[response_compression]`

| key | type | default | meaning | applies | via | doc |
|---|---|---|---|---|---|---|
| `enabled` | bool | false | Whether sites compress their answers for browsers that take it (zstd, brotli, gzip): the copies of cached files made once in memory, and PHP, proxied and CGI answers compressed per request (agensio's own error pages, a few hundred bytes, are not). False by default, so no CPU is spent unless asked; a site's own response_compression = true or false decides for that site. Already-compressed answers pass through, a 206 is never compressed, Vary: Accept-Encoding goes on every answer that could have been, HEAD gets the GET's fields, and every answer compressed per request carries up to 32 bytes of random padding against BREACH (docs/design-compression.md). | reload | file | 20 |
| `compress_signed_in` | bool | false | Whether an answer agensio itself knows to be a signed-in visitor's is compressed too: a path under a [[site.auth]] password (verified or let in by skip_for), a request admitted by an address rule of [[site.access]] that refuses others (not any, not report mode), or a browser-replayed Authorization (Basic, Digest, Negotiate, NTLM; a Bearer token is a script's and does not count). False is the BREACH guard: a compressed page holding a secret beside reflected input leaks the secret to an attacker who can make the visitor's browser request it, and these three are the credentials the browser attaches on its own. An application's own login (its session cookie) is invisible to the server, as to every server; those pages are compressed, padded, and the application's masked tokens (Django, Rails) or a site's exclude_paths protect them. | reload | file | 20 |
| `compress_event_streams` | bool | false | Compress text/event-stream answers too, each event sent as it comes (the upstream's pause flushes the coding), with an encoder sized for a stream held open (86 to 872 KB by coding at the default levels). False by default: each event's compressed size is visible on its own, so a stream that puts a secret beside what a visitor sent leaks it faster than a page does (BREACH); true for live prices, metrics, notifications. | reload | file | 20 |
| `offload` | bool | false | false forwards the browser's Accept-Encoding to the application, which may compress itself (Next.js, Ghost, Grafana, PHP's zlib.output_compression); agensio passes such an answer through. true keeps Accept-Encoding from the application (the proxied field, FastCGI's and CGI's HTTP_ACCEPT_ENCODING), so it answers plain and agensio compresses every answer, padded and under its guard: zstd or brotli for a gzip-only application. Acts only on a site that compresses. | reload | file | 20 |
| `codings` | list | ["zstd", "br", "gzip"] | The codings offered, in the order that decides when a browser takes several equally (q-values decide first). zstd first costs a quarter of brotli's CPU for 1 to 8 % more bytes on HTML and serves 83 % of browsers, brotli the rest; behind Cloudflare, CloudFront or Fastly put br first: they ask the origin for brotli, pass it to visitors and ignore an origin's zstd. Cached files get copies of the brotli and gzip listed (none of zstd: brotli 11 is smaller, and every browser that takes zstd takes brotli), a written list decides the .br and .gz files beside them too, and between those two brotli wins a tie whatever the order. A coding the build lacks is refused at -t, naming the package; the default list holds what the build has. | reload | file | 20 |
| `levels` | { zstd, br, gzip } | { zstd = 3, br = 3, gzip = 5 } | The encoder levels for answers compressed per request: zstd 1 to 9, br 1 to 6, gzip 1 to 9. Measured on real pages (bench/results/compression-levels-20261030.md): zstd 3 matches gzip 6's size within 2 % at eight times its speed; br 3 matches zstd 3's bytes within 2 % at a third of its speed, and br 4 is 5 to 7 % smaller on HTML at 1.5 to 1.8 times br 3's cost; gzip 5 is gzip 6's size at 0.6 of its cost, gzip 1 (nginx's default) 7 to 17 % larger at half of gzip 5's. The copies of cached files are made once at brotli 11 and gzip 9 and are not settable. Windows are fixed (zstd 2^19, brotli 2^18) for the memory per stream. | reload | file | 20 |
| `min_size` | size | 1KB | Answers smaller than this are not compressed, cached files and applications' answers alike. At most 1MB. | reload | file | 20 |
| `extra_types` | list of media types | [] | Media types compressed beyond the built-in list (text/* but event streams, JavaScript, JSON and +json, XML and +xml, XHTML, SVG, ICO, wasm, TTF/OTF/EOT, web manifests), for cached files and applications' answers alike. Matched on the type without parameters, so application/json covers application/json; charset=utf-8. Images, audio, video, archives and WOFF are never compressed. At most 32. | reload | file | 20 |
## `levels = {}`

| key | type | default | meaning | applies | via | doc |
|---|---|---|---|---|---|---|
| `zstd` | int | 3 | zstd level for per-request answers, 1 to 9. | reload | file or site file | 20 |
| `br` | int | 3 | brotli quality for per-request answers, 1 to 6. | reload | file or site file | 20 |
| `gzip` | int | 5 | gzip level for per-request answers, 1 to 9. | reload | file or site file | 20 |
## `[[site]]`

| key | type | default | meaning | applies | via | doc |
|---|---|---|---|---|---|---|
| `response_headers_baseline` | bool | (on with app, off without) | The preset's security baseline (docs/headers.md 4), only what cannot break a working page: Referrer-Policy: strict-origin-when-cross-origin where an answer has none, X-Content-Type-Options: nosniff on the files and error pages agensio serves (never an application's answer, where a script of the wrong type would stop), X-Powered-By removed, and on a static site Cache-Control: no-cache on its HTML. A [[site.response_headers]] rule naming one of these fields decides instead. false turns it off; true gives a site without app the static site's. | reload | site-create (response_headers_baseline) | 14c |
| `response_headers_offer_declined` | list of field names: X-Frame-Options, Content-Security-Policy, Permissions-Policy, X-Content-Type-Options | none | The fields the baseline leaves to the owner (docs/headers.md 4.1) that the owner decided the site must not send, so path_check's response_headers_offer and health's response_headers_suggested stop naming them: X-Frame-Options when other sites embed its pages, a Content-Security-Policy the application cannot live with. It sends and removes nothing; HSTS is declined with hsts = "application" or "none". | reload | site-create (response_headers_offer_declined) | 14c |
| `location` | array of tables | (preset-dependent) | [[site.location]] blocks; a hand-written one replaces the preset's at its path, except one that sets only add_headers, which adds its fields to the preset's. | reload | site file | 6 |
## `php = {}`

| key | type | default | meaning | applies | via | doc |
|---|---|---|---|---|---|---|
| `socket` | unix:/path or host:port | (generated with user) | An existing php-fpm pool to use. | reload | site-create (php_socket) | 7 |
| `children` | int | 8 | pm.max_children of the generated pool; also the FastCGI connection budget. | reload + php-fpm reload | settings (children) / site-create (php_children) | 7 |
| `pm` | enum: ondemand \| dynamic \| static | ondemand | The pool's process manager: ondemand keeps nothing resident while idle, static keeps every child (benchmarks). | reload + php-fpm reload | settings | 7 |
| `max_requests` | int | 500 | pm.max_requests (0 = never recycle). | reload + php-fpm reload | settings | 7 |
| `memory_limit` | size | 256M | PHP memory_limit of the pool. | reload + php-fpm reload | settings | 7 |
| `max_execution_time` | seconds | 60 | PHP max_execution_time of the pool. | reload + php-fpm reload | settings | 7 |
| `max_input_time` | seconds | 60 | PHP max_input_time of the pool (how long an upload may take to arrive). | reload + php-fpm reload | settings | 7 |
| `version` | string (major.minor) | [server] php_version, else the newest installed | The site's PHP version: agensio pools writes its pool into that version's pool directory, and its socket carries the version. php_versions lists the versions installed. | reload + agensio pools | site-create, site-update (php_version) | 7b |
| `open_basedir` | list of paths | project, tmp, sessions | Replaces the pool's open_basedir. Root only: it changes what the site may reach. | reload + php-fpm reload | site file | 7 |
| `extra` | table | {} | php_admin_value lines. Root only: arbitrary ini keys include code execution. | reload + php-fpm reload | site file | 7 |
| `read_timeout` | seconds | 60 | Waiting for php-fpm's answer: 504 beyond. | reload | site file | 7 |
| `connect_timeout` | seconds | 5 | Connecting to php-fpm: 502 beyond. | reload | site file | 7 |
| `send_timeout` | seconds | 30 | Sending the request to php-fpm. | reload | site file | 7 |
| `max_connections` | int | 16 (children / workers with a generated pool) | Connections to php-fpm per worker. | reload | site file | 7 |
| `max_idle` | int | 8 | Kept idle connections per worker (keep_conn). | reload | site file | 7 |
| `idle_timeout` | seconds | 30 | Kept connection closed after this long idle (0 = never); lets an ondemand child exit. | reload | site file | 7 |
| `queue_depth` | int | 64 | Requests waiting for a connection per worker; 503 beyond. | reload | site file | 7 |
| `queue_wait` | seconds | 5 | Longest wait in that queue; 503 with Retry-After beyond. | reload | site file | 7 |
| `priority_reserve` | share | 0 | Share of max_connections (0 to 1) kept for priority = true locations. | reload | site file | 7 |
| `keep_conn` | bool | false (true with a generated static or dynamic pool of at least one child per worker) | FastCGI keep-alive; php-fpm pins a child to every kept connection, so not with pm = ondemand, and max_connections x workers at most the children. | reload | site file | 7 |
| `buffering` | bool | true | Buffer php-fpm's whole answer (memory, then a temp file) so the child is freed at once; false streams it. | reload | site file | 7 |
| `buffer_max` | size | 1MB | Buffered answer kept in memory up to this, spilled to a temp file above. | reload | site file | 7 |
| `buffer_file_max` | size | 1GB | Cap on that temp file; beyond it the rest streams. | reload | site file | 7 |
| `request_buffering` | bool | true | Collect the request body (memory, then a temp file) before talking to php-fpm; false streams it. | reload | site file | 7 |
| `request_buffer_max` | size | 256KB | Request body kept in memory up to this, spilled above. | reload | site file | 7 |
| `head_max` | size | 64KB | Longest response head accepted from php-fpm. | reload | site file | 7 |
| `path_info` | bool | true | Route /index.php/extra with PATH_INFO. | reload | site file | 7 |
| `remote_root` | path | (none) | php-fpm in a container: the script path as the container sees it. | reload | site file | 9 |
| `max_fails` | int | 3 | Failures before a member of an upstream list is skipped. | reload | site file | 12 |
| `fail_timeout` | seconds | 10 | How long a failed member is skipped. | reload | site file | 12 |
## `proxy = {}`

| key | type | default | meaning | applies | via | doc |
|---|---|---|---|---|---|---|
| `host` | string | (passed through) | The Host header sent to the origin; $host and other variables allowed. | reload | site file | 12 |
| `forwarded` | enum: x-forwarded \| forwarded \| both \| off | x-forwarded | Which client-address fields go to the origin: X-Forwarded-For/Proto/Host, RFC 7239 Forwarded, both, or none; X-Real-IP with the client agensio believes goes with all but off. A client's own values are replaced unless it is a trusted proxy, whose chain is appended to; a client's X-Real-IP is never passed on, and a CDN's client fields (CF-Connecting-IP, True-Client-IP, Client-IP and the like) only from a trusted proxy. | reload | site file | 12 |
| `request_headers` | table | {} | Fields added to the request forwarded to the origin, with $ variables; one agensio writes itself (Host, X-Forwarded-*, Forwarded, X-Real-IP) is replaced, sent once; "" removes (X-Real-IP = "" stops agensio's own). | reload | site file | 12 |
| `hide` | list | [] | Response fields removed before the client sees them. | reload | site file | 12 |
| `redirects` | enum: rewrite \| pass | rewrite | Rewrite a Location that points at the origin (its address, or the name given as host) to this site. | reload | site file | 12 |
| `tls` | table { verify, ca, server_name } | verify = true | TLS to the origin: verification, a CA bundle, the SNI name. | reload | site file | 12 |
| `upgrade` | bool | true | Let the origin's 101 turn the connection into a tunnel (WebSockets). | reload | site file | 12 |
| `tunnel_timeout` | seconds | 0 (none) | Idle timeout of an upgraded tunnel. | reload | site file | 12 |
| `read_timeout` | seconds | 60 | Waiting for the origin's answer: 504 beyond. | reload | site file | 12 |
| `connect_timeout` | seconds | 5 | Connecting to the origin: 502 beyond. | reload | site file | 12 |
| `send_timeout` | seconds | 30 | Sending to the origin; on a WebSocket or other tunnel, the longest one write to either side may wait before the tunnel is closed (a quiet tunnel has none waiting). | reload | site file | 12 |
| `max_connections` | int | 256 | Connections to the origin per worker. | reload | site file | 12 |
| `max_idle` | int | 64 | Kept idle connections per worker. | reload | site file | 12 |
| `idle_timeout` | seconds | 30 | Kept connection closed after this long idle (0 = until the origin closes it). | reload | site file | 12 |
| `queue_depth` | int | 1024 | Requests waiting per worker; 503 beyond. | reload | site file | 12 |
| `queue_wait` | seconds | 5 | Longest wait in the queue. | reload | site file | 12 |
| `priority_reserve` | share | 0 | Share of max_connections (0 to 1) kept for priority = true locations. | reload | site file | 12 |
| `buffering` | bool | true | Buffer the origin's answer or stream it. | reload | site file | 12 |
| `buffer_max` | size | 1MB | Memory before the answer spills to a temp file. | reload | site file | 12 |
| `buffer_file_max` | size | 1GB | Cap on that temp file. | reload | site file | 12 |
| `request_buffering` | bool | true | Collect the request body before forwarding. | reload | site file | 12 |
| `request_buffer_max` | size | 256KB | Memory before the body spills. | reload | site file | 12 |
| `head_max` | size | 64KB | Longest response head accepted. | reload | site file | 12 |
| `max_fails` | int | 3 | Failures before a member is skipped. | reload | site file | 12 |
| `fail_timeout` | seconds | 10 | How long a failed member is skipped. | reload | site file | 12 |
## `[[site.location]]`

| key | type | default | meaning | applies | via | doc |
|---|---|---|---|---|---|---|
| `path` | string | (required) | The path this location matches. | reload | site file | 6 |
| `match` | enum: prefix \| exact \| suffix | prefix | How path matches: a prefix (longest wins), the exact path, or an ending such as .php. | reload | site file | 6 |
| `root` | path | the site's root | A different document root for this location. | reload | site file | 6 |
| `alias` | path | (none) | Serve this directory in place of the matched prefix. | reload | site file | 6 |
| `index` | list | the site's (a CGI location: index.cgi) | Index files for this location. | reload | site file | 6 |
| `try_files` | list | the site's | What to try for a path here. | reload | site file | 6 |
| `hidden_files` | bool | the site's | Serve dot-files here. | reload | site file | 6 |
| `symlinks` | enum: allow \| deny | the site's | Symlink policy here. | reload | site file | 6 |
| `handler` | enum: static \| fastcgi \| proxy \| cgi \| deny | static (fastcgi with php, proxy with upstream) | What answers here; deny answers 404 whatever exists. | reload | site file | 6 |
| `methods` | list | what the handler implements | Narrow the methods accepted (others get 405 with Allow). | reload | site file | 6 |
| `final` | bool | false | A prefix location that wins over suffix matches below it (nginx ^~): nothing PHP-like runs under it. | reload | site file | 6 |
| `deny_suffixes` | list | [] | Endings answered 404 here whatever exists (matched without regard to case or trailing dots). | reload | site file | 6 |
| `allow_suffixes` | list | [] | When set, only request paths ending with one of these are served here (matched like deny_suffixes); every other path, a directory or a bare name included, is 404 whatever exists. For a directory whose public media sits beside private data (Grav's user/data). | reload | site file | 6 |
| `add_headers` | table | {} | Response headers added to this location's successful answers (Cache-Control for assets). Strict-Transport-Security is refused here: it is the site's hsts key. | reload | site file | 6 |
| `priority` | bool | false | This location's upstream requests draw on priority_reserve. | reload | site file | 7 |
| `fastcgi` | table | the site's php | fastcgi = { socket, read_timeout, ... }: FastCGI for this location (handler = "fastcgi"), the keys of php = {}; without it the site's php table. | reload | site file | 7 |
| `upstream` | URL or list | (none) | Proxy this location to an origin. | reload | site file | 12 |
| `proxy` | table | the site's | Proxy policy for this location. | reload | site file | 12 |
| `cgi` | table { interpreter, env } | (none) | Run scripts here as CGI processes (interpreter, extra environment). | reload | site file | 13 |
## `root additions file`

| key | type | default | meaning | applies | via | doc |
|---|---|---|---|---|---|---|
| `site` | string | (required) | sites.d/<domain>.root.toml beside a managed site's file: the site these [[location]] tables extend (its domain). Root's freedom on a site the tools manage: any [[site.location]] key, merged before the preset so the additions win at their path; the file must belong to the owner of the main configuration and be writable by nobody else; the control plane never writes it, site_show names it. | reload | root additions | 15 |
## `tls = {}`

| key | type | default | meaning | applies | via | doc |
|---|---|---|---|---|---|---|
| `cert` | path | (required with key) | The certificate chain (PEM) a site presents; tls = "auto" obtains one instead. | reload | site-create (https = { cert, key }) | 14 |
| `key` | path | (required with cert) | The private key (PEM) of that certificate; 0600, root's or the server's. | reload | site-create (https = { cert, key }) | 14 |
## `proxy tls = {}`

| key | type | default | meaning | applies | via | doc |
|---|---|---|---|---|---|---|
| `verify` | bool | true | Verify the origin's certificate (a self-signed origin needs false, or ca). | reload | site file | 12 |
| `ca` | path | "" (system store) | A PEM bundle to verify the origin with. | reload | site file | 12 |
| `server_name` | string | (none: the certificate must name the upstream's address) | The name the origin's certificate must carry, also sent as SNI. Without it the certificate must name the upstream's IP address and no SNI is sent; most certificates name hosts, so set it to the name yours carries. | reload | site file | 12 |
## `[[site.auth]]`

| key | type | default | meaning | applies | via | doc |
|---|---|---|---|---|---|---|
| `path` | string | (required) | The path a password covers, matched like an access rule: a prefix covers it and everything below it on a segment boundary, in any capitalisation; "/" is the whole site. Checked before the locations, after refuse and the access rules, on every internal redirect and on a directory's index, so no location (a .php file, a proxy) steps around it. The longest rule decides. | reload | site file | 19b |
| `match` | enum: prefix \| exact | prefix | exact: this path, and the requests agensio runs as that script (PHP or CGI with path info: /wp-login.php/x runs /wp-login.php). | reload | site file | 19b |
| `users` | path | (required unless open) | The user file: name:hash lines (htpasswd -B or mkpasswd -m yescrypt), with optional :expires=YYYY-MM-DD (refused from that day, UTC) and :note=text (whose login it is). yescrypt, bcrypt, sha512crypt, sha256crypt and scrypt hashes; MD5 (apr1), {SHA}, {PLAIN} and DES are refused at load with the command to use instead. Root's (the owner of the main configuration), not writable by group or others, not readable by others (640), read at load and reload. | reload | site file | 19b |
| `realm` | string | the site's first name | The realm of the challenge (WWW-Authenticate: Basic realm="...", charset="UTF-8"); a browser keeps one login per realm. 1 to 64 characters, no quote or backslash. | reload | site file | 19b |
| `skip_for` | list | (none) | Clients that get in without a password: addresses, ranges or @sets from [addresses] (nginx satisfy any). Everyone else is asked. | reload | site file | 19b |
| `open` | bool | false | true: no password on this path, below a protected one (a health check, a webhook). Takes no users. | reload | site file | 19b |
| `plain_http` | enum: refuse \| allow | refuse | refuse: a request over plain HTTP is never asked for a password (the browser would send it in clear): a GET or HEAD goes to https when the site has it, anything else gets 403 saying to use HTTPS; a connection from this host and a request a trusted proxy forwarded as https are asked as usual (behind a trusted proxy, its X-Forwarded-Proto and the client it names decide, never its own loopback address). allow: asked anyway, for a tool on a network you trust; -t warns and health keeps a finding. | reload | site file | 19b |
| `credentials` | enum: pass \| strip | pass on a site that runs PHP, strip otherwise | pass: the application receives Authorization (PHP_AUTH_USER and PHP_AUTH_PW; WordPress's loopback calls need them). strip: it never does. A client let in by skip_for never passes it (nothing was verified). PHP gets REMOTE_USER and AUTH_TYPE for a verified user. | reload | site file | 19b |
| `forward_user` | field name | (none) | A proxy location sends the verified user name in this request field (X-Remote-User); the client's own field of that name is removed first. | reload | site file | 19b |
## `[[site.response_headers]]`

| key | type | default | meaning | applies | via | doc |
|---|---|---|---|---|---|---|
| `path` | string | (required) | The path the rule covers, normalised: a prefix covers it and everything below it on a segment boundary, in any capitalisation (/assets: /assets, /Assets/x, never /assetsx); "/" is the whole site. It matches the path the client asked for, never an internal target (try_files, a directory's index). | reload | site file | 14c |
| `match` | enum: prefix \| exact | prefix | exact: this path alone. At one path an exact rule decides before a prefix one. | reload | site file | 14c |
| `set` | table: field name to value | none | Fields sent with this value, replacing every copy the answer had (the application's, a location's add_headers): the browser never sees two. Fixed printable text, at most 4 KB, no $ variables. Not the server's own fields (framing, Content-Type, Date, Vary, Location, Server, Alt-Svc, Set-Cookie, the password fields, HSTS: hsts does that). | reload | site file | 14c |
| `default` | table: field name to value | none | Fields sent only when the answer has no copy: the application's own wins. The verb for a Content-Security-Policy on an application site, which may send its own with nonces. | reload | site file | 14c |
| `remove` | list of field names | none | Fields deleted from the answer, every copy, whoever put it there (X-Powered-By, an application's own Strict-Transport-Security); any name but the framing and representation fields. | reload | site file | 14c |
| `endings` | list of file endings | none (every answer) | Only the files agensio serves from disk whose name ends so (svg, woff2, tar.gz; any case), after try_files and a directory's index: /about/ served from about/index.html is an html answer. Never an application's answer, so a sitemap.xml PHP makes is untouched by an xml rule. At one path a rule whose endings the file has decides before one without. An ending the site never serves itself (php where PHP runs it, an ending its preset refuses) is refused. | reload | site file | 14c |
| `when` | enum: always \| success | always | success: only 2xx and 304 answers; on any other the next rule naming the field decides. A Cache-Control or Expires that lets caches keep the answer (max-age above 0, s-maxage, public, immutable) needs it, so an error is never kept for a lifetime. | reload | site file | 14c |
## `[[site.redirect]]`

| key | type | default | meaning | applies | via | doc |
|---|---|---|---|---|---|---|
| `from` | string, a path | (required) | The path the rule redirects, normalised and case-sensitive: a prefix covers it and everything below it on a segment boundary (/blog: /blog, /blog/x, never /blogger); an exact rule may add the query parameters it requires (/index.php?page=about: present with that value, in any order, others ignored). The most specific rule decides (the longest from, an exact rule before a prefix of the same path), never the order written; the same from twice is refused. | reload | site file | 14b |
| `match` | enum: prefix \| exact | prefix | exact: this path alone (/docs, not /docs/, so /docs to /docs/ is allowed). | reload | site file | 14b |
| `to` | string: a path or an http(s) URL | (required; none with 410) | Where it sends: a path of this site (a relative Location) or https://host/path. The rest of the path follows a prefix rule's target (remainder), the request's query follows the target's own after & (query), a fragment of to is sent. Never user@host, another scheme or a control character. | reload | site file | 14b |
| `status` | 301 \| 302 \| 307 \| 308 \| 410 | (required) | 301 or 308 for a page that moved for good, 302 or 307 for now; 307 and 308 keep a POST a POST; 410 for a page that is gone, with no to. | reload | site file | 14b |
| `remainder` | enum: keep \| drop | keep | A prefix rule: the rest of the path after the target (/blog/x to /news/x), or dropped (a section to one page; from "/" with drop is warned: a soft 404 to search engines). | reload | site file | 14b |
| `query` | enum: keep \| drop | keep (drop when from names parameters) | The request's query after the target's, or dropped (old tracking parameters). | reload | site file | 14b |
| `cache` | duration ("1d", seconds) or "none" | "1d" | How long browsers keep a permanent (301, 308) redirect, Cache-Control max-age, so a mistake is undone within it; none sends no lifetime and Chromium keeps it for good. Not for 302, 307 or 410. | reload | site file | 14b |
## `[[site.access]]`

| key | type | default | meaning | applies | via | doc |
|---|---|---|---|---|---|---|
| `path` | string | (required) | The path the rule covers: a prefix covers it and everything below it on a segment boundary (/wp-admin: /wp-admin and /wp-admin/x, never /wp-administrator), in any capitalisation; "/" is the whole site. Checked before the locations, so whichever one would serve the path (a .php file, a proxy) is covered. | reload | site file, site-create (rules.restricted) | 19 |
| `match` | enum: prefix \| exact | prefix | exact: this path, and the requests agensio runs as that script (PHP or CGI with path info: /wp-login.php/x runs /wp-login.php). | reload | site file, site-create (rules.restricted) | 19 |
| `allow` | list | (required) | Who reaches the path: addresses (203.0.113.7), ranges (203.0.113.0/24, 2001:db8:5::/64), sets from [addresses] (@office), or ["any"] to reopen a path below a restricted one. Everyone else gets 403 naming the address the server saw (behind trusted_proxies, the forwarded client). The longest rule covering a path decides; at most 32 rules of 64 addresses. | reload | site file, site-create (rules.restricted) | 19 |
| `mode` | enum: enforce \| report | enforce | report: everyone is served and the error log names who would have been refused, to try a rule before it locks anyone out. | reload | site file, site-create (rules.restricted) | 19 |
## `cgi = {}`

| key | type | default | meaning | applies | via | doc |
|---|---|---|---|---|---|---|
| `interpreter` | path | (the script itself) | The program that runs the script (e.g. /usr/bin/python3). | reload | site file | 13 |
| `env` | table | {} | Environment variables added for the script. | reload | site file | 13 |


# Installing agensio

This guide is for the administrator who installs agensio on a server, desktop or
container host. It has two parts: the **directory layout** agensio uses on each platform
(fixed and predictable, so that a hand-made setup, a package and a control panel end up
with the same shape), and the **installation steps** per platform, which are completed
with the first tagged release on GitHub.

Status: agensio is pre-alpha. Every path marked *today* is what the current binary does;
paths marked *planned* are the defaults the release packages will ship with and that the
binary will adopt on that platform. Until then, anything not marked *today* is set
explicitly in the configuration file.

## 1. Principles

- **The configuration file can live anywhere** (`agensio -c FILE`), and every path in it
  may point anywhere. Relative paths in the file are resolved against the file's own
  directory, so a whole site can be moved with its configuration.
- **Without `-c`** the binary looks, in order, for `./agensio.toml`,
  `./config/agensio.toml`, `/etc/agensio/agensio.toml`,
  `/usr/local/etc/agensio/agensio.toml` and `/opt/homebrew/etc/agensio/agensio.toml`
  (*today*). `agensio reload`, `agensio -t` and `agensio pools` use the same search, so
  on an installed system no command needs a path.
- **agensio creates only what it owns**: the pid file, its log files, the per-user state
  directories (`agensio pools`), the certificate store. It never creates document roots
  or site directories; it checks their ownership (`agensio -t`, section 3 of this guide
  and `docs/design-per-site-users.md`).
- **One directory per concern**, never mixed: configuration, logs, runtime state that
  survives a reboot (certificates, sessions), runtime state that does not (pid, sockets),
  and site content.

## 2. Directory layout per platform

### Linux (Debian, Ubuntu, RHEL, Fedora, Alpine)

Filesystem Hierarchy Standard paths. `agensio` is the service user and group; site users
are separate accounts (section 3).

| purpose | path | owner, mode | status |
|---|---|---|---|
| binary | `/usr/sbin/agensio` (package) or `/usr/local/sbin/agensio` (tarball, source build) | root 0755 | today (package) |
| main configuration | `/etc/agensio/agensio.toml` | root:agensio 0640 | today (search path) |
| one file per site | `/etc/agensio/sites.d/<domain>.toml`, pulled in by `include = ["sites.d/*.toml"]`; `agensio ctl site-create` writes here | agensio:agensio 0750 dir, files 0640 | today |
| TLS material you manage yourself | `/etc/agensio/ssl/<domain>/` (`fullchain.pem`, `key.pem` 0600) | root 0700 | convention |
| server logs | `/var/log/agensio/access.log`, `/var/log/agensio/error.log` | root:agensio 0750 dir (the server's account replaces nothing root or logrotate opens there), files agensio 0640 | today (package); `logs/` next to the configuration file without it |
| per-site logs | `/var/log/agensio/sites/<domain>.log`, the one path a managed site file may name; a site file root writes may name any path, whose directory root owns (configuration guide 8c) | `sites/` agensio:agensio 0750, files agensio:<site group> 0640 | today (`site-create`; handed over at start on the open descriptor) |
| pid file | `/run/agensio.pid` | root 0644 | today |
| php-fpm pool sockets, one per site | `/run/php/agensio-<user>-<8 hex>-<version>.sock` (Debian, Ubuntu, Alpine), `/run/php-fpm/...` (RHEL, Fedora) | <user>:agensio 0660 | today (`server.pools_run`) |
| generated php-fpm pool files, one per site | the pool directory of the site's PHP version: `/etc/php/<version>/fpm/pool.d/agensio-<user>-<8 hex>.conf` (Debian), `/etc/opt/remi/php<XY>/php-fpm.d/` (Remi) | root 0644 | today (`agensio pools`; `[php.runtimes]` for a version not found) |
| persistent state | `/var/lib/agensio/` | agensio 0751 (site users traverse to their own directory, cannot list others) | today (`server.state_dir`) |
| certificates (automatic) | `/var/lib/agensio/acme/account.key`, `/var/lib/agensio/acme/<domain>/key.pem` (0600), `fullchain.pem` | agensio 0700 dir | today (`server.acme.storage`) |
| per-site PHP state | `/var/lib/agensio/<user>/php/<domain>/tmp/` (uploads are created here and renamed into the site, so it carries the server's group), `.../sessions/` | `tmp/` 2750 <user>:agensio, `sessions/` 0700 <user>, the directories above 0700 <user> | today (`agensio pools`) |
| record of the site files served | `/var/lib/agensio/.server/served`: one line per site file served, a digest and its path; written after every start and reload, read at a start to decide a conflict between two site files as the last reload did (configuration.md 12c); no backup needed | agensio 0700 dir | today |
| uploaded archives | `/var/lib/agensio/uploads/` (`agensio ctl upload NAME`, consumed by `site-install --file`) | agensio 0700 | today |
| temporary spill files | the system temp directory, unlinked immediately (large upstream bodies and request bodies) | agensio | today |
| site content | `/var/www/<domain>/` (section 3) | site user | convention |
| systemd unit | `/usr/lib/systemd/system/agensio.service` (package) or `/etc/systemd/system/agensio.service` | root 0644 | today (package, `packaging/agensio.service`) |
| logrotate | `/etc/logrotate.d/agensio` (`postrotate: kill -USR1 $(cat /run/agensio.pid)`) | root 0644 | today (package) |
| host protection, shipped inactive | `/usr/share/agensio/firewall/agensio.nft`, `/usr/share/agensio/fail2ban/{jail.d,filter.d}/`, `/usr/lib/systemd/system/agensio-firewall.service`; once root applies them: `/etc/agensio/firewall.nft`, `/etc/fail2ban/jail.d/agensio.conf`, `/etc/fail2ban/filter.d/agensio-*.conf` | root 0644 | today (package; `agensio ctl protection`, configuration.md 18) |

### macOS (Homebrew)

Everything under the Homebrew prefix, `/opt/homebrew` on Apple silicon and `/usr/local`
on Intel, written `$PREFIX` below. Nothing outside the prefix, so `brew uninstall`
removes it all.

| purpose | path | status |
|---|---|---|
| binary | `$PREFIX/bin/agensio` | planned (formula) |
| configuration | `$PREFIX/etc/agensio/agensio.toml`, `$PREFIX/etc/agensio/sites.d/` | today (search path) |
| logs | `$PREFIX/var/log/agensio/` | planned default; today `logs/` next to the configuration file |
| pid file | `$PREFIX/var/run/agensio.pid` | today (`/usr/local/var/run/agensio.pid`; the `/opt/homebrew` form is planned) |
| php-fpm pool sockets and files | `$PREFIX/var/run/agensio-<user>-<8 hex>-<version>.sock`, `$PREFIX/etc/php/<version>/php-fpm.d/` | today (detected from `$PREFIX/etc/php`) |
| state, certificates, per-user PHP state | `$PREFIX/var/lib/agensio/`, `.../acme/`, `.../<user>/` | planned default; today `/var/lib/agensio` unless `server.state_dir` is set |
| site content | `$PREFIX/var/www/<domain>/` or `~/Sites/<domain>/` for a developer machine | convention |
| service | `$PREFIX/etc/agensio/homebrew.mxcl.agensio.plist`, `brew services start agensio` | planned |

Privileged ports (80, 443) need the service started as root with `server.user` set, as on
Linux; a developer setup on 8080/8443 runs as the logged-in user.

### Windows

agensio compiles on Windows and is not benchmarked there. Service integration, the
ACME client's file ownership and the FastCGI unix-socket path are not ported yet, so
Windows is a developer target until phase H says otherwise. The layout the port will
use follows the platform conventions:

| purpose | path | status |
|---|---|---|
| binary | `%ProgramFiles%\agensio\agensio.exe` | planned |
| configuration | `%ProgramData%\agensio\agensio.toml`, `%ProgramData%\agensio\sites.d\` | planned (today: `-c` is required, or `agensio.toml` in the working directory) |
| logs | `%ProgramData%\agensio\logs\` | planned |
| state and certificates | `%ProgramData%\agensio\state\`, `...\state\acme\` | planned |
| pid file | none; the service manager owns the process | planned |
| php-fpm | TCP only (`php = { socket = "127.0.0.1:9000" }`); no generated pools | today |
| site content | `C:\inetpub\<domain>\` or `%ProgramData%\agensio\www\<domain>\` | convention |
| service | Windows service `agensio` (`sc create`), `agensio reload` through a control event instead of SIGHUP | planned |

Windows path rules (backslash, drive letters, reserved device names, trailing dots) are
already enforced on request targets.

## 3. Recommended site layout

agensio does not impose this tree, but its ownership rules, the generated php-fpm pools,
the per-site logs and the certificate store fit it, and a control panel that creates it
gets a setup `agensio -t` accepts without exceptions. One directory per domain, one
system user per customer (or per site), agensio in the customer's group only where it
needs to write.

```
/var/www/example.com/          web35:agensio 2750   the site user owns it, the server reads it through its group
├── web/          web35:agensio 2750   the document root (`root`), or the project with public/ for Laravel;
│                                      the setgid bit makes files PHP creates inherit the group
├── log/          agensio:client8 0750  access.log for this site (agensio writes, customer reads)
├── private/      web35:web35 0700     files the site reads but never serves (.env can live here, uploads to review)
└── ssl/          root 0700            only for certificates you manage yourself; automatic ones stay in /var/lib/agensio/acme
```

The account's home is its state directory, `/var/lib/agensio/web35` (created by
`agensio pools`, holding each of its sites' private `tmp/` and `sessions/` under `php/<domain>/`),
never the document root:
`useradd --system --no-create-home --home-dir /var/lib/agensio/web35 --shell /usr/sbin/nologin web35`.
`agensio ctl site-create` prints exactly these commands when the account or the
directories are missing.

The matching site file, `/etc/agensio/sites.d/example.com.toml`:

```toml
[[site]]
server_name = ["example.com", "www.example.com"]
# no listen: the server's addresses, [::]:443 and port 80 beside it redirecting to HTTPS (configuration.md 1c)
root = "/var/www/example.com/web"
user = "web35"
group = "client8"
app = "wordpress"
php = { children = 6, version = "8.3" }
access_log = "/var/www/example.com/log/access.log"
tls = "auto"
```

What follows from `user = "web35"`: the site's own php-fpm pool, run by PHP 8.3's php-fpm as web35
on `/run/php/agensio-web35-431ceb26-8.3.sock`, `open_basedir` at the site root plus the site's
private `tmp/` and `sessions/`, the log file owned `web35:agensio` mode 0640 so the customer can
read it, and the rules `agensio -t` enforces: the root owned by web35 or root and not
writable by others, secrets (`.env`, `wp-config.php`, `.git`) not readable by others, the
`log/` directory owned by agensio and not writable by the site user (so no symlink can be
planted where agensio writes), and nothing (root, socket, state directory, log) shared
between two users. A panel such as ISPConfig maps directly: its `web` is `root`, `log`
is `access_log`, `ssl` is either `tls = { cert, key }` or left to `tls = "auto"`,
`cgi-bin` is a `handler = "cgi"` location.

Small servers with one administrator and no customers can skip the users: a site
without `user` runs PHP through whatever pool `php.socket` names, and everything is
owned by `agensio`. The layout still applies; only the owners change.

## 4. Installation steps

To be completed with the first release. Each platform section will hold: getting the
binary (package, archive or source build), the service user and directories with their
owners and modes, the service definition, the first site checked with `agensio -t`,
php-fpm pools with `agensio pools`, certificates, log rotation, reload, upgrade and
rollback.

### 4.1 Linux

0. **Packages.** Every release on GitHub carries a `.deb` and an `.rpm` built by the
   release workflow; they install the binary, the unit file, log rotation, the packaged
   configuration in `/etc/agensio` with a default site serving `/var/www/html`, create
   the `agensio` account and the `agensio-admin` group, and start the service when port
   80 is free. Steps 2 and 5 below are then already done.

   **Debian 12+, Ubuntu 22.04+, from the release page.** Pick the `.deb` of the release
   at https://github.com/YiannisBourkelis/agensio/releases (GitHub shows the version's
   tilde as a dot in the file name; the package inside is unaffected) and let `apt`
   install it, which also pulls the dependencies. Each release has two:

   - `agensio_<version>_amd64.deb`, built on Ubuntu 22.04: Debian 12 and later, Ubuntu 22.04
     and later, without HTTP/3 (their OpenSSL 3.0 has no QUIC API; HTTP/1, HTTP/2 and TLS as
     everywhere);
   - the file with `deb13` in its name, built on Debian 13 against its OpenSSL 3.5: Debian 13 and
     later only, with HTTP/3 (`docs/configuration.md` 17). On Debian 12 `apt` refuses it for
     its dependencies.

   ```sh
   wget https://github.com/YiannisBourkelis/agensio/releases/download/v0.1.0-alpha.3/agensio_0.1.0.alpha.3_amd64.deb
   sudo apt install ./agensio_0.1.0.alpha.3_amd64.deb
   systemctl status agensio         # started if port 80 was free
   curl -s http://127.0.0.1/ | head -3
   ```

   Upgrading is the same two commands with the next release's file: `apt` sees the newer
   version, keeps your edits under `/etc/agensio`, and restarts the service. Removing:
   `sudo apt remove agensio` keeps configuration, logs, certificates and content;
   `sudo apt purge agensio` also removes `/etc/agensio` and `/var/log/agensio`.

   **Debian, Ubuntu, from the APT repository** (available once the release signing key is
   set up, `packaging/README.md`; then `sudo apt update && sudo apt upgrade` follows new
   releases). Two suites, the same two builds as the release page: `trixie` on Debian 13 and
   later, with HTTP/3, and `stable` on Debian 12 and Ubuntu 22.04 and later, without it:

   ```sh
   sudo install -m 0755 -d /etc/apt/keyrings
   curl -fsSL https://yiannisbourkelis.github.io/agensio/agensio.gpg | sudo tee /etc/apt/keyrings/agensio.gpg >/dev/null
   echo "deb [signed-by=/etc/apt/keyrings/agensio.gpg] https://yiannisbourkelis.github.io/agensio/apt trixie main" | sudo tee /etc/apt/sources.list.d/agensio.list   # stable instead of trixie on Debian 12 and Ubuntu
   sudo apt update && sudo apt install agensio
   ```

   The key's fingerprint is `ADD0 06A1 6254 435A 221B 31C5 FE78 1D42 12B6 0F11`. `gpg --show-keys
   /etc/apt/keyrings/agensio.gpg` (gpg is in the `gnupg` package) prints it under `pub ed25519
   2026-10-25 [SC]`; a key with any other fingerprint is not this project's, so remove it and the
   list file rather than install from it.

   A release reaches the repository about five minutes after it is tagged; GitHub Pages' CDN
   keeps each file up to ten minutes, so a host may see it that much later. Each suite also lists
   the release before (the files a host with a cached index asks for, and a way back:
   `sudo apt install agensio=<previous version>`). A Debian 13 host that installed the `deb13`
   file from the release page moves to the repository with the `trixie` line.

   **Fedora, RHEL 9+.** The `.rpm` from the release page (`sudo dnf install ./agensio-0.1.0-0.1.alpha3.x86_64.rpm`),
   or COPR once enabled: `sudo dnf copr enable yiannis/agensio && sudo dnf install agensio`.

   **Arch, Omarchy, Manjaro.** The binary package from the release page:

   ```sh
   wget https://github.com/YiannisBourkelis/agensio/releases/download/v0.1.0-alpha.3/agensio-0.1.0alpha3-1-x86_64.pkg.tar.zst
   sudo pacman -U ./agensio-0.1.0alpha3-1-x86_64.pkg.tar.zst
   ```

   or, once published in the AUR, `yay -S agensio` (`packaging/arch/PKGBUILD`).

1. **Binary.** `.deb` and `.rpm` packages, or a source build (HTTP/3 needs OpenSSL 3.5.1 or later:
   Debian 13, Ubuntu 26.04, RHEL 9.7 or 10.1, Fedora 43, Arch):

   ```
   cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Release
   cmake --build build
   sudo install -m 0755 build/agensio /usr/local/sbin/agensio
   ```

   Dependencies for a source build: a C++20 compiler (GCC 12+, Clang 16+), CMake 3.20+,
   Ninja, Asio headers (`libasio-dev`), OpenSSL 3 or 4 (`libssl-dev`), zlib (`zlib1g-dev`), and for
   response compression zstd and brotli (`libzstd-dev`, `libbrotli-dev`, found through
   `pkg-config`; Fedora `libzstd-devel` and `brotli-devel`, Arch `zstd` and `brotli`). A build
   without one of the two offers the other codings and refuses a configuration naming the
   missing one.

2. **Service user and directories** (the packages do this in their post-install step):

   ```
   sudo useradd --system --home /var/lib/agensio --shell /usr/sbin/nologin agensio
   sudo install -d -o root    -g agensio -m 0750 /etc/agensio
   sudo install -d -o agensio -g agensio -m 0750 /etc/agensio/sites.d   # the control API writes site files here
   sudo install -d -o agensio -g agensio -m 0750 /var/log/agensio
   sudo install -d -o agensio -g agensio -m 0751 /var/lib/agensio   # site users traverse to their own state directory
   sudo install -d -o root    -g root    -m 0755 /var/www
   ```

3. **Configuration.** `/etc/agensio/agensio.toml`:

   ```toml
   include = ["sites.d/*.toml"]

   [server]
   user = "agensio"
   acme = { email = "admin@example.com" }

   [log]
   access = "/var/log/agensio/access.log"
   error = "/var/log/agensio/error.log"
   ```

   Then one file per site in `sites.d/` (section 3), and `sudo agensio -t` until it says
   the configuration is OK. `agensio -t --explain` shows what the presets expanded to.

4. **PHP sites.** `sudo agensio pools` writes the generated pool files into each PHP version's
   pool directory, and the per-site state directories. It exits 3 when php-fpm has to be reloaded,
   printing the line for each version (`systemctl reload php8.4-fpm`). A server started as root
   with its provisioning helper does this itself at every start and with every change of a site
   (`docs/configuration.md` 7b).

5. **Service.** systemd unit (shipped by the packages; to be added to the repository with
   the release):

   ```ini
   [Unit]
   Description=agensio web server
   After=network-online.target
   Wants=network-online.target

   [Service]
   Type=simple
   ExecStartPre=/usr/local/sbin/agensio -t
   ExecStart=/usr/local/sbin/agensio
   ExecReload=/usr/local/sbin/agensio reload
   PIDFile=/run/agensio.pid
   Restart=on-failure
   LimitNOFILE=1048576

   [Install]
   WantedBy=multi-user.target
   ```

   agensio starts as root, binds the ports, opens the logs, prepares the certificate
   store, and switches to `server.user` before it accepts the first connection.

6. **Certificates.** `tls = "auto"` on the site needs port 80 reachable from the internet
   for the validation; the first certificate arrives seconds after the start and the
   server reloads itself onto it. Nothing to schedule.

7. **Log rotation.** `/etc/logrotate.d/agensio` with `postrotate` sending `SIGUSR1`
   (`kill -USR1 $(cat /run/agensio.pid)`): every log file is reopened, nothing is lost.

8. **Changes.** Edit, `sudo agensio -t`, `sudo agensio reload` (or `systemctl reload
   agensio`): no connection is dropped. Restart-only settings: `workers`, `reuse_port`,
   `user`, `group`, `pid_file`, `sendfile`, `sendfile_max_chunk`, `tcp_nodelay`, the whole
   `[cache]` table, `[control]` `socket` and `provision`; the reload names each one it kept.

9. **Upgrade and rollback.** Install the new binary next to the old one, `agensio -t`
   with the new binary, then `systemctl restart agensio`. Keep the previous binary; a
   rollback is the same restart with it. Configuration and state directories are never
   changed by an upgrade; a release that has to migrate a file says so in its notes.

### 4.2 macOS

To be written with the Homebrew formula: `brew install agensio`, `brew services start
agensio` for the plist, configuration under `$PREFIX/etc/agensio`, and the same
`agensio -t`, `agensio pools` (Homebrew php-fpm) and `agensio reload` steps as Linux.
Until then: build from source (`brew install cmake ninja asio openssl@3`, then the same
cmake commands) and run `build/agensio -c path/to/agensio.toml`.

### 4.3 Windows

To be written with the Windows port of the service integration. Until then: build with
Visual Studio 2022 or clang-cl through CMake, run `agensio.exe -c C:\path\agensio.toml`
from a console, PHP through a TCP php-fpm (or php-cgi) socket.

## 5. Checklist for a new server

1. Service user and the four directories (`/etc/agensio`, `/var/log/agensio`,
   `/var/lib/agensio`, `/var/www`) with the owners above.
2. One site per file in `sites.d/`, following section 3.
3. `agensio -t`, then start the service: started as root, it writes the PHP sites' pools before it
   accepts requests (without the helper, `agensio pools` first and the reload it prints).
4. Watch `/var/log/agensio/error.log` for the certificate lines and the first
   `reloaded` message.
5. Log rotation and a backup of `/etc/agensio` and `/var/lib/agensio/acme`.

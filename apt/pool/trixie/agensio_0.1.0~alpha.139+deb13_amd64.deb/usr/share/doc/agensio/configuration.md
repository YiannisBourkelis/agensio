# Configuring agensio

A configuration is one TOML file: `[server]`, `[log]`, `[cache]` and one `[[site]]` per
virtual host, with optional `[[site.location]]` blocks. Paths are relative to the file's
directory. `include = ["sites.d/*.toml"]` pulls in more `[[site]]` tables, one file per
site if a panel writes them, and root additions files beside managed sites (section 15).
Each included site file loads on its own: one with a mistake is set aside and the other
sites are served (section 12c).

Two commands you will use while editing:

```sh
agensio -t -c agensio.toml            # validate; warns about FastCGI upstreams it cannot reach
agensio -t --explain -c agensio.toml  # print the effective configuration after presets
```

`--explain` is the authoritative answer to "what does `app = "..."` do": it prints every
site and location as agensio sees it, marking the blocks a preset generated with
`# from preset:<name>`. The hand-written equivalents below were taken from that output.

Every key, with its type, default, whether a change needs a reload or a restart, and who
may change it, is listed in `docs/keys.md`, generated from the same table that the MCP
tool `config_reference` and `agensio keys` serve; the sections below explain them. A key that
table does not list for its table is refused when the configuration loads, naming the nearest
one: `unknown key 'refsue' (did you mean 'refuse'?)`. A key belongs to the TOML table above it,
so a top-level key (`include`, `[addresses]`) goes above the first `[table]` header, and an
included file holds `[[site]]` tables only. Before 0.1.0-alpha.61 most tables ignored an
unknown key, so a misspelt `refuse` refused nothing and a misspelt `include` loaded no site
file. For
whole jobs (a site on HTTPS, WordPress on its own account, a staging site behind a password,
an application behind the proxy), the cookbook in [examples.md](examples.md) has complete
recipes that the test suite loads with `agensio -t`.

## 1. Static site

```toml
[[site]]
server_name = ["www.example.com", "example.com"]
root = "/var/www/example"
```

Defaults you get without writing them: the server's addresses (`[::]:80` for a site without
`tls`, IPv4 and IPv6 alike, section 1c; a `listen` of the site's own replaces them), `index = ["index.html"]`, dotfiles and
dot-directories hidden (404) except `/.well-known/` at the root (RFC 8615: `security.txt`, app
links, a webroot ACME client's challenge; a dot segment below it stays hidden; before
0.1.0-alpha.70 it needed a location with `hidden_files = true`), symlinks followed, files up to 4 MB cached in memory and
larger ones streamed with sendfile, access log on (see section 8), and Range requests
(one range per request, `If-Range` honoured; video seeking, resumable downloads, PDF
viewers) answered with 206 from the cache and from disk alike.

**Pre-compressed files.** A `name.br` or `name.gz` beside a cached file is served, with
`Content-Encoding` and `Vary: Accept-Encoding`, to a client whose `Accept-Encoding` takes it
(`br` wins a tie, `q=0` refuses one, `*` covers the rest), and the file itself to any other
client. Vite, webpack and the `brotli` and `gzip` tools write these twins at build time;
nothing is compressed at request time (nginx: `gzip_static`, `brotli_static`). A twin is
used only when it is at least as new as the file, since an older one is a build that was
not redone, and it is cached beside the file with an ETag and Last-Modified of its own and
revalidated with it, so a twin added, replaced or removed shows within
`cache.revalidate_interval`. Files above `cache.max_file_size` are served as stored.
`[cache] precompressed = false` turns the lookup off.

**Files still being written.** A file modified in the current second or the one before (agensio
compares modification times in whole seconds, so for one to two seconds after its last write), or
one whose size or modification time changed while agensio read it, is served once as it was read,
with `Cache-Control: no-store` and none of the location's lifetimes (no rule's cache field either),
and is not cached; a twin still being written is passed over. From the second after that it is
cached as usual: a file written at 12:00:00.9 is still `no-store` at 12:00:01.9 and gets its
lifetime from 12:00:02.0. An update made in place (`npm run build` into `public/build`, an unzip over the
root) is served while it writes, and before 0.1.0-alpha.110 a partial copy read then was cached
for a second and could carry a year's `immutable` (Laravel's `/build/`) into every browser that
fetched it. nginx serves such a file per request as it stands, with whatever lifetime its
configuration gives. A modification time more than a second ahead (an archive's, a skewed NFS
server's) counts as settled.

A single-page application that routes on the client:

```toml
[[site]]
server_name = ["app.example.com"]
root = "/var/www/app/dist"
try_files = ["$uri", "$uri/", "/index.html"]   # unknown paths get the shell, assets stay assets
```

`try_files` elements: `$uri` (the path as a file), `$uri/` (as a directory: its index, or a
redirect to the slash form), `=403` / `=404` (answer that status), or `/path` (internal
redirect, routed again through the locations; a `?$query_string` suffix is accepted and
ignored for static files). Without `try_files` the rule is: file, directory index (403 if
there is none), 301 to the slash form for a directory, else 404.

The redirect to the slash form (`/docs` to `/docs/`) is written as every other redirect is
([redirects.md](redirects.md) 5.3): the path encoded again (`/My%20Files/`, `/a%23b/`, a Greek
name as `%CE%A6...`, a backslash as `%5C`, so no directory name can make it point at another
host), the query kept (`/docs/?page=2`, as nginx, Apache, Caddy and h2o keep it), relative, and
with `Cache-Control: max-age=86400` (0.1.0-alpha.100), so a directory that later becomes a page
stops redirecting within a day; Chromium keeps a 301 without a lifetime for good, and nginx and
Apache send none.

A directory's index is a file the site would answer by name. When another location owns it
(a `.php` that runs) it runs there. When the site refuses it by name (a `refuse` pattern, a
`deny` location, a refused ending, a dotfile, a backup of a protected name) it is passed over
as if it were missing: the next index name is tried, then `try_files` goes on to its next step,
the front controller where there is one, else `=404`, or 403 for a directory without an index
when there is no `try_files`. A refused index is never served and never run. So on a preset
where only some scripts run, `/sub/` holding a stray `index.php` is answered by the application,
and TYPO3 13's `/typo3/` reaches `/index.php` as its documentation routes it, without listing
the deprecated `typo3/index.php` (alpha.55; alpha.54 answered 404 there, and before alpha.54
the drupal, laravel and grav presets served `sub/index.php` as a file).

nginx (`index`, `try_files $uri/`), Apache (`DirectoryIndex`) and Caddy (`php_fastcgi`'s
`{path}/index.php`) choose an index by existence alone and leave the refusal to a later rule,
which answers 403 or, in a configuration that runs only `/index.php`, can hand the file out as
text; their documented configurations special-case such directories by hand (TYPO3's `location
/typo3/` without `$uri/`, a rewrite without `!-d`). Here the choice and the refusal are one
decision, and `path-check` (section 15) shows it.

**Encoded separators.** A request whose path spells a slash or a backslash as a percent
escape (`%2F`, `%5C`, in either case) is answered 404 by every location that resolves paths
on disk, static, FastCGI and CGI alike, before anything is looked up: it is Apache's
`AllowEncodedSlashes Off`, and it closes spellings such as `/x%2F..%2Fwp-login.php`, which
decoded and normalised to the script (2026-10-02). Every other escape decodes as before
(`/style%2Ecss` is `/style.css`). A proxied location hands the raw target to its origin
undecoded, as nginx does, so an application that encodes a slash inside a path segment
(GitLab's `group%2Fproject`) keeps working behind `app = "proxy"`. A PHP application behind a
front controller that does the same and reads `REQUEST_URI` itself gets `encoded_slashes =
"allow"` on its site (Apache's `NoDecode` in effect: the escape is decoded for the lookup,
`try_files` reaches `index.php`, PHP sees the raw `REQUEST_URI`); `site_update` sets it,
`agensio ctl site-update NAME --encoded-slashes allow`. nginx has no such switch: it decodes
`%2F` for files and locations always, and passes it untouched only through a plain
`proxy_pass`.

```toml
[[site]]
server_name = ["wiki.example.com"]
app = "php"
encoded_slashes = "allow"      # the application encodes slashes inside path segments
```

**Dumps served as they stand.** A static site serves every file of its root, so a database dump
left there is a download anyone can make. Health's `archives_in_root` (section 4c) searches a
static site and one without `app` for dumps: a `.sql` file that holds data (one whose statements
all define tables does not count), `.sql.gz`, `.sql.bz2`, `.sql.xz`, `.sql.zst`, `.sqlite`,
`.sqlite3`, `.db` (not Windows' `Thumbs.db`) and pg_dump's `.dump`, and any of these inside an
archive or a compression (phpMyAdmin's zipped export `export.sql.zip`, `backup.sql.tar.gz`,
`app.sqlite.gz`), which leaves it a dump. Archives (`.zip`, `.tar.gz`, ...) are not named there:
on a static site they are downloads offered on purpose. Every file found, on any site, is judged by
what a request for it gets today, the decision `path_check` explains:

| a request for the file | health |
|---|---|
| gets it, from anyone | **warn**: anyone can download it |
| is refused by the site's own `refuse` (or a managed site's `rules`) | nothing: the owner decided |
| is refused only by the preset's defaults | info: not served today, a preset change would serve it |
| gets it from some addresses or with a password only | info |
| names a path listed in `public_archives` | counted as public on purpose |

The message names each file with its path as served, and the fix offers both keys with it. What a
file is decides which: a backup or a dump nobody needs is moved out of the document root or deleted;
a file the owner publishes for download on purpose (an open dataset, a tutorial's sample database)
goes in `public_archives`; a file the application needs where it is, which nobody downloads, goes in
`refuse` (section 6b), which answers 404 for it and so also silences the finding:

```toml
[[site]]
server_name = ["data.example.com"]
app = "static"
public_archives = ["/downloads/world-cities.sql.gz", "/datasets/"]   # published on purpose
refuse = ["/backups/"]                                                 # kept in the tree, never served
```

`public_archives` serves, refuses and moves nothing, and holds exact paths and directories only (a
directory ending in `/` covers all below it; no wildcards, `*`, `?` or `[`; never `/` alone; at most
64), so a dump that lands elsewhere by mistake is still named; a directory written without its `/`
(`/db`) covers nothing below it, and the finding says so. A path listed there that the site's
`refuse` answers 404 is a contradiction `-t` and health name (`public_archive_refused`). Managed:
`site_update`'s field of the same name (the list sent whole, `[]` or `null` clears it), `agensio ctl
site-update NAME --public-archive /downloads/world-cities.sql.gz` (repeatable, the list replaced;
`--no-public-archives` clears it); `site_show` and `agensio ctl site NAME` list the current ones.

## 1b. Which site answers a request

A site answers the names in its `server_name`, compared case-insensitively and without
the port. On each listen address exactly one site may be the **catch-all**: the one with
`server_name = ["*"]`, or with `default = true`. It answers every other Host, requests
by IP address, and HTTP/1.0 requests without a Host header.

A listener **without** a catch-all is strict: a request whose Host no site on it lists
answers `421 Misdirected Request` with `Cache-Control: no-store` and a constant body.
Nothing reaches an application for a name it did not claim, so forged Host headers
(the class Drupal's `trusted_host_patterns` and Laravel's `TrustedHosts` defend
against) never get there, and an HTTP/2 client that coalesced connections retries on a
fresh one rather than caching a 404. If you want the old behaviour of "the only site
serves everything", say so with `server_name = ["*"]`, or add `default = true` to the
site. Monitors that check the IP address need the hostname, or a catch-all.

**IPv4 and IPv6 on one port.** A listener on `[::]:P` takes both families while it is the
only listener on port P. An IPv6 address has one spelling everywhere, in brackets and as the IP
stack prints it (`[::]:443`, `[2001:db8::1]:443`): the configuration, `-t --explain`, status, the
error log and health show the same text, and `site_create` or `site_update` may write it either
way (before 0.1.0-alpha.120 status and the error log printed `:::443`, and the dry run compared the
two spellings and called a port the server held "not bound yet"). Next to a listener on an IPv4 address with the same port
(`0.0.0.0:P`), IPv4 clients go to that listener's sites and `[::]:P` serves IPv6 only, as
nginx's `ipv6only=on`; a site for both lists both addresses (`listen = ["0.0.0.0:443",
"[::]:443"]`), and `-t` and health warn about a site on `[::]:P` alone next to IPv4 sites
there (`listen_ipv6_only`). With `SO_REUSEPORT` (Linux, `reuse_port = "auto"`) the kernel
routes the families so, the `[::]` socket staying dual-stack: only `0.0.0.0:P` takes every IPv4
connection, a listener on one IPv4 address (`127.0.0.1:P`) takes what is sent there and `[::]:P`
keeps the rest (so health counts only `0.0.0.0:P` as cutting a site off), and a reload that removes
the last `0.0.0.0:P` hands its IPv4 connections to `[::]:P` at once. Without it (macOS, `reuse_port =
"off"`) the `[::]` socket is opened IPv6-only beside any IPv4 listener of its port, and the two
cannot be separated on a running socket: a reload cannot add `0.0.0.0:P` next to a `[::]:P` that was
opened alone (refused, restart), and one that removes `0.0.0.0:P` leaves `[::]:P` IPv6-only until a
restart (a warning in the error log).

**TLS** follows the same rule at the handshake: the certificate is the one of the site
that lists the name the client sent (SNI), each site on a listener may have its own
certificate, and a name no site lists ends the handshake with `unrecognized_name`, so no
other site's certificate is ever shown. A client that sends no name gets the catch-all's
certificate, or is refused when the listener has none. Such refusals write no log line (there is
no request), but `agensio ctl status` counts them, `tls_handshakes_refused`, with the addresses
and listeners in `tls_handshakes_refused_detail`: a scanner probing port 443 by address shows up
there. An HTTP/1.1 request without a Host header stays a 400.

**A TLS connection is authoritative only for the names its certificate covers** (RFC 9110
section 7.4, RFC 6125 matching: the subject CN, the DNS and IP entries of the
subjectAltName, a wildcard for exactly one leftmost label). Whatever sites the listener
holds, a request whose Host the presented certificate does not name answers `421`, the
same constant answer as an unknown Host: a connection opened with `b.example`'s
certificate never serves `a.example`, and a catch-all site on a TLS listener is bounded
the same way. A certificate covering several names (a SAN or wildcard certificate) makes
every site it names reachable on one connection, which is what an HTTP/2 client's
connection coalescing relies on. The decision uses the certificate presented at the
handshake, so a renewal or reload never changes what an established connection may
serve. Plain listeners have no certificate and keep the listener rule; a request without
a Host (HTTP/1.0) claims no name and reaches the catch-all as before.

`agensio ctl status` names each listener's catch-all or `null`; `sites` marks catch-all
sites; `site-create` warns when it adds the first site to a listener without one.

## 1c. The server's addresses and a site's own

```toml
[server]
listen_tls = ["[::]:443"]      # the default: every site with tls, both IP families on one socket
listen_plain = ["[::]:80"]     # the default: every site without tls, and the redirect port beside listen_tls
```

A site that names no `listen` takes the server's addresses: `listen_tls` with `tls`, and then
`listen_plain` for the plain port that redirects to it (section 14), or `listen_plain` without
`tls`. The built-in default is `[::]`, one dual-stack socket per port that takes IPv4 and IPv6
clients alike (an IPv4 client is logged as its IPv4 address), so a new install serves both families
without anyone deciding it. Where the host cannot (no IPv6 at all, or `net.ipv6.bindv6only = 1`,
which keeps IPv4 off an IPv6 socket) the server binds `0.0.0.0` instead of, or beside, `[::]`, and
says so: `-t`, the error log and health's `ipv6_unavailable`.

The two keys are **restart-only** (section 12b): the addresses are bound at start, as root, before
the privilege drop, so no reload ever has to bind a port below 1024, and a change of the host's
addresses is one edit of the main file and one `systemctl restart agensio`, every site moving
together. Each key written in the main file opens its addresses at start whether or not a site
uses them yet, so a site created later (`site_create`) attaches by a reload; a key left out gives
its built-in default to a site that names none, opened when the first such site does (until
0.1.0-alpha.121 naming one key opened the other's default too: `[::]:443` on a host with
`listen_plain` alone, which an unprivileged instance could not bind). The package's main file names
both. A reload that finds them changed keeps the running addresses and names the keys, as it does
for every restart-only key.

A site's own `listen` replaces the server's whole, for a site that owns one address of a host with
several (`listen = ["203.0.113.5:443"]`), a loopback-only one, or another port; it is not a way to
choose a family. The kernel hands a connection to the most specific socket before a byte is read,
so a site on `0.0.0.0:443` beside sites on the server's `[::]:443` takes every IPv4 connection of
the port, and the others are reachable over IPv6 only: `-t`, the dry run and health warn
(`listen_family_split` on the site that caused it, `listen_ipv6_only` on the ones it cut off). A
site on the host's one IPv4 address apart from loopback does the same from outside, since there is
no other address the others could answer on, and is warned about the same way (the alpha.121
report); the addresses counted are those of the interfaces carrying the default route (a bridge or
a container network such as docker0 does not count, the alpha.122 report), read afresh at each
check, and a loopback address, or one of several the host has, is not warned about. The same holds
for IPv6 (the alpha.123 report): a site on the host's one global IPv6 address (not link-local, not
unique-local `fc00::/7`, of the interfaces with the default IPv6 route) takes every outside IPv6
connection of its port, and the sites on `[::]:P` answer over IPv4 only (`listen_ipv4_only` on them,
`listen_family_split` on the cause). Two ways end a
split by a specific address: every site on it hands back, or every site cut off lists it too
(`listen = ["[::]:443", "203.0.113.5:443"]`, sharing its socket; `0.0.0.0:443` ranks below the
specific socket and would change nothing). The second is offered only while every site cut off is
hand-written: a managed site takes one address of its own per kind and cannot list both, so with one
among them the hand-back is the way, and a site that already lists the address is told so rather
than told to remove its line (the alpha.123 report). Once every site cut off lists it, none is: the
sites that joined it are told nothing more, and the site with the address alone keeps a note, at
info, on what a site added later on the server's addresses would meet, which becomes a warning on
both once such a site is cut off (until 0.1.0-alpha.125 each site that had joined was warned and told
to remove the line it was told to add, the alpha.124 report). Whenever no site is cut off, the
cause's finding is info. A listen address is an IP address, one per
entry: a host name, or a list written as one value, is refused at load and by `site_create` and
`site_update` (before 0.1.0-alpha.124 `-t` passed it and the start refused it). To
keep one family out of a site, use an access rule (section 19), which answers 403 on purpose. An
address below 1024 the server does not hold cannot be added by a site's `listen` once the server
dropped root: `site_create` and `site_update` say so and give the way (the main file and a restart,
or a port above 1023); before 0.1.0-alpha.120 the dry run promised a restart the reload could not
keep (the test VPS's IPv6 report).

Managed sites (section 15) write no `listen` unless `listen_tls` or `listen_plain` was given to
`site_create` or `site_update`; `agensio ctl site-update NAME --listen-default` (MCP `listen_tls:
""`, `listen_plain: ""`) hands a site with an address of its own back to the server's. Files written
before alpha.120 carry `listen = ["0.0.0.0:443"]` and count as overrides until then, which is what
the IPv6 recipe of the cookbook walks through (`docs/examples/basics.md`). The order matters: the
main file's keys and the restart first (the server's `[::]` sockets open beside the sites' `0.0.0.0`
ones, which keep every IPv4 connection of their port: visitors notice nothing), then `--listen-default`
for every site in one go, since a site handed back answers over IPv6 only until the last leaves
`0.0.0.0:P` and that socket closes, after which the server's `[::]:P` takes IPv4 too (with
`SO_REUSEPORT`; without it a restart). In the other order the first move is refused
(`listen_unbound`): the server's `[::]:443` is not open and a reload cannot bind it. The two findings
carry this as their fix, with the sites to hand back by name.

## 2. Plain PHP: `app = "php"`

Any `.php` file under the root runs; `index.php` or `index.html` serves directories.

```toml
[[site]]
server_name = ["php.example.com"]
root = "/var/www/php-site"
app = "php"
php = { socket = "unix:/run/php/php8.4-fpm.sock" }
```

What it expands to, written by hand:

```toml
[[site]]
server_name = ["php.example.com"]
root = "/var/www/php-site"
index = ["index.php", "index.html"]
try_files = ["$uri", "$uri/", "=404"]
php = { socket = "unix:/run/php/php8.4-fpm.sock" }

[[site.location]]        # every request whose path ends in .php (also /x.php/extra: PATH_INFO)
path = ".php"
match = "suffix"
handler = "fastcgi"
```

Every `.php` under the root runs, wherever it sits, and a request for a directory runs its
`index.php` whatever the method: a form posted to `/` or `/sub/` (Roundcube's and Kanboard's logins)
reaches the script, as with nginx's `index` and Apache's `DirectoryIndex` (0.1.0-alpha.130; before,
anything but GET, HEAD and OPTIONS answered 405 there). A directory whose index is a static file still
answers 405 to a POST. For an application that lets its users
upload files, name the scripts that run (exact `fastcgi` locations and a `.php` suffix location
with `handler = "deny"`, or `rules.entry_points` on a managed site; section 15), or refuse
`.php` where the uploads go (`refuse = ["/uploads/**/*.php"]`, section 6b): health says
`php_any_script_runs` (information) until a site does one or the other.

**The project's public directory: `served_dir`.** An application that keeps `index.php` and
its assets in `public/` and its code, `vendor/` and `.env` beside it names the project as `root`
and the served directory in `served_dir`:

```toml
[[site]]
server_name = ["app.example.com"]
root = "/var/www/app.example.com/app"   # the project directory
served_dir = "public"
app = "php"
user = "app"
tls = "auto"
```

Requests are answered from `/var/www/app.example.com/app/public` (`DOCUMENT_ROOT`, the scripts'
paths), and nothing outside it has a URL. The project stays the site's directory: PHP's
`open_basedir` starts there, so `require __DIR__ . '/../src/Kernel.php'` works, `site-install`
unpacks into it, health reads its `composer.json` for the PHP the application needs (section
7b), and its `.env` and `.git` are held to the hosting rules as credentials (section 11).
`served_dir` is a plain relative path at any depth, up to 255 characters (`public`,
`web/public`, `apps/shop/public`: no `..`, no segment starting with `.`, no `/` at either end) and only for `app = "php"`, since the other PHP presets know
their own directory; one that exists must stay inside the project once its symlinks are
resolved. A served directory that does not exist yet loads (the install brings it) and answers
404, and health says `served_dir_missing` until it is there. Managed: `served_dir` of
`site_create` and `site_update` (`agensio ctl --served-dir DIR`; `""`, `--no-served-dir`, serves
the root itself, and a change of `app` away from `php` sends it, as `--no-env-file`,
`--no-project` and `--no-entry` empty the other presets' fields: 0.1.0-alpha.133);
`site_show` gives both directories (`served_dir`, `project_directory`). The cookbook recipe:
[A PHP application with a public/ directory](examples/php.md#a-php-application-with-a-public-directory).

## 3. Laravel: `app = "laravel"`

`root` is the project directory; the preset serves its `public/`.

```toml
[[site]]
server_name = ["app.example.com"]
root = "/var/www/app"
app = "laravel"
php = { socket = "unix:/run/php/php8.4-fpm.sock" }
```

Equivalent by hand:

```toml
[[site]]
server_name = ["app.example.com"]
root = "/var/www/app/public"
index = ["index.php"]
try_files = ["$uri", "$uri/", "/index.php?$query_string"]
php = { socket = "unix:/run/php/php8.4-fpm.sock" }

[[site.location]]        # the front controller is the only script that ever runs (also
path = "/index.php"      # /index.php/extra, with PATH_INFO /extra: section 6)
match = "exact"
handler = "fastcgi"

[[site.location]]        # everything else: static files, or the front controller; PHP in
path = "/"               # any spelling is refused (404), never executed, never served as source,
deny_suffixes = [".php", ".phtml", ".phar", ".pht", ".phtm", ".php2", ".php3", ".php4", ".php5", ".php6", ".php7", ".php8", ".phps",
                 ".inc", ".bak", ".orig", ".save", ".swp", ".swo", "~"]   # and .inc and editor backups too

[[site.location]]        # Vite output is content-hashed: cache it for a year
path = "/build/"
try_files = ["$uri", "=404"]
deny_suffixes = [...the same list...]
add_headers = { "Cache-Control" = "public, max-age=31536000, immutable" }
```

Why it is shaped like this: a Laravel application has exactly one entry point. A
request for any other `.php` under `public/`, existing or not, answers 404 from the
static handler before anything is read from disk, so a stray or uploaded `.php` file is
neither a code-execution path nor a download of its source (2026-09-19: before this
rule an existing second `.php` was served as a file). An application with several
entry points is not Laravel; use `app = "php"` (with `rules.entry_points` on a managed
site, section 15), or `app = "drupal"` for Drupal (section 4c).
Dotfiles (`.env`) stay hidden by the site default. `public/storage` is a symlink into the project, which is
why `symlinks = "allow"` is the default; set `symlinks = "deny"` on sites that have no
such link.

**Tasks** (2026-11-04, the grabloop.app report): a Laravel site, `app = "laravel"` or a Laravel
application on `app = "php"`, has artisan's own commands as site tasks (section 15, `site-task`):
`migrate_force` (`migrate --force`), `optimize`, `optimize_clear`, `storage_link`, `queue_restart`,
`schedule_run`, `schedule_clear_cache` (`schedule:clear-cache`, below) and `queue_work_once`
(`queue:work --stop-when-empty --max-time=50`), each a fixed argv, never a command a release declares. They run as the site's account in the directory that holds
`artisan`: the project for `app = "laravel"`; for `app = "php"` the nearest directory from
`served_dir` up to the project (`releases/<id>/` for `served_dir = "releases/<id>/public"`), never
reached through a symlink, and a site with no `artisan` there is refused before anything runs. So
`served_dir` names the release itself: a `current` link to it (Deployer's and Envoyer's layout) is
not followed, and the refusal, the scheduler's and the task list name the link (before
0.1.0-alpha.125 they said "no Laravel application"). The
interpreter is the command-line binary of the site's own PHP version (`/usr/bin/php8.5`, from the
runtimes agensio found, or `cli` in root's `[php.runtimes]`), never the host's default `php`; a
version without one answers with root's package line (`php8.5-cli`). They run in the live release,
the one `served_dir` names, so after a switch `migrate_force` runs the new release's migrations.

**Its .env** (2026-11-04, the grabloop.app answer): the site key `env_file` names the application's
`.env`, relative to the project (`.env` by default for `app = "laravel"`, none for `app = "php"`, where
`shared/.env` beside the releases is the usual place), outside the directory the site serves. `site-env`
lists its names, lengths and fingerprints, a value only on request; `site-env-set` changes it through
the root helper, keeping every line it does not change: the file is root's with the group PHP runs
the site as, `0640`, so the application reads it and neither the site's account nor a compromised
application changes it in place (`artisan key:generate` cannot rewrite it: `--generate APP_KEY` writes
Laravel's key, `base64:` and 32 random bytes). A value is written as phpdotenv reads it back (plain,
in single quotes, or in double quotes), and a name whose value goes over several lines is refused
rather than rewritten, as is any change to a file with a quote never closed (phpdotenv cannot read
it, and the lines after the quote belong to that value: the answer names the line to fix with
`site_file_edit`). A name in both `--unset` and `--generate` is rotated where its line was. Every
change is read back before it is written. A configuration cached by the `optimize` task reads `.env` again only after
`optimize` runs again; the answer says so. A generated password of a service the application connects
to (`DB_`, `REDIS_` or `MAIL_` with `PASSWORD` in the name) is new to that service too: the approval's
preview says so, and the answer's first step is root's, setting the same password there, with the
`grep` line that prints the value on root's terminal; `optimize` comes after. A rotated `APP_KEY` signs
every user out and leaves what the application encrypted with the old key unreadable (Laravel 11 and
later read old keys from `APP_PREVIOUS_KEYS`); the preview and the answer warn. `--dry-run` checks the
change as the write would and writes nothing; a dry run needs no `--yes`. Names are upper-case: a line
of the `.env` under another name (phpdotenv reads lower-case ones too) is changed with `site_file_edit`.

**The scheduler** (2026-11-04): `agensio ctl site-unit NAME` on a Laravel site renders two units for
root to install once, `agensio-schedule-NAME.timer` (every minute) and the oneshot
`agensio-schedule-NAME.service` it starts, which runs `agensio ctl site-task NAME schedule_run
--scheduled` as the server's own account over the control socket. agensio then runs `php artisan
schedule:run` like any of the site's tasks: as the site's account, in the live release, with the site's
PHP version, so nothing in the units names a release and a switch needs nothing of root. A scheduled
run holds no task slot (a deploy's `migrate_force` is never refused for it), is skipped while a task
runs on the site or the previous minute's still runs, keeps its record apart from the deploy's output,
and is named in the audit log only when its outcome changes; `ctl --scheduled` prints the run's record,
which systemd keeps in the journal, only for a run that failed, was skipped or changed the outcome, so a
quiet minute leaves systemd's own lines alone; a skipped run exits 0, so systemd does not record the
unit as failed for each minute a deploy's task runs (until 0.1.0-alpha.127 it exited 1). `site-service NAME` says whether a
scheduler exists before anyone makes another: agensio's timer as installed, any cron line that runs
`schedule:run` for the site (the account's crontab, `/etc/crontab`, `/etc/cron.d`, named by file and
line, never by text), and the runs agensio recorded; health warns `site_schedule_duplicate` when two
run (every scheduled command would run twice), `site_schedule_failing` when the last run failed, and
notes `site_schedule_unit_stale` when the installed units are not what agensio renders now.

A scheduled run ends with whatever it started, as every task does (section 15): a command with
`runInBackground()` is ended the moment `schedule:run` exits, not left running as cron would leave it.
With `withoutOverlapping()` as well, its lock then stays behind and the scheduler skips the command
until the lock expires, a day by Laravel's default; the task `schedule_clear_cache` removes such
locks. Such a command drops `runInBackground()` (the commands after it in the minute then wait for it,
and a minute that runs past the next start skips that one) or dispatches its work to the queue.
`site-service NAME` names the command when a recorded run started one in background (Laravel 9 and
later print `Running [COMMAND] in background`), with these steps (0.1.0-alpha.127, the alpha.126
report), and health warns `site_schedule_background` with the command and the same steps for a day
after the last run that started one (0.1.0-alpha.128): such a run is quiet and ok, so the scheduler's
journal says nothing of it.

**Statamic** is a Laravel application: use `app = "laravel"` unchanged. Its control panel
uploads and PATCH/DELETE requests all go through `/index.php`. Raise
`[server] max_body_size` (default 1 MB) for asset uploads.

## 4. WordPress: `app = "wordpress"`

```toml
[server]
max_body_size = "64MB"    # media uploads (a server-wide setting)

[[site]]
server_name = ["blog.example.com"]
root = "/var/www/blog"
app = "wordpress"
php = { socket = "unix:/run/php/php8.4-fpm.sock" }
```

Equivalent by hand:

```toml
[[site]]
server_name = ["blog.example.com"]
root = "/var/www/blog"
index = ["index.php"]
try_files = ["$uri", "$uri/", "/index.php?$query_string"]   # pretty permalinks
php = { socket = "unix:/run/php/php8.4-fpm.sock" }

[[site.location]]        # wp-login.php, wp-admin/*.php, wp-cron.php, plugin endpoints
path = ".php"
match = "suffix"
handler = "fastcgi"

[[site.location]]        # everything else: static files or the front controller; PHP in a spelling
path = "/"               # the suffix location does not take (x.PHP, x.phtml), .inc and editor backups
deny_suffixes = [".php", ".phtml", ".phar", ".pht", ".phtm", ".php2", ".php3", ".php4", ".php5", ".php6", ".php7", ".php8", ".phps",
                 ".inc", ".bak", ".orig", ".save", ".swp", ".swo", "~"]

[[site.location]]        # nothing under uploads is ever executed; files are cacheable
path = "/wp-content/uploads/"
final = true             # nginx ^~: the .php suffix location is not consulted here
deny_suffixes = [...the same list...]
try_files = ["$uri", "=404"]
add_headers = { "Cache-Control" = "public, max-age=604800" }

[[site.location]]        # core assets: same shield, longer cache
path = "/wp-includes/"
final = true
deny_suffixes = [...the same list...]
try_files = ["$uri", "=404"]
add_headers = { "Cache-Control" = "public, max-age=2592000" }

[[site.location]]        # WordPress's hardening guide: never reached from the web
path = "/wp-admin/includes/"
final = true
handler = "deny"         # 404 whatever exists; likewise /wp-includes/theme-compat/

[[site.location]]        # the admin's static files: served, nothing runs (no Cache-Control added);
path = "/wp-admin/css/"  # likewise /wp-admin/js/ and /wp-admin/images/
final = true
deny_suffixes = [...the same list...]
try_files = ["$uri", "=404"]
```

`wp-admin/includes/` and `wp-includes/theme-compat/` answer 404 and never run (since
alpha.53), the two directories WordPress's "Hardening WordPress" guide blocks besides
`wp-includes/` itself: their scripts are libraries loaded by WordPress, and run directly
they print errors that name paths. `wp-content/plugins` is deliberately not shielded: some
plugins expose PHP endpoints there. `wp-config.php`, `wp-config-sample.php`, `readme.html`, `license.txt` and the
`wp-content` drop-ins `db.php`, `advanced-cache.php` and `object-cache.php` are answered
404 by exact locations the preset adds (`try_files = ["=404"]`): the credentials file is
never executed nor shown, whereas nginx recipes usually execute it (it prints nothing);
the readme and the licence name the installed WordPress version, the first thing a
vulnerability scanner reads, and cost nothing to withhold; the drop-ins run only inside
WordPress's own bootstrap and answer 500 when fetched directly. `.htaccess`, `.user.ini`
and the SQLite plugin's `wp-content/database/.ht.sqlite` are dotfiles and hidden. agensio
never reads `.htaccess`; see section 4c.

**Backups of those names are the same 404.** `wp-config.php~`, `wp-config.php.bak`,
`.save`, `.orig`, `.txt`, `.old`, `.dist`, `wp-config.bak`, `wp-config.txt`,
`.wp-config.php.swp` (vim), `#wp-config.php#` (emacs), `wp-config.php-old`, in any case:
every name a preset never serves is protected in every backup spelling within its
directory, without configuration and whatever `hidden_files` says. The rule is anchored
on the name, not on an ending, so `ads.txt`, `security.txt` and every other public file
are untouched, and `/readme`, `/license` and `/license-agreement` stay permalinks
(2026-09-20: a live host served `wp-config.php~` and four other backups with the database
password and the salts in them; the exact name was 404). The presets catalogue
(`agensio ctl presets`, MCP `presets_list`) states the rule.

## 4c. Drupal: `app = "drupal"`

```toml
[[site]]
server_name = ["drupal.example.com"]
root = "/var/www/drupal"            # the composer project; its web/ is served (a tarball without web/ is served as is)
app = "drupal"
php = { socket = "unix:/run/php/php8.4-fpm.sock" }
```

expands to:

```toml
root = "/var/www/drupal/web"
index = ["index.php"]
try_files = ["$uri", "$uri/", "/index.php?$query_string"]   # pretty paths reach the front controller

[[site.location]]        # Drupal's own rule: a script directly in / runs (index.php, update.php)
path = ".php"            # (shown by --explain as "only a script directly in /"; a preset rule,
match = "suffix"         #  not a key a hand-written site can set)
handler = "fastcgi"

[[site.location]]        # and a script directly in /core/ (install.php, authorize.php, rebuild.php)
path = ".php"
match = "suffix"
handler = "fastcgi"      # "only a script directly in /core/"

[[site.location]]        # the one deeper script Drupal's .htaccess lets run
path = "/core/modules/statistics/statistics.php"
match = "exact"
handler = "fastcgi"

[[site.location]]        # what Drupal's .htaccess protects, refused natively (404): PHP source in its
path = "/"               # other spellings, templates, translations, dumps, editor backups
deny_suffixes = [".inc", ".bak", ".orig", ".save", ".swp", ".swo", "~", ".log", ".sql",   # the shared list (below)
                 ".install", ".module", ".theme", ".engine", ".profile", ".make", ".po", ".twig", ".yml", ".yaml",
                 ".sqlite", ".sqlite3", ".db", ".tpl", ".xtmpl", ".sh",                      # Drupal's own
                 "/composer.json", "/composer.lock", "/package.json", "/package-lock.json",  # these names in any
                 "/yarn.lock", "/web.config"]                                                # directory

# final prefixes (nginx ^~): nothing PHP-like under library, vendor and upload directories
[[site.location]]  path = "/core/lib/"             final = true  try_files = ["$uri", "=404"]  deny_suffixes = [...php and the list above...]
[[site.location]]  path = "/core/includes/"        final = true  (same)
[[site.location]]  path = "/vendor/"               final = true  (same)
[[site.location]]  path = "/node_modules/"         final = true  (same)
[[site.location]]  path = "/sites/default/files/"  final = true  (same)

# never answered, whatever is on disk (404, existence not disclosed)
[[site.location]]  path = "/sites/default/settings.php"  match = "exact"  try_files = ["=404"]
# likewise settings.local.php, default.settings.php, services.yml, default.services.yml,
# composer.json, composer.lock, package.json, package-lock.json, yarn.lock, web.config,
# and autoload.php (Drupal's .htaccess refuses it by name: it is a script directly in /)
```

**Which PHP runs is Drupal's own rule** (since alpha.53, from the `.htaccess` that Drupal 10
and 11 ship): a script directly in the web root (`index.php`, `update.php`), a script
directly in `core/` (`install.php`, `authorize.php`, `rebuild.php`) and
`core/modules/statistics/statistics.php`; `autoload.php` and every other `.php` (a
module's, a theme's, a library's, anything a plugin left under `modules/` or `themes/`) is
refused with 404 and never reaches php-fpm, in any case spelling. PATH_INFO after a script
that runs still works (`/index.php/node/1`). Before alpha.53 any `.php` ran, as most nginx
recipes for Drupal do; a module's stray script was then executable from the web. A module
whose documentation asks for a script of its own to be reachable (Drupal's `.htaccess`
says to copy the statistics line for it) gets an exact `handler = "fastcgi"` location in
the site's root additions (section 15).

`.htaccess`, `.ht.sqlite` (Drupal's SQLite database), `.env` and `.git/` are dotfiles and
stay hidden by the site default. A `.php` that does not exist answers 404 before php-fpm.
`composer.json`, `package.json`, `yarn.lock`, `web.config` and `.sh` scripts are refused in
any directory, as the `FilesMatch` of Drupal's `.htaccess` refuses them.

**agensio never reads `.htaccess`.** Applications that ship one (Drupal, WordPress,
Joomla, most PHP software) rely on it for exactly these refusals under Apache; under
agensio the preset provides them, and a hand-written site for such an application must
provide its own. The list above is the subset of Drupal's `.htaccess` that matters:
source disclosure and execution of files that are not entry points. Drupal's other
rules (canonical redirects, caching headers) are optional and can be added as locations.

The preset is Drupal's. An application with a front controller and several `.php` entry
points of its own that are not where Drupal keeps them (Kanboard, phpBB) takes `app =
"php"`, where any `.php` runs, narrowed with `rules.entry_points` on a managed site
(section 15).

A file below `sites/default/files/` that exists is served statically, cached like any
asset; one that does **not** exist reaches `index.php` with its query string, because
that is how Drupal makes image-style derivatives (`styles/<style>/public/...?itok=...`)
and rebuilds aggregated `css/` and `js/` after a cache rebuild: Drupal's own `.htaccess`
does the same. PHP-like endings below `files/` stay refused with 404 and never reach
PHP, whether the file exists or not; the refusal ignores case and trailing dots
(`x.PHP`, `x.PhP`, `x.php.`), covers `.php`, `.phtml`, `.phar`, `.pht`, `.phtm`,
`.php3` to `.php8`, `.phps`, Drupal's source spellings and editor backups (`~`, `.bak`,
`.orig`, `.save`, `.swp`), and a `.php.jpg` is a jpg (2026-09-20: upper-case and
trailing-dot spellings were served as source). (2026-09-20: a deleted derivative was answered 404
by the server for ever; the other shields, `core/lib/`, `vendor/`, keep answering 404
for a miss.)

**One list for every PHP preset.** Besides the PHP spellings, every preset's root and
every shield refuse `.inc` (the include suffix PHP code ships as; a bare Apache serves it
as text), editor or copy backups of anything: `.bak`, `.orig`, `.save`, `.swp`,
`.swo`, `~`, and since alpha.20 logs and database dumps, `.log` and `.sql` (2026-09-23:
a Grav site's `logs/grav.log` named the backup archive next to it; WordPress's
`wp-content/debug.log` is the classic). A hand-written location still serves any of them
where a site means to. Drupal's list is that plus its own spellings. The root refuses the PHP
spellings too, on every preset: when every `.php` runs, the suffix location takes the
exact spelling first, so what reaches the root is `x.PHP` or `x.phtml`, which nothing
runs and which would otherwise be served as source. The integration suite plants one
table of spellings under every preset's shields and roots and asserts each is refused
(2026-09-20: testing each preset against its own list had let WordPress fall behind
Drupal, and `x.inc`, `x.php~` under `wp-content/uploads` were served as source). And
every name a preset never serves (section 4, WordPress) is refused in every backup
spelling: `settings.php~`, `settings.php.bak`, `settings.bak`, `.settings.php.swp`.

**The preset must be the application's.** A site whose files belong to another
application than its `app` says gets that application's refusals and none of its own:
run on the drupal preset, a Grav site served its `logs/grav.log` (before `.log` was on
the shared list) and, named in it, the `backup/*.zip` with the admin account and the
signing salt inside (2026-09-23, a live host). `health` reports such a site as
`preset_mismatch` with the application it detected (`bin/grav` and `system/defines.php`
for Grav, `artisan`, `core/lib/Drupal.php`, `wp-config.php`) and the `app` to set;
`site-create` warns the same way when the directory already holds files. Backup
archives and database dumps under any served tree (`.zip`, `.tar.gz`, `.7z`, `.sql`, `.sql.gz`
and the other compressed dumps, `.sqlite`, `.db`, `.dump`, ...) are reported as
`archives_in_root`, whatever the preset refuses today: nothing served should hold a copy of the
site. Each is judged by what a request for it gets today: a warning when anyone can download it,
information when only the preset's defaults keep it or only some reach it, nothing when the site's
own `refuse` covers it (section 1, with `public_archives` for the files published on purpose). A
static site and one without `app` are searched for the dumps alone. A file an application writes itself is
not counted either: on a Grav site the API plugin's `user/data/grav-security-probe.zip` (32 bytes,
up to 1 KB taken), which it writes to check that `user/data/` stays private and writes again when
it is deleted; a larger file of that name, or any other archive there, still is. The SQL an application ships with its code is not
counted: TYPO3's `ext_tables.sql` and `ext_tables_static+adt.sql` in an extension's directory
(beside its `ext_emconf.php` or `composer.json`), and an uncompressed `.sql` file of up to 64 KB
whose statements all define tables (`CREATE TABLE`, `CREATE INDEX`, `CREATE VIEW`, `ALTER TABLE`,
`DROP TABLE`, `DROP INDEX`, `DROP VIEW`; comments aside), which holds no rows and no credential; a
table made from a query or from values (`CREATE TABLE s AS SELECT 'sk_live_...'`, MySQL's `CREATE
TABLE s SELECT ...`, `CREATE TABLE s AS VALUES (...)`) and a view whose body holds a `'...'` literal
carry data and count, while a quoted `DEFAULT` and a generated column do not. A
larger file, a compressed one, one that ends inside a quote and one with any other statement
(`INSERT`, `UPDATE`, `COPY`, `SET`, `GRANT`, `CREATE USER ... IDENTIFIED BY`, MySQL's `/*! ... */`
lines) is.

## 4d. Grav: `app = "grav"`

```toml
[[site]]
server_name = ["grav.example.com"]
root = "/var/www/grav"              # the Grav directory itself (index.php, system/, user/)
app = "grav"
php = { socket = "unix:/run/php/php8.4-fpm.sock" }
```

expands to Grav's own nginx recipe and its user-folder-exposure guidance
(https://learn.getgrav.org/2/security/user-folder-exposure), which deny directories rather
than endings wherever a directory is private:

```toml
index = ["index.php"]
try_files = ["$uri", "$uri/", "/index.php?$query_string"]   # every page route reaches the front controller

[[site.location]]        # only index.php runs; any other .php is refused (404), never served as source
path = "/index.php"
match = "exact"
handler = "fastcgi"

[[site.location]]        # the root: PHP spellings, .inc, editor backups, .log and .sql refused
path = "/"
deny_suffixes = [".php", ".phtml", ..., ".inc", ".bak", ".orig", ".save", ".swp", ".swo", "~", ".log", ".sql"]

# never answered, whatever they hold: Grav's recipe denies these directories whole, and a
# backup archive under backup/ is the site (accounts, salt, configuration, pages); user/config/
# and user/env/ hold the configuration and the signing salt, webserver-configs/ the recipes
[[site.location]]  path = "/logs/"    final = true  try_files = ["=404"]     # handler = "deny"
[[site.location]]  path = "/logs"     match = "exact"  try_files = ["=404"]  # the bare name: no redirect confirms the directory
# likewise /backup/, /cache/, /bin/, /tests/, /tmp/, /webserver-configs/, /user/config/, /user/env/

# assets only below system/ and vendor/ (css, js, images, fonts): no source, templates,
# configuration, documentation or json
[[site.location]]  path = "/system/"  final = true  try_files = ["$uri", "=404"]
                   deny_suffixes = [...the root's list..., ".txt", ".xml", ".md", ".html", ".htm", ".shtml", ".shtm", ".json",
                                    ".yaml", ".yml", ".pl", ".py", ".cgi", ".twig", ".sh", ".bat"]
[[site.location]]  path = "/vendor/"  (same)

# user/: images, css, js, fonts and uploads are served; pages (.md), accounts and
# configuration (.yaml, .json), templates (.twig) and scripts are not
[[site.location]]  path = "/user/"    final = true  try_files = ["$uri", "=404"]
                   deny_suffixes = [...the root's list..., ".txt", ".md", ".json", ".yaml", ".yml", ".pl", ".py", ".cgi", ".twig", ".sh", ".bat"]

# user/accounts/ answers avatar images and nothing else (the account files sit beside them;
# svg stays out on purpose, a stored-XSS vector); user/data/ answers public media, documents,
# fonts, css and js and nothing else (Flex objects keep their data there). A directory or a
# bare name below either is 404 too.
[[site.location]]  path = "/user/accounts/"  final = true  try_files = ["$uri", "=404"]
                   allow_suffixes = [".jpg", ".jpeg", ".png", ".gif", ".webp", ".avif", ".bmp", ".ico"]
[[site.location]]  path = "/user/data/"      final = true  try_files = ["$uri", "=404"]
                   allow_suffixes = [".jpg", ".jpeg", ".png", ".gif", ".webp", ".avif", ".bmp", ".ico", ".mp4", ".webm", ".ogg", ".ogv",
                                     ".mov", ".mp3", ".wav", ".m4a", ".flac", ".pdf", ".woff2", ".woff", ".ttf", ".otf", ".eot", ".css", ".js"]

# the public caches images/ (derivatives) and assets/ (pipelined css and js): scripts are
# never run or served there, and a missing file reaches the front controller, which makes it
[[site.location]]  path = "/images/"  final = true  try_files = ["$uri", "/index.php?$query_string"]
                   deny_suffixes = [...the root's list..., ".pl", ".py", ".cgi", ".sh", ".bat"]
[[site.location]]  path = "/assets/"  (same)

# never answered although present (404): the version fingerprints, composer files and the
# markdown files the release ships at the root
[[site.location]]  path = "/LICENSE.txt"  match = "exact"  try_files = ["=404"]
# likewise composer.json, composer.lock, nginx.conf, web.config, htaccess.txt, CHANGELOG.md,
# README.md, CONTRIBUTING.md, CODE_OF_CONDUCT.md, SECURITY.md, user/config/security.yaml (the
# signing salt; the preset's `secret`)
```

Two things Grav's recipe leaves to the operator stay so here. Media under `user/pages/` is
served directly, because Grav's `pages.media_route_urls` is off by default (a hand-written
`[[site.location]]` for `/user/pages/` with `try_files = ["=404"]` hands it to the page
route once that setting is on). And `.md` is refused by name at the root rather than by
ending, because a page route that ends in `.md` is Grav's Markdown output, not a file.

`.htaccess` and `.git/` are dotfiles and stay hidden by the site default. Grav's
processed images (`images/`), the asset pipeline (`assets/`) and theme and plugin assets
under `user/` are plain files and cache like any other. The admin plugin's routes
(`/admin`) are pages and reach `index.php`. `site-install` fetches the newest
`grav-admin` release from getgrav.org (`--version 1.7.48` for a release); the site's
directory is Grav's own, no `public/`. Health looks at `user/pages` first for
unreadable uploads. What every `never` name gets (section 4c) applies here: backups of
`security.yaml` in any spelling are refused.

## 4b. Proxied applications: `app = "proxy"`

Node, Rails, Go, Java, Python: anything that speaks HTTP on a local port. `root` is not
needed; hand-written locations serve files from disk next to the proxied application.

```toml
[[site]]
server_name = ["app.example.com"]
app = "proxy"
upstream = "http://127.0.0.1:3000"        # or a list: round-robin with health marking
proxy = { read_timeout = 120 }            # defaults for every proxied location of the site

[[site.location]]                         # optional: assets straight from disk
path = "/assets/"
alias = "/srv/app/public/assets"
add_headers = { "Cache-Control" = "public, max-age=31536000, immutable" }
```

Equivalent by hand: one `[[site.location]]` with `path = "/"`, `handler = "proxy"` and the
site's upstreams and options. WebSockets, redirects pointing at the origin, forwarded
headers and keep-alive need nothing (section 12). Worked examples for Node, Rails,
Django, Rocket.Chat and ThingsBoard are recipes in [the cookbook](examples/proxy.md); two real applications run this
way in the repository's test beds, Redmine (Rails) in `bench/redmine/` and Uptime Kuma
(Node, Socket.IO over WebSockets) in `bench/uptime-kuma/`.

On a proxy site `root` is optional and nothing is served from it: every request goes to
the upstream. When it is given, it is the application's directory, which `site-install`
fills and the hosting rules check (section 11).

**Ruby on Rails: `app = "rails"`.** The same routing as `proxy` (every request to the
site's upstream, where Puma listens), plus what a Rails application needs from the
control plane: `root` is required and is the project directory, by convention `app/`
beside `web/` in the site's tree (`/var/www/example.com/app`, what `site-create`
suggests), and the preset's named tasks run there as the site's account (section 15,
`site-task`): `gem_install_rails`, `rails_new`, `bundle_install`, `db_prepare`,
`db_migrate`, `assets_precompile`. Its credential files, `config/master.key`,
`config/credentials/`, `config/database.yml`, `config/secrets.yml` (the `secret_key_base`
of applications from before Rails 5.2's credentials) and `storage/` (the SQLite databases
and Active Storage's files), are held to the hosting rule of section 11 like `wp-config.php`
is, and every writer and task leaves them the site's alone. A site with its own `user`
and `app = "rails"` gets no php-fpm pool. Nothing is served from the project directory
yet: every request goes to Puma, and Rails' own public file server answers what lies in
`public/` (serving it from disk is step 7 of `docs/design-site-operations.md`). The paths
scanners probe are answered 404 by agensio itself and never reach the application:
`/config/master.key`, `/config/database.yml`, `/config/secrets.yml`,
`/config/credentials.yml.enc`, `/config/credentials/`, `/.env`, `/.env.production`,
`/.kamal/`, `/.git/`, `/Gemfile`, `/Gemfile.lock`, `/log/production.log` and everything
below `/storage/` (Rails keeps its
databases and Active Storage's disk files there and routes none of it; Active Storage
answers under `/rails/active_storage/`), and any path ending in `.sqlite3`,
`.sqlite3-wal`, `.sqlite3-shm`, `.sqlite3-journal`, `.log`, `.key` or `.sql`, the ending in
any case, wherever the application keeps its files (the `/storage/` prefix is matched as
written, as every path is; `/Storage/db/production.sqlite3` is refused by its ending) (Writebook's database is
`storage/db/production.sqlite3`). `presets` lists them under `never_served`; a hand-written
location of the same path wins, and a hand-written `/` location replaces the endings too. Every task prints
"Using vips to process variants requires the libvips library" until `libvips42` is
installed; only Active Storage's image variants need it.

```toml
[[site]]
server_name = ["ag5.example.com"]
tls = "auto"
app = "rails"
root = "/var/www/ag5.example.com/app"   # the project directory: tasks run here, nothing is served from it
user = "ag5"
upstream = "http://127.0.0.1:3000"      # where Puma listens; keep it on loopback
```

The application server itself is not started by agensio yet (roadmap F14): until then a
systemd unit runs Puma as the site's account with the environment the tasks use, rendered
for the site by `agensio ctl site-unit NAME` (MCP `site_service_unit`): its account, its
directory, the loopback port of its `upstream`, the Ruby of `[control] runtimes` first on
`PATH` and in `ExecStart` (the one its bundle was built with), and the site's environment
file. Root puts it in place:

```sh
agensio ctl site-unit ag7.example.com --out /etc/systemd/system/agensio-app-ag7.service
systemctl daemon-reload && systemctl enable --now agensio-app-ag7.service
```

It binds loopback (`-b tcp://127.0.0.1:3007`; the `puma.rb` Rails generates binds every
address, which would publish the application beside agensio, without its TLS and
refusals) and loads the site's environment file (section 15, "The site's environment"),
so a secret is written once, through the control plane, and the tasks and Puma both see
it. The unit is refused for a site without its own account or whose upstream is not
plain HTTP on loopback, and every value in it must be a plain path or name, so nothing
can add a line to it. `docs/examples/puma.service` is the same unit written by hand.
`agensio ctl site-service NAME` (MCP `site_service_status`) says whether it runs,
`site-service-logs NAME` (MCP `site_service_logs`, admin) shows its journal, and `health`
reports every Rails site whose unit is missing (`site_service_missing`, info), stopped
(`site_service_down`) or failing (`site_service_failed`), all read through the
provisioning helper. Starting, stopping and restarting the unit stays root's: after a
task that changes what the application loads (`bundle_install`, `db_migrate`,
`assets_precompile`) the task's answer carries the restart line.

An existing application (a GitHub release tarball, an upload) goes in with `site-install`,
then `bundle_install`, `db_prepare` and `assets_precompile`. One that ships
`config/database.yml.example` and no `config/database.yml` first gets its database:
`site-env-set NAME --set DATABASE_URL=sqlite3:db/production.sqlite3` (or
`postgresql://USER:PASSWORD@HOST/NAME`, `mysql2://...`), then the task `database_config`,
which writes `config/database.yml` from a fixed template (the database from
`DATABASE_URL`, the adapter from its scheme, no password in the tree; `0600`, only when the
file is missing); `bundle_install` then bundles the matching driver where the Gemfile reads
`database.yml`, and a `bundle_install` that exits 0 while the application says it found no
database configuration answers 409. The install's answer says so (its `facts` name
`database_yml` and `database_yml_example`),
names the Ruby the application pins in `.ruby-version` when it has one, and, when the
archive came without Rails credentials (`config/credentials.yml.enc`, as every ONCE
application such as Writebook and every Kamal deployment), generates `SECRET_KEY_BASE`
into the site's environment, once. A new site's answer also states its request-body
limit: 1 MB unless `settings.max_body_size` raises it, and an upload above it is a 413 the
application never sees (the error log names the site, the size and the limit).

**Redmine: `app = "redmine"`.** The rails preset's routing, refusals and tasks for an
application installed from an archive (`gem_install_rails` and `rails_new` are not
offered), plus Redmine's own: `gemfile_local` writes the fixed `Gemfile.local` Redmine's
Gemfile evaluates, adding Puma (Redmine keeps it in its test group, which the tasks'
`BUNDLE_WITHOUT` skips); `load_default_data` loads trackers, statuses and roles in one
language (`--param lang=en`); `plugins_migrate` runs the migrations of `plugins/` after a
plugin's `site-install --path plugins/NAME --create-path` and `bundle_install`. Its
credential files are `config/database.yml`, `config/configuration.yml` (SMTP) and
`config/initializers/secret_token.rb`. `site-install --version 7.0.1` fetches
`https://www.redmine.org/releases/redmine-7.0.1.tar.gz` (a version is required; pass the
`--sha256` redmine.org publishes). A Redmine archive installed on a `rails` site is named
in the answer's warnings. The whole path, which `tests/redmine-install.sh` runs:

```sh
agensio ctl site-create --domain pm.example.com --app redmine --root /var/www/pm.example.com/app --user pm --upstream http://127.0.0.1:3007 --yes --reason redmine
agensio ctl site-install pm.example.com --version 7.0.1 --sha256 <redmine.org's> --yes --reason redmine
agensio ctl site-env-set pm.example.com --set DATABASE_URL=sqlite3:db/production.sqlite3 --yes --reason redmine
for t in database_config gemfile_local bundle_install db_migrate; do agensio ctl site-task pm.example.com $t --yes --reason redmine; done
agensio ctl site-task pm.example.com load_default_data --param lang=en --yes --reason redmine
agensio ctl site-task pm.example.com assets_precompile --yes --reason redmine
agensio ctl site-unit pm.example.com --out /etc/systemd/system/agensio-app-pm.service   # as root, then enable it
```

## 4e. Django and Wagtail: `app = "django"`, `app = "wagtail"`

A Django project runs under Gunicorn on a loopback port; agensio serves its `/static/`
(what `collectstatic` gathers) and `/media/` (uploads) from the project directory, since
Gunicorn serves no files, and sends every other request to Gunicorn. `wagtail` is built on
`django` as `redmine` is on `rails`: the same routing and tasks, plus Wagtail's own. `root`
is the project directory (where `manage.py` lives) and `project` names the project's Python
package (`NAME/settings`, `NAME/wsgi.py`), required for both presets: a new project is
created under that name, an installed one must match its own.

```toml
[[site]]
server_name = ["ag8.example.com"]
tls = "auto"
app = "wagtail"
root = "/var/www/ag8.example.com/app"   # the project directory; only static/ and media/ below it are served
project = "mysite"                       # the Python package: mysite/settings, mysite/wsgi.py
user = "ag8"
upstream = "http://127.0.0.1:3008"      # where Gunicorn listens; keep it on loopback
```

What the preset adds:

| path | answered by |
|---|---|
| `/static/` | the file below `<root>/static/`, else 404 (never the application); a name that carries its content's hash (`base.85e6f9d19e42.css`, what `ManifestStaticFilesStorage` writes, Wagtail's production default) gets `Cache-Control: public, max-age=31536000, immutable`, any other name `public, max-age=300`, then revalidation by `ETag`, so an upgrade reaches browsers |
| `/media/` | the file below `<root>/media/`, else 404; `X-Content-Type-Options: nosniff` and `Content-Security-Policy: script-src 'none'; form-action 'none'; base-uri 'none'`, so an uploaded HTML or SVG page runs no script on the site's origin (no `sandbox`: a browser's PDF viewer refuses a sandboxed document) |
| `/media/documents/` (wagtail) | 404: Wagtail serves documents through its own view (`/documents/ID/NAME`), which checks a collection's privacy |
| `/.env`, `/.git/`, `/manage.py`, `/requirements.txt`, `/agensio_settings.py`, `/db.sqlite3`, `/Dockerfile`, `/.dockerignore` | 404 at the edge |
| a path ending in `.py`, `.pyc`, `.pyo`, `.sqlite3` (and `-wal`, `-shm`, `-journal`), `.log`, `.key`, `.sql`, `.env` | 404, on the application's paths and in the two served directories |
| everything else | the upstream (Gunicorn) |

Both served directories refuse dot segments and follow no symlink out of the project.

**The virtualenv.** Every task runs in a virtualenv of the site's own,
`<state_dir>/<account>/venvs/<site>`, outside the served tree and never shared between
sites (a virtualenv holds one version of each package). `venv_create` makes it with the
`python3` of `[control] runtimes`; every other task runs that same root-owned `python3`
under the virtualenv's name (`argv[0]` is `<venv>/bin/python`, which is how Python finds
its virtualenv), so the packages are the site's while the program executed stays root's,
as the interpreter rule requires. Debian and Ubuntu ship venv's `ensurepip` apart: without
`python3-venv` the task list marks the interpreter and names
`apt-get install -y python3-venv` for root, and `venv_create` is refused before it runs.

**`pip_install` waits for a person's approval.** It installs whatever packages it is given (one
to ten requirement specifiers: a name, extras, version clauses; no URL, path or option, each passed
to pip after `--`), and their code runs as the site's account, so no run is made on an agent's
`confirm`: the task is checked by a dry run, then stored, and runs only once a person approves it
with the code from their authenticator app (`docs/approvals.md`; `agensio ctl approve` on the
server, or `approvals_ask` in an MCP client that can ask). What waits names the packages, the site,
the account, the exact command, and a warning to check each name on pypi.org, since a look-alike
name is a common way to get malicious code. Typed by you at a terminal, `agensio ctl site-task ...
pip_install ... --yes` asks for the code at once. Until 0.1.0-alpha.120 the confirmation was a field
of the request, which any process of the agent's account could send. `pip_install_requirements`
waits for nothing: the project's own file names the packages.

**The tasks**, in the order a new Wagtail site takes them:

| task | runs | notes |
|---|---|---|
| `venv_create` | `python3 -m venv <venv>` | again keeps what is installed |
| `pip_install` | `pip install -- PACKAGES` | any packages, `--param "packages=wagtail gunicorn"`; every run waits for a person's approval with a code (below); downloads |
| `startproject` | wagtail: `wagtail start PROJECT .`; django: `django-admin startproject PROJECT .` | the directory must be empty; needs the framework from `pip_install` |
| `pip_install_requirements` | `pip install -r requirements.txt` | after a new project, an install, a change; downloads |
| `django_settings` | no program: writes `agensio_settings.py` | a fixed template, `0640`, only when missing; needs `DJANGO_SECRET_KEY` |
| `migrate` | `manage.py migrate --noinput` | |
| `collectstatic` | `manage.py collectstatic --noinput` | into `static/`, which agensio serves |
| `createsuperuser` | `manage.py createsuperuser --noinput --username=U --email=E` | the password from `DJANGO_SUPERUSER_PASSWORD` in the site's environment |
| `check_deploy` | `manage.py check --deploy` | reports, changes nothing |

Every Python task runs with `DJANGO_SETTINGS_MODULE=agensio_settings`,
`VIRTUAL_ENV=<venv>`, `PYTHONNOUSERSITE=1` (never the account's user site-packages),
`PYTHONUNBUFFERED=1`, `PIP_DISABLE_PIP_VERSION_CHECK=1`, `PIP_NO_INPUT=1`, and what
`agensio_settings.py` reads about the site: `AGENSIO_DJANGO_PROJECT`, `AGENSIO_HOSTS` (the
site's names, `*.example.com` as Django's `.example.com`), `AGENSIO_ORIGINS` (those names
with the scheme the site is reached by), `AGENSIO_BASE_URL`, `AGENSIO_STATIC_ROOT` and
`AGENSIO_MEDIA_ROOT` (`<root>/static`, `<root>/media`). The site's environment cannot set
any of these (section 15, "The site's environment"), nor `PIP_*`.

**The production settings.** A generated Wagtail project's production settings have no
`SECRET_KEY` (only its dev settings do) and no `ALLOWED_HOSTS`, so Django refuses every
request until someone writes them; a plain `startproject` has `DEBUG = True` and no
`STATIC_ROOT`. `django_settings` writes `agensio_settings.py` from a fixed template:
it imports the project's own settings (`PROJECT.settings.production` when there is one,
else `PROJECT.settings`), then sets `DEBUG = False`, `SECRET_KEY` from
`DJANGO_SECRET_KEY`, `ALLOWED_HOSTS` and `CSRF_TRUSTED_ORIGINS` from the site's names,
`SECURE_PROXY_SSL_HEADER = ("HTTP_X_FORWARDED_PROTO", "https")` (agensio replaces a
client's `X-Forwarded-Proto` and sets `https` on its TLS listeners, which is what makes
that setting safe), `STATIC_ROOT` and `MEDIA_ROOT` where agensio serves them,
`WAGTAILADMIN_BASE_URL` for a Wagtail project, `SESSION_COOKIE_SECURE` and
`CSRF_COOKIE_SECURE` on a site with TLS, and `DATABASES` from `DATABASE_URL` when
the site's environment has one (`sqlite:///db.sqlite3`, `postgresql://USER:PASSWORD@HOST/NAME`,
`mysql://...`; the driver must be in `requirements.txt`). `manage.py check --deploy`
cannot see what agensio does at the edge, so the file silences `security.W008` (the
redirect of plain http) when the site redirects to https and `security.W004`
(Strict-Transport-Security) when the site has `hsts`, and nothing else: a warning left
means something (on a TLS site without `hsts`, W004 stays until `site_update` with
`hsts: "1y"` sends the header on every answer; `check_deploy` sees the change at once). It
holds no secret and names no host, so a new alias needs no new file, only a new unit.
Running `django_settings` again replaces agensio's own earlier version of the file (it
starts with `# Written by agensio (site task django_settings)`), keeping it as
`agensio_settings.py.bak`, so a site gets a later template's fixes; a file without that
marker is left alone. `manage.py` and `wsgi.py` default to the dev settings; agensio always
sets `DJANGO_SETTINGS_MODULE`, in its tasks and in the unit.

**The first admin.** `site-env-set NAME --generate DJANGO_SUPERUSER_PASSWORD`, then
`site-task NAME createsuperuser --param username=admin --param email=ADDRESS`: the
password is made on the server and never passes through the caller; `site-env NAME
--reveal DJANGO_SUPERUSER_PASSWORD` shows it when the user asks. The rendered unit keeps
it from the application (`UnsetEnvironment=` for the three `DJANGO_SUPERUSER_*` names).

**The unit.** `agensio ctl site-unit NAME` renders the Gunicorn unit: the site's account
and directory, the environment above, the site's environment file, and
`ExecStart=@<runtimes.python3>/python3 <venv>/bin/python -m gunicorn PROJECT.wsgi:application
--bind 127.0.0.1:PORT --workers 2` (systemd's `@` passes the second word as `argv[0]`: root's
interpreter as the site's virtualenv), with the hardening of the Rails unit. Root installs
it with the three commands in its answer; after a change of the site's names or its
Python, root renders it again. `site-service` and `site-service-logs` read it as for Rails.

An existing project goes in with `site-install` (its `manage.py` at the archive's top); the
answer generates `DJANGO_SECRET_KEY` into the site's environment, lists the tasks from
`venv_create` on (`pip_install_requirements`, then `pip_install` for Gunicorn), and warns when the archive's package (the directory holding `wsgi.py`,
`facts.wsgi_packages`) is not the site's `project`. A new Wagtail site, the whole path,
which `tests/wagtail-install.sh` runs:

```sh
agensio ctl site-create --domain ag8.example.com --app wagtail --project mysite --root /var/www/ag8.example.com/app --user ag8 --upstream http://127.0.0.1:3008 --yes --reason wagtail
agensio ctl site-task ag8.example.com venv_create --yes --reason wagtail
agensio ctl site-task ag8.example.com pip_install --param "packages=wagtail gunicorn" --yes --reason wagtail   # prints the warning
for t in startproject pip_install_requirements; do agensio ctl site-task ag8.example.com $t --yes --reason wagtail; done
agensio ctl site-env-set ag8.example.com --generate DJANGO_SECRET_KEY --generate DJANGO_SUPERUSER_PASSWORD --yes --reason wagtail
for t in django_settings migrate collectstatic; do agensio ctl site-task ag8.example.com $t --yes --reason wagtail; done
agensio ctl site-task ag8.example.com createsuperuser --param username=admin --param email=admin@example.com --yes --reason wagtail
agensio ctl site-unit ag8.example.com --out /etc/systemd/system/agensio-app-ag8.service   # as root, then enable it
```

## 4f. Node.js: `app = "node"`

A Node application runs as the site's account under root's `node` (`[control] runtimes.node`)
on a loopback port; agensio forwards every request to it, WebSocket upgrades included (it
serves its own files), and answers these itself with a 404, never forwarded: `/.env`,
`/.git/`, `/.npmrc`, `/node_modules/`, `/package.json`, `/package-lock.json`,
`/npm-shrinkwrap.json`, `/yarn.lock`, `/pnpm-lock.yaml`, and any path ending in `.db`,
`.db-wal`, `.db-shm`, `.db-journal`, `.sqlite`, `.sqlite3` (and its `-wal`, `-shm`,
`-journal`), `.log`, `.key`, `.sql` or `.env`. `root` is the project directory (where
`package.json` lives) and `entry` the file `node` runs, relative to it. `entry` may wait
until the application is installed: `site-install`'s facts guess it from `package.json`
(the start script, one level of `npm run NAME`, else `main`).

```toml
[[site]]
server_name = ["ag9.example.com"]
tls = "auto"
app = "node"
root = "/var/www/ag9.example.com/app"   # the project directory: npm runs here, nothing is served from it
entry = "server/server.js"               # the file node runs
user = "ag9"
upstream = "http://127.0.0.1:3009"      # where it listens; keep it on loopback
```

**The tasks**, as the site's account in the project directory:

| task | runs | notes |
|---|---|---|
| `npm_ci` | `npm ci --omit=dev --no-audit --no-fund` | the dependencies exactly as `package-lock.json` pins them, into `node_modules/`; their install scripts run as the account; needs the lockfile; downloads |
| `npm_run` | `npm run SCRIPT` | one script of the project's `package.json` by name (`--param script=download-dist`): a post-install step the application documents; the project's own code; may download |

Every task runs with `NODE_ENV=production` and npm's cache and user configuration in the
account's own home (`NPM_CONFIG_CACHE=<home>/.npm`, `NPM_CONFIG_USERCONFIG=<home>/.npmrc`),
no update notice, no funding or audit chatter; never the host's `~/.npmrc` or a global
install. The site's environment cannot set `NPM_CONFIG_*` on any site, and on a Node site not
`HOST`, `PORT` or `NODE_ENV` either (section 15, "The site's environment"): systemd lets an
environment file override a unit's own lines, and those three bind the application to its
upstream. `site-tasks` names the missing runtime with `apt-get install -y nodejs npm` for
root. A task that fails names the cause when it is a known one: no lockfile, a lockfile out
of step with `package.json`, a missing script, an engine the runtime's Node does not satisfy,
a native module that needs a compiler.

**The unit.** `agensio ctl site-unit NAME` renders it: the site's account and directory,
`NODE_ENV=production`, `HOST` and `PORT` from the upstream (what Express, Uptime Kuma and most
servers read), the site's environment file, and `ExecStart=<runtimes.node>/node <root>/<entry>`,
with the hardening of the Rails unit. It is refused without `entry`. `site-service`,
`site-service-logs`, `health` and the restart lines after `npm_ci` and `npm_run` work as for
Rails and Django.

**An application from an archive.** `site-install`'s answer reads `package.json`: its name,
the Node it asks for (`engines.node`, compared with the runtime's `node --version`: they
match, they do not, or the range is not one agensio reads), its scripts, whether a lockfile
ships, and the entry it guesses; the next steps are `npm_ci`, the post-install steps through
`npm_run`, the `entry`, and the unit. A Node archive installed on an `app = "proxy"` site is
named in the answer's warnings. Uptime Kuma, the whole path (the setup script Kuma documents is
`npm ci --omit dev` and `npm run download-dist`; `DATA_DIR` keeps `kuma.db`, which holds every
monitored service's credentials, in the account's own home, and `UPTIME_KUMA_DB_TYPE=sqlite`
skips Kuma 2's database page, which the first visitor would otherwise answer):

```sh
agensio ctl site-create --domain ag9.example.com --app node --root /var/www/ag9.example.com/app --user ag9 --upstream http://127.0.0.1:3009 --yes --reason kuma
agensio ctl site-install ag9.example.com --url https://codeload.github.com/louislam/uptime-kuma/tar.gz/refs/tags/2.5.5 --yes --reason kuma
agensio ctl site-task ag9.example.com npm_ci --yes --reason kuma
agensio ctl site-task ag9.example.com npm_run --param script=download-dist --yes --reason kuma
agensio ctl site-env-set ag9.example.com --set DATA_DIR=/var/lib/agensio/ag9/data/ --set UPTIME_KUMA_DB_TYPE=sqlite --yes --reason kuma
agensio ctl site-update ag9.example.com --entry server/server.js --yes --reason kuma
agensio ctl site-unit ag9.example.com --out /etc/systemd/system/agensio-app-ag9.service   # as root, then enable it
```

Kuma, like WordPress's installer and Writebook's first run, creates its admin in the browser
on the first visit: whoever opens the site first becomes its admin, so open it right after
the service starts.

## 5. Customising a preset

A preset never overrides what the site writes itself:

- `index`, `try_files`, `hidden_files`, `symlinks`, `access_log`: site keys apply, and the
  locations the preset generates inherit them.
- `php = { ... }`: every option in it reaches the preset's FastCGI location(s).
- A `[[site.location]]` with the same `path` and `match` as a preset location replaces it
  entirely. Other locations coexist under the normal precedence, with one rule since
  0.1.0-alpha.120: a prefix location below a directory the preset shields (`no_php_under` in
  `presets`: `wp-content/uploads/`, Grav's `user/`), whoever wrote it (the file, a root addition,
  a managed site's `rules`), keeps the shield's refusals, its endings added to the location's own
  `deny_suffixes` and its `serves_only` endings taken as `allow_suffixes` when the location names
  none; and one below a directory the preset never answers (`never_served_directories`: Grav's
  `logs/`, `cache/`) is refused at load. Before, the longest prefix won with only what it wrote: a
  managed site's cache rule on Grav's `user/themes/` served the themes' `blueprints.yaml`,
  `README.md` and twig templates with a week's public lifetime (the alpha.119 report). An exact
  location naming one file stays the site's own decision.
- A `[[site.location]]` that sets nothing but `path` (a prefix) and `add_headers` joins
  the location the preset, or the implicit `/`, makes at that path: its fields are added,
  a field of the same name replacing the preset's value, and everything else of the
  preset's location stays. This is how an `add_headers` at `/` reaches every answer
  the preset's locations give. Before 0.1.0-alpha.36 it replaced the
  preset's location: a proxy preset's site (`proxy`, `rails`, `redmine`, `django`,
  `wagtail`) with `hsts` served its `root` from disk instead of the application, source
  files included, and a PHP preset's site lost its front controller.

Example, Laravel with streaming responses (server-sent events) and a shorter asset cache:

```toml
[[site]]
server_name = ["app.example.com"]
root = "/var/www/app"
app = "laravel"
php = { socket = "unix:/run/php/php8.4-fpm.sock", buffering = false, read_timeout = 300 }

[[site.location]]        # replaces the preset's /build/ block
path = "/build/"
try_files = ["$uri", "=404"]
add_headers = { "Cache-Control" = "public, max-age=86400" }
```

Two things a preset does not let you change: under `app = "laravel"` the web root is
always `public/` and only `/index.php` runs. A project that needs otherwise uses
`app = "php"` or explicit locations.

An application with server guidelines of its own and no preset (Kanboard, say) runs under
`app = "php"` with the site's `rules` (section 15: private paths, the `.php` files that
run, cached directories, a front controller), which the control plane renders into the
locations below, each marked `# rules: ...`; they can only narrow what the preset serves.

## 6. Locations, the reference

Precedence: `exact` matches first, then `suffix` locations (an ending such as `.php`,
matched at the end of the path or before a `/`), then the longest `prefix`; an implicit
`/` prefix with the site's settings always exists. A prefix location with `final = true`
(nginx `^~`) that is the longest prefix match shields its subtree from suffix locations.

An exact location for a `.php` file also takes that script's path-info form: `/install.php/x`
and `/install.php/a/b` are decided by the exact `/install.php`, because PHP runs them as
`/install.php` (FastCGI cuts the path at its first `.php/`, the rest is `PATH_INFO`). A
denied script stays denied however it is spelled, and an entry point runs its path-info URLs
(`/index.php/old/link`, `PATH_INFO = /old/link`). A longer exact location naming the whole path
still wins (`/install.php/help`), and an exact path with `.php/` inside it
(`/a.php/b.php`) takes only itself, since PHP would run `/a.php`. Before 0.1.0-alpha.109 an exact
location matched its literal path only: on a site whose `.php` suffix location runs any script
(`app = "php"`, `wordpress`), `/install.php/x` reached that location and ran the script an exact
deny refused (a `rules.private` file, WordPress's `wp-content/db.php`, `wp-config.php`), and an
entry point's path-info URLs went round `try_files` and lost their `PATH_INFO`. nginx has the same
trap: `location = /install.php { deny all; }` beside `location ~ [^/]\.php(/|$)`.

| key | meaning |
|---|---|
| `path`, `match` | `"prefix"` (default), `"exact"`, or `"suffix"` |
| `root` | file = root + path (default: the site's root) |
| `alias` | file = alias + (path minus the location prefix); prefix locations ending in `/` only |
| `index`, `try_files`, `hidden_files`, `symlinks` | as on the site; the location's value wins |
| `handler` | `"static"` (default), `"fastcgi"`, `"proxy"`, `"cgi"`, or `"deny"` (404 for every path here whatever exists, as hidden files are; what a managed site's `rules.private` renders) |
| `fastcgi = { ... }` | overrides the site's `php = { ... }` for this location (section 7) |
| `methods` | narrows what the handler serves, e.g. `["GET", "HEAD"]`; the rest get 405 with `Allow` |
| `final` | prefix only: nginx `^~` |
| `deny_suffixes` | endings answered with 404 (like hidden files: a refusal never confirms a file exists), e.g. `[".php"]` under an uploads directory; `"~"` (an editor's `name~` backup) is the one entry without a dot |
| `allow_suffixes` | when set, the only endings served here; every other path, directories and bare names included, is 404 whatever exists (Grav's `user/data`: public media beside private data) |
| `add_headers` | response fields added on 200 and 304, e.g. `{ "Cache-Control" = "..." }` |
| `priority` | may use the FastCGI pool slots reserved by `priority_reserve` |
| `httparena = { dataset }` | with `handler = "httparena"`, in a build made with `-DAGENSIO_HTTPARENA=ON` only: the HttpArena benchmark endpoints answered in-process from the dataset (`bench/httparena/`); a release build refuses the handler |

## 6b. Refused paths: `refuse`

Paths a site answers with 404 whichever location would serve them, written as gitignore-style
patterns. It is where an application without a preset of its own gets the denials its
official server configuration lists (an nginx `location ~ ... { deny all; }`, an Apache
`<FilesMatch>` or `RewriteRule ... [F]`), and it works on every `app`, since it only narrows
what the site serves.

```toml
[[site]]
server_name = ["cms.example.com"]
app = "php"
root = "/srv/www/cms.example.com/web"
refuse = ["/vendor/", "composer.json", "*.yaml", "*.typoscript",
          "/typo3conf/ext/*/Resources/Private/", "/fileadmin/templates/**/*.ts", "_recycler_/"]
```

| pattern | refuses |
|---|---|
| `/vendor/` (or `/vendor`) | `/vendor`, `/vendor/` and everything below; never `/vendors/` or `/a/vendor/` |
| `composer.json` | that name in any directory: `/composer.json`, `/core/composer.json` |
| `*.yaml` | every path with a segment ending in `.yaml`: `/config/x.yaml`, and below a directory so named |
| `_recycler_/` | a directory of that name anywhere and everything below it |
| `/typo3conf/ext/*/Resources/Private/` | `*` is any run of characters within one segment: `/typo3conf/ext/news/Resources/Private/x.html`, not `/typo3conf/ext/a/b/Resources/Private/` |
| `/fileadmin/templates/**/*.ts` | `**` is any number of directories, none included: `/fileadmin/templates/a.ts`, `/fileadmin/templates/x/y/a.ts` |
| `**/Tests/Unit/` | that directory pair at any depth |

The rules, all of them on purpose:

- **A match is a 404, and order does not exist.** No pattern reopens what another refuses, and
  none is shadowed by a location: the check runs on the request path before any location is
  chosen, again on every internal redirect (`try_files` fallbacks), and on the index file a
  directory would answer with, so `/docs/` is 404 when `/docs/index.html` is refused. That is
  the class of mistake nginx invites, where a `location ~ \.php$` before a deny, or a `^~`
  prefix, steps around it.
- **A pattern refuses what it matches and everything below it**, with or without the trailing
  `/`. A pattern without a `/` (but a trailing one) is a name in any directory; one with a `/`
  inside is anchored at the root and starts with `/` (or `**/` for any depth): `typo3conf/ext/x`
  without the leading `/` is refused with that advice, rather than guessed at.
- **Case and trailing dots are ignored** (`/VENDOR/`, `x.yaml.`), as for every refusal by
  name; the other ways an application may read a path (a `;parameter` in a segment, a second
  decoding, the path after a script) are judged too, as for the access rules (section 19).
- **Wildcards are `*` and `**` only.** No `?`, brackets or braces (write one pattern per
  alternative), no percent escapes (paths are matched decoded), at most one `**`, at most 64
  patterns of 200 characters; matching is linear and allocates nothing. A pattern of
  wildcards alone (`/*`, `**/*`) or `/` is refused: disable the site or restrict it by
  address instead.
- **A pattern may not refuse what the site serves on purpose**: the index of its root, a
  path `try_files` sends a miss to (a front controller), or an exact location that runs
  something. `-t` refuses the configuration with both named: `'*.php' refuses /index.php,
  the site's index`.

Translating another server's rules: `location ~* \.(yaml|yml)$ { deny all; }` is `*.yaml`,
`*.yml`; `location ~ /\.git { deny all; }` needs nothing (dotfiles are hidden by default);
`RewriteRule ^(vendor|typo3_src)/ - [F]` and nginx's `location ~ ^/vendor/` are `/vendor/`,
`/typo3_src/`; an unanchored `location ~ _(recycler|temp)_/` is `_recycler_/`, `_temp_/`;
`<FilesMatch "^(composer\.json|package\.json)$">` is `composer.json`, `package.json`. Beware an
nginx regex anchored without its slash (`^vendor`): nginx matches it against a path that
always begins with `/`, so as written it refuses nothing; the intent is `/vendor/`.

On a managed site the same list is `rules.refuse` (section 15), and `path-check` (MCP
`path_check`) says what the site does with one path and which pattern or location decides.
A server older than 0.1.0-alpha.54 ignores `refuse` without a word: after an upgrade, check
with `agensio -t --explain` that the patterns are listed.

## 6c. Content types: `mime_types`

0.1.0-alpha.100. The `Content-Type` of the files agensio serves comes from three layers, the most
specific first:

1. a site's own `mime_types` (its site file, or the managed `site_update` field);
2. root's `[mime_types]` in the main file, for every site;
3. the built-in table, nginx's `mime.types` with `charset=utf-8` on text, and `.svgz` sent with
   `Content-Encoding: gzip` (it is gzip-compressed SVG; section 14c and [headers.md](headers.md) 4.1).

Each layer only adds and overrides entries; none replaces the table below it (an nginx `types`
block in a nested level does, and every type it does not list is lost).

```toml
# the main file, root's: for every site
[mime_types]
"webmanifest" = "application/manifest+json; charset=utf-8"
"jxl" = "image/jxl"

[[site]]
server_name = ["example.com"]
root = "/var/www/example.com/web"
tls = "auto"

[site.mime_types]                                               # this site's, over [mime_types]
"sh" = "text/plain; charset=utf-8"                              # an ending
"/.well-known/apple-app-site-association" = "application/json"  # an exact path, for a file without an ending
"js.gzip" = { type = "text/javascript; charset=utf-8", encoding = "gzip" }  # a file stored compressed (TYPO3)
```

`[site.mime_types]` is the table of the `[[site]]` above it; a short one fits on the site's own line
(`mime_types = { "sh" = "text/plain; charset=utf-8" }`: TOML keeps an inline table on one line).

- **A key** is an ending (`sh`, `js.gzip`; matched in any case, a leading dot dropped, the longest
  ending of the file's name first, so `app.js.gzip` takes `js.gzip` before `gzip`) or the exact path
  a file is served at (`/` first, decoded, normalised; a directory's index by its own name,
  `/docs/index.html`). Quote an ending with a dot: TOML reads `js.gzip = ...` bare as a table.
- **A value** is a media type, `type/subtype` with at most a `charset` (RFC 9110 8.3.1), or a table
  `{ type, encoding }` for a file stored compressed, `encoding` being `gzip` or `br` (sent as
  `Content-Encoding`, with no `Vary` and no pre-compressed twin). No encoding on a bare compressed
  or archive ending (`gz`, `br`, `zip`, `tgz`, `tar.gz`...): a browser would unpack the download and
  save its contents under the archive's name, the trap of Apache's `AddEncoding x-gzip .gz`, which
  reaches every `.tar.gz`. A two-part ending that names what is inside (`js.gzip`, `html.br`,
  `txt.gz`) is a file stored compressed on purpose, and is judged by that inner ending for the rule
  below.
- **What a site may not do**: give an ending or a path a type browsers run scripts in (`text/html`,
  XHTML, SVG, any XML, JavaScript) unless the built-in table already gives its ending one; `txt`
  mapped to `text/html` would turn every uploaded `.txt` into a page on the site's origin. Mapping
  the other way (`html` to `text/plain`) is accepted. Root's `[mime_types]` may, and `-t`, the error
  log and health note it (`mime_type_scriptable`).
- **What it reaches**: the files agensio serves from disk, a directory's index and a `try_files`
  target included; an application's answers (PHP, a proxied application, CGI) keep the type they
  send.
- At most 64 entries a site and 256 in `[mime_types]`; an included site file cannot hold
  `[mime_types]` (root's main file only). A reload applies both: a site's cached files take their
  new type at once, since each load's locations cache apart.

On a managed site: `agensio ctl site-update example.com --mime-type 'sh=text/plain; charset=utf-8'
--mime-type 'js.gzip=text/javascript; charset=utf-8; encoding=gzip' --yes --reason "types"` (given
together they replace the table; `--no-mime-types` clears it), or MCP `site_update` with
`mime_types`; `site_show` lists it. `path_check` (MCP `path_check`) names the type a file is served
with and which layer gave it (`content_type`, `content_encoding`, `content_type_from`).

## 7. PHP and FastCGI options

`php = { ... }` on the site is the default for its FastCGI locations; `fastcgi = { ... }`
on a location overrides it. Pool bounds are per upstream socket and per worker, so every
location on the same socket must agree on them: set them once on the site.

| option | default | meaning |
|---|---|---|
| `socket` | required | `"unix:/run/php/php8.4-fpm.sock"`, a bare path (relative to the config file), `"127.0.0.1:9000"` or `"[::1]:9000"` |
| `remote_root` | none | the docroot as php-fpm sees it when it runs in a container (section 9) |
| `buffering` | `true` | collect the whole reply (memory, then a temp file) and release the fpm child at once; `false` streams it |
| `buffer_max` | `"1MB"` | reply bytes kept in memory before spilling to a temp file |
| `buffer_file_max` | `"1GB"` | temp-file cap; beyond it the rest of the reply is streamed |
| `request_buffering` | `true` | collect the request body (memory, then temp file) before talking to fpm; `false` streams it |
| `request_buffer_max` | `"256KB"` | request body bytes kept in memory before the temp file |
| `connect_timeout`, `send_timeout`, `read_timeout` | 5, 30, 60 s | 504 when exceeded; `read_timeout` is between two records from fpm |
| `max_connections` | 16 | in-flight requests per worker to this socket; more wait in the queue |
| `queue_depth`, `queue_wait` | 64, 5 s | queue size and longest wait; beyond either, 503 with `Retry-After` |
| `priority_reserve` | 0 | share of `max_connections` kept for `priority = true` locations |
| `max_idle` | 8 | idle connections kept per worker to this socket when `keep_conn` is on |
| `idle_timeout` | 30 | seconds a kept connection may stay idle before agensio closes it (0 = kept until the peer closes); a kept connection pins a php-fpm child |
| `keep_conn` | `false`; with a generated pool `true` for `pm = "static"` or `"dynamic"` with at least as many children as workers, `false` for `"ondemand"` or fewer children | FastCGI keep-alive; php-fpm pins a child to every kept connection, so `max_connections` x workers must stay at or below `pm.max_children` (`-t` and health warn, `php_keep_conn_exceeds_children`): a request on a kept connection no child takes waits until `read_timeout`. Never with `pm = "ondemand"` (`-t` and health warn, `php_keep_conn_ondemand`): php-fpm forks one child per event on its socket, so connections opened together can get one child between them (its bugs #69724 and #72935), and a child on a kept connection never takes another, so the rest wait until `read_timeout`. Not worth it through a Docker-published port (see below) |
| `head_max` | `"64KB"` | reply head larger than this is 502 |
| `path_info` | `true` | split `/x.php/extra` into SCRIPT_NAME and PATH_INFO |

Transport, measured on a Laravel page (`bench/results/laravel-keepconn-20260917.md`):
a unix socket costs agensio about half the CPU per request of a TCP port, and
`keep_conn` on top of it saves a little more. On TCP, agensio sets `TCP_NODELAY` and,
for kept connections, `TCP_QUICKACK` (Linux) so php-fpm's Nagle cannot stall large
responses; a port published through docker-proxy is out of reach of that fix, so keep
`keep_conn` off there or bind-mount the socket directory instead.

Failures are logged with a reason and a fix hint (socket owner/group/mode against
agensio's uid, the script php-fpm could not open, bytes seen before a child closed) and
appear in the JSON access log as `upstream`.

## 7b. PHP versions

Several PHP versions can be installed side by side, each its own php-fpm with its own
configuration, extensions and pool directory: `php8.4-fpm` and `php8.5-fpm` on Debian and Ubuntu.
agensio finds them on its own (Debian and Ubuntu `/etc/php/X.Y/fpm`, RHEL with Remi's repository
`/etc/opt/remi/phpXY`, Alpine `/etc/phpXY`, Homebrew `<prefix>/etc/php/X.Y`), counting a version
only when its FPM binary and its `php-fpm.conf` are both there. Root names one it does not find
(a build under `/opt`, a second instance) in the main file:

```toml
[php.runtimes."8.5"]
fpm   = "/opt/php85/sbin/php-fpm"
conf  = "/opt/php85/etc/php-fpm.conf"
pools = "/opt/php85/etc/php-fpm.d"
unit  = "php85-fpm"              # its systemd service, for its state and its reload; optional
cli   = "/opt/php85/bin/php"     # optional, for site tasks
```

`php_versions` (MCP, viewer; `agensio ctl php`; `GET /v1/php`) answers, for each installed version:
- the exact version and the extensions its FPM side loads (`php-fpm -m`, not the command line's,
  whose `conf.d` may differ);
- whether its configuration tests clean (`php-fpm -tt`, which needs root: through the provisioning
  helper when agensio started as root, else not run);
- its service's state, and its `process_control_timeout` (without it a php-fpm reload cuts the
  requests in flight on every one of its pools);
- its opcache settings;
- its support status from PHP's own release table (`active`, `security` for security fixes only,
  `eol` past its end of life, `unknown` for one newer than agensio's table), with the dates.

It also lists the versions the system's repositories can install (Debian and Ubuntu: `apt-cache
policy`, read-only), and, for one they do not offer, root's way to add the usual repository:
Ondřej Surý's (packages.sury.org) on Debian, the ondrej/php PPA on Ubuntu. Installing a version is
root's; agensio never installs packages. The design of the whole feature, switching a site's
version without downtime included, is `docs/design-php-versions.md`; this section grows with each
step of it.

**A site's version.** Every site with its own user (section 11) has a php-fpm pool of its own, run
by the php-fpm of its PHP version, so two sites of one account may run two versions:

```toml
[server]
php_version = "8.4"              # every site that names none; without it, the newest installed

[[site]]
server_name = ["grav.example.com"]
user = "ag4"
app = "grav"
php = { version = "8.5" }        # this site's own
```

- **Which version**: the site's `php = { version }`, else `[server] php_version`, else the newest
  installed when the configuration loaded. `site_show` says which and why (`php.version`,
  `php.version_from`: `site`, `server` or `newest`). A site that follows the newest moves to a
  newer PHP installed at the next reload, a step better taken on purpose: health's
  `php_default_unpinned` (info) says so and gives the `php_version` line.
- **The pool**: named `agensio-<user>-<8 hex digits of the domain>` (short and stable: a unix
  socket's path holds 107 bytes, a domain may have 253), its file `<name>.conf` in that version's
  pool directory (`/etc/php/8.5/fpm/pool.d` on Debian), its socket
  `<pools_run>/agensio-<user>-<8 hex>-<version>.sock`, the version in the name so that two
  versions' php-fpm can listen for one site while it moves between them. Its `tmp/` and `sessions/`
  are the site's own (section 11).
- **`agensio pools`** makes every version's pool directory hold exactly the pools the configuration
  gives it: it writes each site's file into its version's directory, removes every other file it
  generated there (a site gone, or moved to another version), and, run as root, tests each
  directory that changed with that version's own `php-fpm -t` before anything reloads it. A
  directory php-fpm refuses is put back as it was, with php-fpm's message. It prints the reload of
  each version it changed (`systemctl reload php8.5-fpm`); the provisioning helper, which runs it
  after `site_create` and `site_update`, reloads them itself.
- **A version that is not installed** does not stop the server: the site loads, its pool is not
  written, its PHP answers 502, and health reports `php_version_missing` (error) with the fix:
  install the version (`php_versions` gives root the line), or give the site an installed one.
- Health's `php_fpm_hard_reload` is judged per version that runs pools: a version whose
  `php-fpm.conf` lacks `process_control_timeout` cuts the requests in flight on its sites whenever
  its pools are written. `php_fpm_inactive` (error) names a version whose service is down while it
  runs sites.

**Changing a site's version without downtime.** `site_update` with `php_version` (`agensio ctl
site-update NAME --php-version 8.5`) or a site file edited by hand followed by `agensio reload`:
every reload that gives a site a new pool socket runs one ordered switch, with the provisioning
helper (agensio started as root):

1. **Preflight**, before anything changes, for a site moving from 8.4 to 8.5:
   - 8.5 is installed;
   - its php-fpm runs (systemd's state of `php8.5-fpm`; without systemd, the master in the pid file
     its `php-fpm.conf` names);
   - both versions' `php-fpm.conf` set `process_control_timeout`.

   A failed preflight changes nothing and says why. It gives root `systemctl enable --now php8.5-fpm`
   for a stopped php-fpm, or the line to add to `php-fpm.conf`. On the control plane a missing
   `process_control_timeout` is a refusal that `cut_requests: true` (`--cut-requests`) overrides; on
   a SIGHUP it is a warning in the error log.
2. **The new pool comes up beside the old one**: written into 8.5's directory, tested with
   `php-fpm8.5 -t`, 8.5 reloaded, its socket awaited (at most 30 s; php-fpm brings a new pool up once
   the children it has finish what they are doing). A test that fails, or a socket that does not
   come up, puts 8.5's files back, and the site never leaves 8.4.
3. **agensio switches**: its new configuration sends the site to the 8.5 socket. Requests already
   running finish on 8.4.
4. **The old pool goes**: removed from 8.4's directory, 8.4 reloaded, its requests in flight finishing
   within `process_control_timeout`.

The answer lists what each phase did and how long it took. Switching back is the same switch.
Changing `[server] php_version` moves every site that follows it in one switch. Two things are slower
for a moment, never failed: the first requests on 8.5 compile their scripts into its empty opcache,
and php-fpm holds new requests in its socket's backlog while it reloads. Sessions carry over: PHP's
session format is the same across 8.x. The one line that makes every reload graceful is root's, in
the `[global]` section of each version's `php-fpm.conf`:

```ini
process_control_timeout = 10s
```

A version without a systemd unit (Alpine, a build named in `[php.runtimes]`, a container) is reloaded
with SIGUSR2 to its master, found through the pid file its `php-fpm.conf` names and checked to be that
version's binary. A new site, or a pool written while its php-fpm is stopped, is not an error: its
pool is read when the master starts.

**At a start.** When agensio starts as root, the helper first makes every version's pool directory
match the configuration, and reloads and awaits what changed before the listeners accept requests.
Clients that connect meanwhile wait in the backlog. This covers what no reload sees:
- an upgrade that changed or renamed the pool files;
- a site file edited before a restart;
- a newer PHP installed for the sites that follow the newest;
- a configuration restored from a backup.

A start whose files already match changes nothing, and the error log says `php-fpm pools at start:
up to date`.

**What an application needs.** Each PHP preset carries its application's published requirements,
read from the application's own pages for its current stable line (checked 2026-10-21):

| preset | PHP | recommended | supported up to | required extensions | recommended extensions | source |
|---|---|---|---|---|---|---|
| `wordpress` | 7.4 (6.9 and older: 7.2.24) | 8.3 | 8.5 | hash, json | curl, dom, exif, fileinfo, igbinary, imagick, intl, mbstring, mysqli, openssl, xml, zip | [requirements](https://wordpress.org/about/requirements/), [hosting handbook](https://make.wordpress.org/hosting/handbook/server-environment/), [PHP compatibility](https://make.wordpress.org/core/handbook/references/php-compatibility-and-wordpress-versions/), `wp-includes/version.php` |
| `drupal` | 8.3.0 (10.x: 8.1.0) | 8.4 | 8.5 | date, dom, filter, gd, hash, json, pcre, pdo, session, simplexml, spl, tokenizer, xml, zlib | openssl | [PHP requirements](https://www.drupal.org/docs/getting-started/system-requirements/php-requirements), `core/composer.json` |
| `laravel` | 8.2 (13.x: 8.3) | | 8.5 | ctype, filter, hash, mbstring, openssl, session, tokenizer | curl, dom, fileinfo, pdo, xml | [deployment](https://laravel.com/docs/12.x/deployment#server-requirements), laravel/framework's `composer.json` |
| `grav` | 8.3 (1.7: 7.3.6) | | | ctype, curl, dom, fileinfo, gd, json, libxml, openssl, session, zip | iconv, intl, mbstring, simplexml | [requirements](https://learn.getgrav.org/2/basics/requirements), `composer.json` |

- **Required** is only what the application enforces. For Drupal, Laravel and Grav that is the
  `require` of their `composer.json` (Composer refuses to install without it). WordPress ships none,
  so its own `wp-includes/version.php` decides (`$required_php_extensions`). `mysqli` is therefore
  recommended, not required: a WordPress site on SQLite runs without it.
- **Recommended** is what the pages ask for beyond that. Cache back ends (apcu, memcached, redis)
  and what a page calls optional are neither, and an application's own run-time checks are never
  read: Grav's code asks whether redis is loaded, and Grav runs fine without it.
- **The installed release wins**: its `composer.json` `require.php` and `ext-*` (the project's, or
  Drupal's `core/composer.json`), or WordPress's `$required_php_version`. A WordPress 6.9 site is
  judged by 7.2.24, a Grav 1.7 site by `^7.3.6 || ^8.0`. Extensions are named as `php-fpm -m`
  prints them (the FPM side, not the command line); which package provides one is the
  administrator's, and the agent's, to find.

Where it is judged, and what happens:
- **Moving a site to another version** (the switch above): a version outside the range, or one that
  does not load a required extension, is refused, naming what is missing; `ignore_requirements: true`
  (`--ignore-requirements`) goes ahead once the user agreed. These come as warnings in the answer,
  never refusals:
  - a missing recommended extension;
  - a version newer than the application says it supports;
  - an extension the old version loads and the new one does not (a plugin may use it).
- **A new site** (`site_create`): only warnings. Nothing is installed to break yet.
- **`site_install`** of the application into a PHP site: after unpacking, the release's own
  declaration and the preset's table are judged against the site's PHP. A release the site's PHP
  cannot run is taken out again, the directory left empty, unless `ignore_requirements`. The
  answer's `facts.php` says what the release declares and how the site's version meets it.
- **Health**:
  - `php_extensions_missing`: an error for a required extension, info for a recommended one;
  - `php_version_unsupported_by_app` (warning): the site's version is outside its application's
    range;
  - `php_version_eol`: from PHP's own release table. Info past active support, a warning past
    security support, an error more than a year after that.
- **`php_versions`** lists, per installed version, which presets it fits (`presets`). **`presets_list`**
  shows each preset's requirements with the page and the date.

`server.pools`, the one pool directory of earlier versions, is gone: each version has its own,
discovered or named in `[php.runtimes."X.Y"]`.

## 8. Logging

```toml
[log]
access = "logs/access.log"   # default: this path next to the config file; "off" disables
format = "vhost_combined"    # the default: Apache's, host:port first; or "combined", or "json"
error = "stderr"             # or a file
level = "warn"               # error | warn | info
```

A site sets `access_log = "path"` or `"off"` to differ; where that path may be, and which site
files may name one outside `sites/`, is section 8c. A request no site takes (a `421` for a
name no site answers on a listener without a catch-all, a scanner going by the bare address)
is written to `[log] access` whatever the sites log, so the fail2ban jails see it (section 18;
before 0.1.0-alpha.70 it was in no log). Logs are buffered per worker and
flushed every second; `kill -USR1 <pid>` reopens all files after rotation.

**The line.** `format` is one setting for every access log. The three forms, for the same request:

```
example.com:443 203.0.113.7 - - [02/Nov/2026:14:03:11 +0200] "GET /wp-login.php HTTP/1.1" 404 153 "-" "Mozilla/5.0"
203.0.113.7 - - [02/Nov/2026:14:03:11 +0200] "GET /wp-login.php HTTP/1.1" 404 153 "-" "Mozilla/5.0"
{"time":"2026-11-02T14:03:11+02:00","remote":"203.0.113.7","host":"example.com","method":"GET","target":"/wp-login.php","proto":"HTTP/1.1","status":404,"bytes":153,"referer":"","user_agent":"Mozilla/5.0"}
```

- `vhost_combined`, the default since 0.1.0-alpha.120: Apache's format of that name (Debian's
  `other_vhosts_access.log`, `%v:%p %h %l %u %t "%r" %>s %O "%{Referer}i" "%{User-Agent}i"`): the
  combined line with the host the request asked for, lower case and without its port, and the
  port of the listener it came in on, in front. The default file is shared by every site without
  an `access_log` of its own and by the 421 lines, and this is what tells one site's lines from
  another's there, and a stray domain still pointing at the host (`old-domain.example:443`) from
  a scan by bare address (`203.0.113.9:80`, or `-:80` for a request that named no host). GoAccess
  reads it as `VCOMBINED`; the shipped fail2ban filters read it (section 18); `agensio ctl logs
  --site NAME` on the shared file answers the site's own lines (section 15). A site's own log
  carries the prefix too, which tells its names apart (`www.example.com` from `example.com`).
- `combined`: the classic Apache and nginx line, for a pipeline that expects exactly it
  (AWStats' `LogFormat=1`, GoAccess `COMBINED`, fail2ban's stock `apache-*` and `nginx-*`
  access-log filters, which anchor on the client address). It carries no host name, so lines of
  a shared file belong to no site in particular. The default before alpha.120.
- `json`: one object per line, for a log collector: `time`, `remote`, `host`, `method`,
  `target`, `proto`, `status`, `bytes`, `referer`, `user_agent`, plus `user` behind a password
  and `upstream` (the outcome of a PHP or proxied request) when there is one. The shipped
  fail2ban filters do not read it (health: `fail2ban_log_format`).

The `remote` field is the client agensio believes: the real client behind `trusted_proxies`,
never the proxy. The user is the one a password check verified (`[[site.auth]]`), never the name
a refused request claimed. A change of `format` applies at a reload. The escaping is
nginx's (`ngx_http_log_escape`): in the combined forms `"`, `\`, control bytes and every
byte from 0x7F up are written `\xHH`, so a line is ASCII whatever a client sent; a JSON line
keeps well-formed UTF-8 and writes a stray byte as `\xHH` too (a TLS ClientHello sent to
port 80 used to land raw, 2026-10-02). `agensio ctl logs` and `logs_query` escape the same
way when they read, so older files are answered as valid text as well.

Every request that reached a site has one line, on HTTP/1.1, HTTP/2 and HTTP/3 alike, however it
ended. When the answer's head went out (the status line, the HEADERS frame), the line has that
status, also when the body was cut short; the bytes are the body bytes that left the server, what
the socket took (HTTP/1.1, HTTP/2) or what went into packets (HTTP/3), so they can exceed what a
client that left had read, as nginx counts them, but never more than the body. When no head went
out, the status says why: `499` the client left first (closed the connection, reset or cancelled
the stream: RST_STREAM, STOP_SENDING, RESET_STREAM; nginx's "client closed request", which log
tools and fail2ban filters know), `408` its body stopped arriving for `body_timeout`, `400` it
broke the body's framing or the protocol on that stream. A `499` and a `408` are what the log
records, never sent: the client is gone or silent, and the connection is closed (nginx does the
same). A `400` for a broken chunked body is sent over HTTP/1.1 before the close (0.1.0-alpha.120;
alpha.119 closed without it); over HTTP/2 and HTTP/3 the stream is reset instead, as RFC 9113
8.1.1 and RFC 9114 4.1.2 ask of a malformed request. The application may still have run the
request: agensio closes its connection to PHP or the origin when the client leaves, but a PHP
script runs on until it writes output, and on to its end with `ignore_user_abort` set. Before
0.1.0-alpha.119 such a request was logged `200 0` over HTTP/1.1 and HTTP/3 and not at all over
HTTP/2, and an HTTP/3 download cut short counted the whole file.

A query whose `since` reaches back past the first line of the current file reads on into the
rotated files as the shipped logrotate configuration leaves them (`packaging/agensio.logrotate`:
daily, 14 kept, `delaycompress`, `nodateext` so that the names are numbered on RHEL and Fedora too,
whose `/etc/logrotate.conf` turns `dateext` on for every program): `FILE.1` as it is, then `FILE.2.gz` and older, newest first, until
`since` or the line limit is reached (0.1.0-alpha.103; before, only the current files were read, so
in the morning a day's window held the hours since the rotation and said nothing). The rotated files
of one log are read up to 8 MB of text and 64 MB inflated, off the workers. The answer lists every
file read in `files`, each source's rotated ones under `rotated`, and when the lines go back less far
than asked, `incomplete` says from when and why: nothing older is kept, the read limit, or the older
files are compressed in a build without zlib. Health's `recent_errors` reads the `.1` too, so its
"last 24 hours" are 24 hours. Rotated files named by date (`dateext` set by hand on agensio's logs)
are not read.

## 8b. Fewer records: `access_log_exclude_paths`, `access_log_keep_days`

Two site keys for a site that promises its visitors fewer records than a web server keeps, as a
privacy notice may ("the server keeps no record of these requests"; under the GDPR an address in a
log is personal data, kept only as long as needed). Both since 0.1.0-alpha.128.

```toml
[[site]]
server_name = ["grabloop.app", "www.grabloop.app"]
# ...
access_log = "/var/log/agensio/sites/grabloop.app.log"
access_log_exclude_paths = [
    "/api/notices/",   # every copy of the app fetches it daily; the privacy notice promises no record
    "/healthz",        # the load balancer's probe every 10 s
]
access_log_keep_days = 7   # rotated lines older than 7 days are deleted (logrotate keeps 14)
```

**`access_log_exclude_paths`.** A request under one of the paths writes no line in the site's access
log, on every method and whatever its status, and the error log's lines about it (a body over the
limit, an unknown method, an HTTP/2 or HTTP/3 stream reset, a tunnel's end) are still written but with
`-` where the client's address would be, so a problem there is still seen. Lines written before the
path is known keep the address: a TLS handshake that failed, a request line that did not parse, the
connection's own HTTP/2 lines. A path is a prefix from `/` covering whole segments: `/healthz` covers
`/healthz` and `/healthz/live`, never `/healthzx`; `/api/notices/` everything below it. It is matched
in the capitalisation written, on the cleaned path, the one routing judges, never the raw request:
`/api/notices/../../wp-login.php` is a request for `/wp-login.php` and is logged. At most 16; plain
characters, no query.

It is refused for `/` (`access_log = "off"` is that) and for every path the fail2ban jails count
(section 18): a login path (the preset's and the site's `login_paths`), also reached through the
site's front controller (on a preset with one, `/index.php` and `/index.php/` are refused, since the
application routes every request through it, and `/index.php/login` is `/login` to the application
and to the login jail's filter, so it is judged as that path; 0.1.0-alpha.129), a path a
`[[site.auth]]` password protects (the `agensio-auth` jail counts failed passwords by address) and
one a `[[site.access]]` rule restricts, report mode included (the `-denied` jail counts its 403s,
the report lines name the clients), where an exact rule on a script covers the paths that run it
with path info (`/adm.php/x` runs `/adm.php`, as the rules judge it; alpha.129); a path `["any"]`
reopens below a restricted one may be excluded. The `-scan` and `-post` jails go on counting
everything else of the site. On a managed site the same checks run in the request itself, so a dry
run refuses what the reload would and nothing waits for a person's approval only to fail (alpha.129;
before, the coverage checks ran at the reload alone). Health lists the paths
(`access_log_excluded`, info) and `site_show` shows them; `logs_query` answers nothing for them. The
application behind the site keeps whatever it logs itself (Laravel's `storage/logs`, an analytics
tag): the key covers agensio's logs alone. The php-fpm pools agensio writes keep no access log.

The check costs nothing on the request path of a site without the key, and nothing at all on a site
whose access log is off: it is asked when the line is written, after the test of the log itself.

**`access_log_keep_days`.** No rotated file of the site's access log that holds a line older than
this many days is kept: every hour agensio deletes logrotate's numbered rotations of the file
(`NAME.1`, `NAME.2.gz` and on, as `packaging/agensio.logrotate` names them) whose oldest line is
older, judged by the lines at the file's start (inflated for a `.gz`), or, for one whose start does
not read, by its time of change less a day. A ceiling, from 1 to 14: the shipped logrotate keeps 14
days, which this cannot lengthen. The current file is logrotate's, rotated daily, so it holds up to a
day and some hours. logrotate takes one `rotate` per file and refuses a second entry for a file its
glob names already, so the days cannot be its setting per site.

The site needs its own access log in `sites/` of agensio's log directory (the directory of `[log]
access`, `/var/log/agensio` as packaged), named `*.log`, as `site_create` gives a site with its own
account: a site writing `[log] access`, a file outside that directory or one another site writes too
is refused (the other site would lose its lines). `sites/` is the server account's (8c), and a
server started as root deletes through its root helper, which reads the sites and days from the
configuration on disk and reaches the directory without following a link (`docs/security-control-plane.md`
row 58); otherwise the server deletes as its own account. A file that could not be deleted is health's
`access_log_keep_failed`. Rotated files named by date (`dateext` set by hand) are not touched.

On a managed site both are fields of `site_update` (and `site_create`): `agensio ctl site-update NAME
--access-log-exclude /api/notices/ --access-log-keep-days 7`. A change that adds or widens an
excluded path, or sets or lowers the days, waits for a person's approval (`docs/approvals.md`):
both leave less of a record, and deleted lines do not come back. Removing a path or raising the days
does not wait. Lines written before a path was excluded stay until their rotated files go; agensio
does not edit log files.

## 8c. Where a log may be

Which paths a log may have, and why there is a rule at all (0.1.0-alpha.129;
`docs/security-control-plane.md` row 59). The start opens every log as root, before the privilege
drop, and keeps the descriptors; the site files under `sites.d` belong to the server's account, which
`site_create` writes them as. nginx and Apache open any path their configuration names, because their
configuration is root's; agensio's site files are not all root's, so a file the server's account can
write must not be able to make root open, create or hand over a file anywhere.

- **The main file names any path** for `[log] access`, `[log] error` and `[control] audit`.
- **A site file of the main configuration's owner names any path** in `access_log`: a regular file
  (no link) of the same uid as the main file, writable by nobody else (`chown root`, `chmod 0644`).
  That is the hand-written file, root's word, as nginx's `access_log` directive; the directory of a
  log elsewhere is root's to own, as Apache's security guide asks of its `logs` directory: a directory
  another account can write lets that account replace a log with a link before root opens it.
- **Any other site file** (the managed files, anything the server's account put under `sites.d`, a
  file writable by its group or by others) names its log in `sites/` of the log directory only:
  `<log directory>/sites/<name>.log`, `<name>` of letters, digits, `.`, `_` and `-` (a domain), or
  `[log] access`, or `"off"`. Anything else sets the file aside (12c) with a message naming the rule.
  A managed site with its own account gets `sites/<domain>.log`; `site_create` and `site_update`
  have no field for it, and a `site_update` of a file set aside for an older request's path writes
  that one path back.
- **Below the log directory nothing is followed.** The log directory is the directory of `[log]
  access` (`/var/log/agensio` as packaged). A path below it is opened from there one component at a
  time without following a symbolic link; the file must be a regular one with one name, owned by root
  or the server's account; the only directory agensio makes there is `sites/`. A link planted as
  `sites/` or as a site's log, a hard link, a FIFO, a file of another account: refused by name, the
  site set aside, the rest served. A link at or above the log directory itself (the directory on
  another disk) is the system's layout and is followed. Each refusal carries its fix: a link standing
  for a directory is made a directory again (logs on another disk: link or mount the log directory
  itself); a link, FIFO or hard link standing for the log is removed, and the start creates the log.
- **What `-t` says.** The packaged unit runs `agensio -t` before the start, so `-t` walks every log
  below the log directory as the start does, read-only (0.1.0-alpha.130; alpha.129 judged links alone):
  a site whose log the start cannot open is set aside there too (a warning, `--strict` fails), and one of
  the server's own files makes `-t` fail, as it makes the start fail. A site of the main file is set
  aside alone, the main file's other sites served (0.1.0-alpha.130): the main file is all or nothing,
  but what stands in the log directory is the server account's to change, not the main file's, and must
  not keep the host from starting. While the
  server runs, the reload's error-log lines and health say the same before the next start: `log_path_link`
  (a link on the way, naming its target and who logs behind it) and `log_path_refused` (anything else).
  A reload keeps a log it has open, so a link or a FIFO planted over an open log changes nothing until
  the next start; one a reload would open sets its site aside at that reload. `validate` (`agensio ctl
  validate`, MCP `config_validate`) judges the logs as that reload does: the logs the server has open
  kept, any other walked, a site whose log the reload cannot open in `held_back` (0.1.0-alpha.131).
- **Rotation.** `SIGUSR1` and `logs_reopen` open every log again through the same walk. A file that
  does not open again keeps its previous descriptor, so its lines go on into the rotated file, which
  logrotate's next run compresses and removes: each such file is an error-log line naming who writes it
  and why, the `logs_reopen` answer's `failed` (status 409), and health's `log_reopen_failed` until a
  reopen opens it (0.1.0-alpha.130; before, the reopen answered ok and said nothing).
- **Hand-over on the descriptor.** A log opened as root is given to the server's account on the open
  descriptor (`fchown`), never by path: the server's own files `agensio:agensio 0640`, a site's
  `agensio:<site group>` when every site writing it is that account's, `agensio:agensio` for a site
  without a user (before alpha.129 such a log stayed root's, and every reload after the start was
  refused with `cannot open log file ...: Permission denied`).

The directories as packaged: `/var/log/agensio` is `root:agensio 0750` (Debian's nginx layout since
CVE-2016-1247: the server's account can replace nothing root or logrotate opens there) and its `sites/`
`agensio:agensio 0750`, so a reload, which runs as the server's account, creates a new site's log there
itself; a start makes a missing `sites/` the server's. A log a root-written file names in the log
directory itself, or `[log] access` renamed, is created by the start as root; a reload that needs it
sets that site aside, or refuses the reload for the server's own file, naming the one command
(`install -o agensio -g <group> -m 0640 /dev/null PATH`), until the file exists or a restart creates
it. logrotate rotates `/var/log/agensio/*.log` and `sites/*.log`, as root in root's directory; a log
root named elsewhere needs an entry of its own with the same `postrotate`.

The boundary exists where the server runs as `server.user` under a main file of root's. Without
`server.user` the server is whoever started it (a developer's machine, a container running the
one account), nothing is root's against it, every site file is the owner's word and nothing but
the walk applies.

## 9. php-fpm in a container

When php-fpm runs elsewhere (Docker, ddev), publish its port and tell agensio the docroot
as php-fpm sees it:

```toml
[[site]]
server_name = ["app.example.com"]
root = "/srv/app"                       # the project on this host (bind-mounted into the container)
app = "laravel"
php = { socket = "127.0.0.1:9000", remote_root = "/var/www/html/public" }
```

`SCRIPT_FILENAME`, `DOCUMENT_ROOT` and `PATH_TRANSLATED` are rewritten from the local root
to `remote_root`; agensio still checks locally that the script exists. The three ddev test
beds under `bench/` are complete working examples of this shape.

## 10. Behind a reverse proxy or load balancer

```toml
[server]
trusted_proxies = ["10.0.0.0/8", "127.0.0.1"]
```

From those peers `X-Forwarded-For` (rightmost hop that is not itself trusted) becomes the
client address in the access log and `REMOTE_ADDR`, and `X-Forwarded-Proto: https` sets
`HTTPS` and `REQUEST_SCHEME` for PHP. Unset, the headers are ignored, so nothing can be
spoofed from the open internet.

An entry may carry a port, as some load balancers write it: `198.51.100.7:1234` and
`[2001:db8::7]:443` are the address alone (a port is 1 to 65535; any other is not an address). Several `X-Forwarded-For` lines are one list in order, read from the end of the last line,
so a proxy that adds a line of its own (HAProxy's `option forwardfor`) decides, and a line
the client wrote before it is reached only through hops you trust. `X-Forwarded-Proto`
counts the last value of its last line. An entry that is not an address stops the walk.
A reverse-proxy location forwards a trusted chain whole, every line in order, then its peer.

An IPv4 client of a listener on `[::]` is recorded as its IPv4 address (`192.0.2.7`, never
`::ffff:192.0.2.7`), in the logs, in `REMOTE_ADDR` and when it is matched against a list;
an entry written in that mapped form (`::ffff:10.0.0.0/104`) means the IPv4 range it names,
and an IPv6 entry never matches an IPv4 client. Entries with a zone id (`fe80::1%eth0`) are
refused. A reload that changes the list applies to connections already open from their
next request on.

The list also takes the `[addresses]` sets of the access rules (section 19), so a CDN's
published ranges live in one place:

```toml
[addresses]
cdn_a = ["173.245.48.0/20", "103.21.244.0/22"]
cdn_b = ["198.51.100.0/24"]

[server]
trusted_proxies = ["@cdn_a", "@cdn_b"]
```

**A site's own list.** With several proxies on the server, every site believes all of them,
and a CDN's addresses are shared by all its customers: anyone can point CDN B at this server
and send requests for a site behind CDN A. A site therefore names the proxies that speak for
it:

```toml
[[site]]
server_name = ["example.com"]
trusted_proxies = ["@cdn_a"]     # only CDN A speaks for this site

[[site]]
server_name = ["example2.com"]
trusted_proxies = []             # visitors connect directly: no proxy speaks for this site
```

A request from a proxy the server trusts and the site does not is then the peer's own: its
address is the client (access rules, password exceptions, the logs, fail2ban, `REMOTE_ADDR`,
the origin's `X-Real-IP`) and its scheme is the connection's. Each entry must lie within the
server's list, which only root widens in the main file: a site that could add ranges would make
the server believe forged addresses for it, and those reach fail2ban, whose bans hold for the
whole host. Without the key a site believes the server's whole list, and pays nothing per
request; health reports `site_trusts_every_proxy` when the server lists two or more sets and a
site names none. A managed site sets it with `site_update` (`trusted_proxies`, `null` back to
the server's list) or `agensio ctl site-update NAME --trusted-proxy @cdn_a`,
`--no-trusted-proxies`, `--trusted-proxies-default`. The fail2ban jails agensio renders never ban
a trusted proxy (`docs/fail2ban.md`).

## 11. Hosting: one user per site

`user = "web1"` on a site makes PHP for that site run as `web1` in a php-fpm pool that
agensio generates. Nothing else is needed:

```toml
[server]
user = "agensio"             # the account the server serves as; its group reads the sites and the pool sockets
# group = "agensio"          # default: the user's primary group
# php_version = "8.4"                 # the PHP version of sites that name none (section 7b)
# pools_run = "/run/php"              # where generated pools listen (default: per distro)
# state_dir = "/var/lib/agensio"      # per-site tmp and session directories
# strict_users = true                 # refuse a site without `user` (one that only redirects needs none)

[[site]]
server_name = ["shop.example.com"]
root = "/var/www/clients/web1/shop"
user = "web1"
group = "client1"            # optional, default: the user's primary group
app = "laravel"
php = { children = 8 }       # no socket: it is derived, /run/php/agensio-web1-a0711666-8.4.sock
```

Then, as root:

```sh
agensio pools -c /etc/agensio/agensio.toml   # writes agensio-web1-a0711666.conf into 8.4's pool.d, tests it; exit 3 when something changed
systemctl reload php8.4-fpm                  # the line it prints for each PHP version it changed
```

Each site with a user has its own pool, in the php-fpm of its PHP version (section 7b); its name is
the user and 8 hex digits of the domain. What the pool gets: `user`/`group` of the site, socket
`0660 web1:agensio`, `pm` and `children`, `pm.max_requests`, a private `tmp/` and `sessions/` under
`<state_dir>/web1/php/<domain>` (`tmp/` is `2750 web1:<server group>`, `sessions/` `0700
web1:web1`, see below; the account's directory `<state_dir>/web1` and its `php/` are `0700
web1:web1`), `open_basedir` at the project directory plus those two (`upload_tmp_dir` and
`sys_temp_dir` at `<state_dir>/<user>/php/<domain>/tmp`, `session.save_path` at
`<state_dir>/<user>/php/<domain>/sessions`, both created by `agensio pools` as the user and listed
in `open_basedir`, so PHP's uploads and temp files land in the site's private space and never in
`/tmp`, and one site's PHP does not reach another's sessions within the account. `tmp/` is `2750 <user>:<server group>`, like the
document root: an uploaded file is created there, so it is born with the server's group,
and `move_uploaded_file()` renames it into the document root with that group kept, where
the server can read it; a set-gid document root alone would not do that, since rename
keeps a file's group (2026-09-20: every upload was `0640 user:user` and answered 404).
`sessions/` stays `0700 <user>:<user>`, nothing leaves it. `agensio pools` repairs a
`tmp/` from an earlier layout when run as root; files uploaded before that need `chgrp
-R <server group>` on the application's upload directory, and `health` reports them
as `files_unreadable` until then, with `php_tmp_missing` when the directory is gone), `memory_limit`, `max_execution_time`, upload limits from
`max_body_size`, `clear_env`, `expose_php = off`. `agensio -t --explain` prints the
whole file. agensio's own FastCGI options for a generated pool default to
`max_connections = children / workers` (at least 1), and to `keep_conn = true` for a
`static` or `dynamic` pool with at least as many children as workers, so kept connections can
never pin every child (section 7). With fewer children than workers each worker still holds a
connection, more than the pool has children, so such a pool gets no kept connections either
(before 0.1.0-alpha.70 the rest waited until `read_timeout`: 4 workers before a static pool of 2
children answered a burst of 16 requests with up to 8 x 504 in 20 s, now all in 1.2 s,
`bench/results/php-pool-20261011-161150.md`). An `ondemand`
pool (the default) gets no kept connections: php-fpm forks its children one per event on the
pool's socket, and a burst of connections behind kept ones waited until `read_timeout`
(0.1.0-alpha.66 and earlier). Keep-alive saves about 11 us of CPU per request (agensio's and
php-fpm's together, `bench/results/php-pool-20261011-103217.md`), which counts for a script that
does almost nothing; a site that needs it sets `pm = "dynamic"`.

Pool keys in `php = { ... }`, all optional:

| key | default | meaning |
|---|---|---|
| `children` | 8 | `pm.max_children` |
| `pm` | `"ondemand"` | `"ondemand"`: a child starts on the first request and exits after 60 s idle, nothing resident while the site is quiet; `"dynamic"`: half the children on standby; `"static"`: every child resident, predictable, what a PHP benchmark should use |
| `max_requests` | 500 | `pm.max_requests`; 0 = unlimited |
| `memory_limit` | `"256M"` | `memory_limit` |
| `max_execution_time` | 60 | seconds |
| `max_input_time` | 60 | seconds, how long a request body may take to arrive |
| `version` | `[server] php_version`, else the newest installed | the site's PHP version (section 7b): its pool goes into that version's php-fpm |
| `open_basedir` | project, tmp, sessions | replaces the default list |
| `extra` | none | `{ "date.timezone" = "Europe/Athens" }` becomes `php_admin_value[...]` lines |

**Why `ondemand` is the default** (2026-09-21, a live host): with `static`, every site
with its own account kept its 8 children resident around the clock, 15 to 25 MB of
private memory each on top of the shared PHP image, about 150 to 200 MB per idle site,
and a 4 GB machine ran out at 15 to 20 sites before serving anything. `ondemand` costs a
fork on the first request after a quiet minute (tens of milliseconds) and starts
children up to `children` under a burst; agensio writes `pm.process_idle_timeout =
60s` and closes its own kept connections after `idle_timeout` (30 s, section 7) so the
children are free to exit. Set `pm = "static"` on a site that must not pay that first
fork, and in a development environment when measuring PHP throughput: the benchmark beds
under `bench/` use static pools, and a comparison against nginx in front of an
`ondemand` pool would measure php-fpm's forking. `health` names every `static` or
`dynamic` pool with the PHP processes it keeps and their memory (`php_pool_resident`),
so the cost is visible before the machine is full. The verdict comes from the pool file
php-fpm runs, not from the configuration: a pool whose file still says `static` after the
configuration changed to `ondemand` is named as a warning until `agensio pools` and a
php-fpm reload (2026-09-23: two such pools held 681 MB while the finding stayed silent).

A site's own `max_body_size = "200MB"` (a site key, next to `root`) bounds its request
bodies (413 above) and sets the pool's `upload_max_filesize` and `post_max_size`; without
it the site takes `[server] max_body_size`. The keys `children`, `pm`, `max_requests`,
`memory_limit`, `max_execution_time`, `max_input_time` and the site's `max_body_size` are
also settable through the control plane (`site-create` / `site-update` with `settings`,
section 15), within the ceilings `[control] site_limits` sets. `open_basedir` and `extra`
are not: they change what a site may reach or run, and stay in this file, root's.

Rules: each site has its own pool, so two sites of one account may differ in every key above,
the version included; sites with different users may never name the same socket; a site with `user` and an
explicit `php.socket` keeps its own pool and gets no generated file. A site that runs
no PHP (`app = "proxy"`, `app = "static"`, no `handler = "fastcgi"` location) derives no
pool from its `user`: the account owns the files and, behind a proxy, runs the
application; `agensio pools` writes nothing for it, `health` looks for no PHP
directory, and pool keys in its `php = { ... }` are refused (2026-09-26: a Rails site
was reported `php_tmp_missing` and `pools_stale` before this rule).

**What the hosting rules refuse** for a site with `user`, naming the path, its owner and
mode, and what was expected (what a refusal does follows the list):

- the user or group does not exist;
- the root or an `open_basedir` entry is not owned by the user (or root), or is writable
  by other users;
- the root (or the project above a Laravel `public/`) cannot be read by the server's
  account: the fix it prints is `chown <user>:<server group> ROOT && chmod 2750 ROOT`,
  the layout `site-create` prescribes;
- a secret is readable by other users: the preset's credential files (`presets` lists
  them under `secrets`: `wp-config.php` for WordPress; `settings.php`,
  `settings.local.php` and `services.yml` for Drupal), `.env` and `.git` under the root,
  and for Laravel the project's `.env`, `config/`, `storage/` and `.git` (make them
  `0600`, or `0640 user:<the site's own group>`; `site-install` and `site-copy` create
  them `0600`, the same list, so what they write always passes). This rule sets no site
  aside; see below;
- the pool socket is not owned by the user, not in the server's group (owner = site user,
  group = server group, `0660`: the server connects through the group bit, nobody else
  can), or has mode bits for others; or its directory is world-writable;
- the access log is readable by other users, or its directory is writable by them;
- two sites with different users share a root (or nest one inside the other), an access
  log or a state directory.

Sites without `user` are not checked, so a single-tenant machine changes nothing.

A site file under `sites.d/` whose site breaks a rule is set aside like a file with an error
(section 12c), and the other sites load: `agensio -t` warns (`--strict` fails), health reports
`hosting_rule` with the site, the path and the fix. **A site is served only by a version that
passes every rule now:** on a reload, a site whose file was edited to break a rule keeps the
version that runs, while a site whose own paths broke a rule (a root opened to others while it
serves) goes down until they are fixed and a reload brings it back, because its running version
breaks the rule too; a reboot does the same. Two users sharing a root, a log or a state directory
set one of the two files aside, the one the server already serves keeping its place. What only
the server's own account breaks (`server.group` missing), and a rule a site of the main file
breaks, refuse the start or the reload as a whole. Before 0.1.0-alpha.62 any rule any site broke
refused it as a whole: one tenant's `chmod` stopped every site at the next boot and blocked
every reload. `agensio pools` is not held to the rules (writing the pools is how a socket rule
is fixed) and, while a site file is set aside, keeps the pool files of every account.

**A credential file readable by others sets nothing aside** (0.1.0-alpha.110). An update made in
place is how one loosens: `cp .env.example .env` leaves `0644`, Laravel's common advice `chmod -R
775 storage` gives `storage/` to the server's group, `rsync -a` and `tar x` put an archive's modes
back. Before, the next reload, whatever caused it (another site's change through the control plane,
a SIGHUP), set such a site aside, and a site stopped makes the file no more private. Now the site
keeps serving, and:

- at a start and at every reload made by a server started as root, the provisioning helper makes
  each such file private as the site's account, with the installer's modes: a file `0600`, a
  directory without its group's read and write and nothing for others (`2750` becomes `2710`).
  It never follows a link, never changes another account's file, and touches only what the rule
  flags (a `0640` file of the site's own group stays). The error log and the audit log say
  `tightened PATH from 0644 as USER`;
- what is left (another account's file, a link, a server not started as root) is a health error,
  `credential_exposed`, with the `chmod` or the `chown` to run; `agensio -t` prints it as a
  warning and passes; `validate` lists it under `credentials_exposed`.

nginx and php-fpm check no file mode at all. Apache's suEXEC refuses a script, per request,
when it or its directory is writable by others: the rules above stay fail-closed for what someone
else could write (a root or an `open_basedir` directory of another account, or writable by others),
and tighten what someone else could read.

The account's home is its state directory, `<state_dir>/<user>`. For a PHP site `agensio
pools` creates it with `tmp/` and `sessions/`; for an account without a PHP pool (a Rails
site) the provisioning helper creates it, `0700` with a `tmp/`, the first time a site task
runs, because `gem` and `bundle` write below `HOME` (section 15, `site-task`).

One rule set answers `agensio -t`, the server's own start, every reload and site change
through the control socket, and the health check: a configuration that reloads is one
that boots. The server's group in those rules is `server.group`, else the primary group
of `server.user`, never the group of whoever runs the check.

**Starting as root.** With `user` set on sites you normally want privileged ports and
per-site logs too:

```toml
[server]
user = "agensio"     # bind, open the logs, then become this user
group = "agensio"
```

agensio binds its listeners and opens every log as root, makes each site's access log
`agensio:<site group> 0640` (agensio writes it, the customer reads it through their
group, nobody else), then switches to `user` with its groups before accepting the first
connection. Started as that user already, as systemd would, it just runs. Started as root
without `user` it warns and keeps running as root. Without root the per-site chown fails
and one warning per site says which customer cannot read their log.

## 12. Reverse proxy

`upstream = "http://host:port"` (or `"unix:/path"`) on a location forwards everything under
it to an HTTP/1.1 origin. The defaults are what a site behind a proxy needs, so most setups
are one line per location:

```toml
[[site]]
server_name = ["app.example.com"]
root = "/var/www/app/public"      # static files served here where a location says so
tls = { cert = "...", key = "..." }
proxy = { read_timeout = 120 }    # site-wide defaults for every proxy location below

[[site.location]]                 # the application
path = "/"
upstream = "http://127.0.0.1:3000"

[[site.location]]                 # an API on another service, its prefix dropped:
path = "/api/"                    # /api/users -> http://127.0.0.1:4000/users
upstream = "http://127.0.0.1:4000/"

[[site.location]]                 # server-sent events: stream, do not buffer
path = "/events/"
upstream = "http://127.0.0.1:3000"
proxy = { buffering = false, read_timeout = 3600 }

[[site.location]]                 # assets straight from disk
path = "/assets/"
```

**Groups.** `upstream = ["http://10.0.0.11:3000", "http://10.0.0.12:3000"]` spreads
requests over several origins, round-robin within each worker. An origin that fails
`max_fails` times in a row (default 3) is skipped for `fail_timeout` (default 10 s), then
tried again; when every member is down the one marked longest ago is tried anyway. A
request whose origin refuses the connection or times out before answering moves to the
next member: any request when nothing was sent yet (a refused connection), only GET and
HEAD once bytes went out, so a POST is never delivered twice. Each member is a pool of its
own with the location's limits; all members must share the URI part. Both events are in
the error log: `marked down for 10 s after 3 failure(s)` and `is back`. No weights and no
active health checks until a real deployment asks for them.

**TLS to the origin.** `upstream = "https://10.0.0.11:8443"` talks TLS to the origin,
keep-alive included, so a handshake is paid once per pooled connection rather than per
request. The certificate is verified against the system store by default;
`proxy = { tls = { ca = "/etc/ssl/internal-ca.pem", server_name = "app.internal" } }`
names a private CA and the name the certificate must carry (also sent as SNI). Without
`server_name` the certificate must name the upstream's address itself (an IP address entry,
`IP:10.0.0.11`), as nginx and Caddy check by default, and no SNI is sent; most certificates
name hosts, not addresses, so set `server_name` to the name yours carries. `tls = { verify =
false }` accepts anything, for a self-signed origin you control. A failed handshake or
verification is a 502 logged as `tls_error`; without `server_name` the line adds that the
certificate must name the address. Kept connections belong to their TLS policy: two
locations reaching one origin with different `tls` tables never share a connection. Before
0.1.0-alpha.61 an empty `server_name` checked no name at all (any certificate a trusted CA
signed was accepted), connections were shared across policies, a redirect from an `https://`
origin to its own address was never rewritten, and `host = "upstream"` sent the scheme in
`Host`.

**Target.** The client's request line is forwarded as sent. With a URI part on `upstream`
(`http://host:port/` or `.../v1/`) the location's prefix is replaced by it, the way
nginx's `proxy_pass` with a URI works; without one the path is untouched. Exact and
suffix locations cannot rewrite.

**What the origin sees**, with no configuration:

- `Host` as the client sent it. (nginx forwards the upstream's address unless told
  otherwise, which is the first thing everyone has to fix; here `host = "upstream"` is the
  opt-in and `host = "app.internal"` a literal.)
- `X-Forwarded-For` and `X-Forwarded-Proto`, always set by agensio; `X-Forwarded-Host`
  only when Host was rewritten (or a trusted proxy in front sent one), because with Host
  passed through it would only repeat it and every field costs the origin parsing time.
  A client that is not one of `server.trusted_proxies` gets its own X-Forwarded-* replaced,
  never appended to, so nothing from the open internet reaches the application as a
  believed address. Behind a trusted proxy the chain is appended to. `forwarded =
  "forwarded"` sends RFC 7239 `Forwarded` instead, `"both"` sends both, `"off"` neither.
- `X-Real-IP` with the client as agensio knows it (the address of its logs and access rules,
  forwarded-aware), as nginx's `proxy_set_header X-Real-IP $remote_addr` does and most
  applications' proxy guides ask for (Vaultwarden, Grafana and Rocket.Chat read it first).
  A client's own `X-Real-IP` is never passed on. `forwarded = "off"` sends none;
  `request_headers = { "X-Real-IP" = "" }` removes it.
- The fields in which a CDN names the client (`CF-Connecting-IP`, `CF-Connecting-IPv6`,
  `CF-Pseudo-IPv4`, `True-Client-IP`, `Fastly-Client-IP`, `X-NF-Client-Connection-IP`,
  `DO-Connecting-IP`, `B-Forwarded-For`, `X-AppEngine-User-IP`, `X-Plausible-IP`, `X-Client-IP`,
  `Client-IP`, `X-Cluster-Client-IP`, `X-Forwarded`, `Forwarded-For`) only from a peer in
  `server.trusted_proxies`: from anyone else they are dropped, since the application sees
  agensio's loopback address as its peer and believes such a field from there (Umami and
  Plausible read them before `X-Forwarded-For`, Rails reads `Client-IP`). Until 2026-10-13 a
  client could set any of these, `X-Real-IP` included, and choose the address the application
  saw.
- Every other field except the hop-by-hop ones (`Connection` and whatever it lists,
  `Keep-Alive`, `TE`, `Trailer`, `Transfer-Encoding`, `Upgrade`, `Expect`), the framing, and any
  field with `_` in its name: Rack and Puma, like CGI, read `Client_IP` as `HTTP_CLIENT_IP` and
  `X_Real_IP` as `HTTP_X_REAL_IP`, the fields agensio guards under their dashed names, so such a
  field could name the client or the user, or make a Rails application answer 500 on every page
  (alpha.74). FastCGI and CGI drop them the same way, and nginx does by default
  (`underscores_in_headers off`). There is no switch to pass them (nginx's
  `underscores_in_headers on`): none of the applications whose proxy guides were reviewed needs
  one; an application that sends its own fields with `_` gets them under a dashed name instead
  (`X-Api-Key`, which it reads as `HTTP_X_API_KEY` all the same).
- One `Cookie` line, whatever the client sent: a browser sends one `cookie` field per
  cookie over HTTP/2 and HTTP/3, and they are joined with `; ` in the order received (RFC
  9113 8.2.3, RFC 9114 4.2.1), as are two `Cookie` lines from an HTTP/1.1 client, so an
  origin that reads the first line only (Rack, Puma) sees every cookie. FastCGI and CGI get
  the same single `HTTP_COOKIE`.
- The body with a Content-Length when its size is known (also after agensio collected a
  chunked body), chunked otherwise. Keep-alive to the origin, HTTP/1.1: nothing to enable.

`request_headers = { ... }` sets fields on the way to the origin. A value may use `$host`,
`$remote_addr` (the client as agensio knows it, forwarded-aware), `$scheme`,
`$server_name` and `$server_port`; an empty value removes the client's field. A site's
`proxy = { request_headers = ... }` and a location's are merged, the location winning per field:
nothing is silently reset by a nested table, which is nginx's best-known
`proxy_set_header` trap.

**What the client sees.** The origin's status and fields, except framing and connection
ones, `Server` and `Date` (agensio's own), and whatever `hide = [...]` lists. A chunked
origin body is re-framed with a Content-Length when buffered, passed on as chunked when
streaming. A `Location` that points at the origin's own address is rewritten to this site
(`redirects = "pass"` leaves it alone): with a URI part the URI part becomes the location's
prefix (`path = "/api/"`, `upstream = "http://127.0.0.1:3000/v1/"`: `http://127.0.0.1:3000/v1/x`
becomes `https://example.com/api/x`); without one the origin was asked the path untouched, so
its root is the site's root and only the scheme and host change (`http://127.0.0.1:3000/app/x`
becomes `https://example.com/app/x`), as nginx's `proxy_redirect default` does. Before
0.1.0-alpha.62 a location without a URI part added its prefix again (`/app/app/x`); a location
at `/` was not affected. The location's `add_headers` are
added on 2xx and 3xx answers (HSTS, CORS, cache policy), for proxied and PHP responses
alike.

**WebSockets and other upgrades** need nothing: a request carrying `Connection: Upgrade`
and an `Upgrade` field is forwarded as one, and when the origin answers 101 the connection
becomes a tunnel that copies bytes both ways until a side closes. There is no idle limit on
a tunnel by default (nginx's 60 s read timeout silently dropping idle WebSockets is the
usual surprise); `tunnel_timeout = 3600` sets one, `upgrade = false` refuses upgrades
on a location. What a tunnel does bound is a write: one to either side that does not finish
within `send_timeout` (30 s) closes the tunnel, the way nginx applies `send_timeout` and
`proxy_send_timeout` to an upgraded connection. A client that stops reading while the
application sends to it (a phone that lost its signal) is let go after that, and the application
sees its connection end; an application that stops reading is let go the same way. A quiet tunnel
has no write waiting and is not affected. Each closed tunnel is an `info` line in the error log,
with the direction and the bytes waiting. Until 0.1.0-alpha.114 such a write waited as long as
the kernel retransmitted, about fifteen minutes, holding both connections.

**Options** of `proxy = { ... }`, on a site (defaults for its locations) or a location:

| option | default | meaning |
|---|---|---|
| `host` | `"pass"` | `"pass"` the client's Host, `"upstream"` the origin's address, or a literal name |
| `forwarded` | `"x-forwarded"` | `"x-forwarded"`, `"forwarded"` (RFC 7239), `"both"`, `"off"` |
| `request_headers` | none | fields set toward the origin, `{ "X-Gateway" = "$host" }`; `""` removes (`"X-Real-IP" = ""` stops agensio's own); a field agensio writes itself (`Host`, `X-Forwarded-*`, `Forwarded`) named here replaces agensio's line, sent once |
| `hide` | none | fields dropped from the origin's answer, `["X-Powered-By"]`; before the response-header rules see it, so a rule's `default` for the field fills its place (14c) |
| `redirects` | `"rewrite"` | Location pointing at the origin (its address, or the name given as `host`) rewritten to this site, or `"pass"`. Apart from it, on a site whose plain HTTP redirects (`http`, section 14) an `http://` Location naming the site goes out as `https://` |
| `upgrade` | `true` | forward Upgrade requests and tunnel after a 101 (WebSocket) |
| `tunnel_timeout` | 0 | seconds a tunnel may stay idle in both directions; 0 = no limit |
| `buffering` | `true` | collect the whole answer (memory, then a temp file above `buffer_max`) so a slow client never holds the origin; `false` streams with backpressure |
| `request_buffering` | `true` | collect the request body before connecting; `false` streams it as it arrives |
| `connect_timeout`, `send_timeout`, `read_timeout` | 5, 30, 60 s | 504 when exceeded; `read_timeout` is between two reads from the origin; on a tunnel `send_timeout` bounds each write to either side |
| `keep_conn`, `max_idle`, `idle_timeout` | `true`, 64, 30 s | keep-alive to the origin; idle connections kept per worker; how long one may stay idle before agensio closes it (0 = until the origin does) |
| `max_connections`, `queue_depth`, `queue_wait` | 256, 1024, 5 s | per worker: in flight, waiting, and the longest wait before a 503 with `Retry-After` |
| `head_max` | 64 KB | an origin head larger than this is a 502 |
| `max_fails`, `fail_timeout` | 3, 10 s | consecutive failures that mark a group member down, and for how long |
| `tls` | verify on, system store | `{ verify, server_name, ca }` for `https://` origins |

The pool is per worker, so an origin sees at most workers x `max_connections` connections
and workers x `max_idle` idle ones, none of them idle for longer than `idle_timeout`
(the pool's 250 ms tick closes them, so an origin with a shorter keep-alive timeout, Node's
5 s, should get `idle_timeout` below it). Before a kept connection that has been idle for longer
than a pool tick (250 ms) is reused it is peeked once without blocking: a peer that closed it (php-fpm reloaded, an origin's idle timeout)
is dropped for a fresh connection, so a POST or an upload never meets a dead one. A GET or HEAD whose kept connection turns out dead is
retried once on a fresh one. An origin that is down gives 502, a timeout 504, a full
queue 503; each is logged with the reason and appears in the JSON access log as
`upstream`. `agensio -t` connects to every origin once and warns when it cannot, and
`-t --explain` prints the effective policy of every proxy location.

Not here on purpose: separate buffer-size knobs (nginx's `proxy_buffer_size`,
`proxy_buffers`, `proxy_busy_buffers_size` and their interplay), a `proxy_http_version`
switch, the three-directive Upgrade/Connection incantation for WebSockets, and
`proxy_redirect` rules with regular expressions.

## 12b. Reload without restart

Edit the file, then:

```sh
agensio reload        # validates the file, then signals the running server
```

No path is needed on an installed machine: the file is looked for in the working
directory, then `/etc/agensio/agensio.toml` (and the brew locations on macOS), the same
search every command uses; `-c` points elsewhere. A file found there that the account cannot
read is named with the cause (`cannot be read: Permission denied`, with the line to run it as
root or as a member of the file's group, or to pass `-c`), exit 1; before 0.1.0-alpha.120 the
lookup ended with SIGABRT, and `-c` on such a file said only that it could not be opened. The
server writes its pid to
`server.pid_file`, `/run/agensio.pid` by default (`""` disables it), which is how the
command finds it; `kill -HUP $(cat /run/agensio.pid)` does the same without the
validation step. What
happens in the server, in this order: the file is loaded and checked exactly as `-t`
does, including the hosting rules; certificates are read and new listen addresses are
bound; only then does every worker switch to the new configuration, between requests.
Nothing is interrupted:

- a request being served, an upstream exchange waiting on php-fpm or an origin, a CGI
  process, a WebSocket tunnel: each finishes on the configuration it started with;
- a keep-alive connection serves its next request from the new configuration on the
  same connection;
- a connection on a listen address that was removed serves its current request, then is
  told `Connection: close`; the address stops accepting at once;
- a broken main file or a port that cannot be bound refuses the whole reload, with the
  reason in the error log, and the old configuration keeps serving; a broken site file
  under `sites.d/`, or a site whose certificate cannot be loaded, is set aside instead and
  the other sites' changes apply (12c).

Under a 64-connection load the switch itself costs nothing measurable and no request
fails (`tests/reload.sh`). Restart-only settings (the `applies` column of `docs/keys.md`):
`workers`, `reuse_port`, `user`, `group`, `pid_file`, `listen_tls`, `listen_plain` (the server's
addresses, bound at start as root, section 1c), `sendfile`, `sendfile_max_chunk`,
`tcp_nodelay`, the whole `[cache]` table, and `[control]` `socket` and `provision`. A reload that finds
one of them changed keeps the running value and names each in the error log (`reload:
cache.precompressed, tcp_nodelay changed on disk and take effect at a restart`), and
`agensio ctl validate`, health and the answer of `agensio ctl reload` list them under
`restart_needed` (the reload's answer since 0.1.0-alpha.62). The control plane's role
groups (`admins`, `operators`, `viewers`) apply on reload: the next connection to the socket
is judged by the new groups. Before 0.1.0-alpha.61 the reference called most of the `[cache]`
keys, `stream_chunk_size`, `sendfile_max_chunk` and `tcp_nodelay` reload keys while a reload kept
them, and the role groups needed a restart.

**The file cache across a reload** (since 0.1.0-alpha.120): a location that serves the same files
the same way after the reload keeps its cached entries and their compressed copies (section 20),
so the first answers after it are the ones served before, copies included. "The same way" is what
an entry holds when it is filled: the `root` or `alias`, `index`, `try_files`, `symlinks`, the
content types (`mime_types`, root's and the site's) and the site's `response_compression`
(on, `min_size`, `extra_types`, the codings). A change to any of these, a new location, a new
site or a renamed one (a site is the running one with the same names) starts that location's
cache over, and the entries it had are dropped at once; a site file set aside keeps its running
version, cache included. What a request checks on its own (`hidden_files`, `deny_suffixes`,
`allow_suffixes`, `refuse`, `add_headers`, the access, password, redirect and response-header
rules) is not in an entry and applies at once with the cache kept. A file changed on disk is
caught by the revalidation (section 7) as always. The error log says what happened at level
`info` (`cache kept across the reload for 12 site(s), 40 location(s); started over where the
serving changed: example.com (/assets/: root)`), and `agensio ctl status` shows the cache under
`cache` (`entries`, `bytes`, `open_files`, with their budgets). A restart starts the cache over.
Before alpha.120 every reload started every site's cache over, and the entries of the
configuration that ended stayed in memory until the cache was full (the test VPS's alpha.119
report measured a site's CSS and JS going out uncompressed after a `site_update` on another site).

## 12c. One broken site file never stops the others

The main file is all or nothing: an error there refuses the start or the reload, as before.
Each file an `include` pattern brings in is loaded on its own, and a site file that does not
load is **set aside** whole while every other site loads. Before 0.1.0-alpha.62 one mistake in
any site file stopped the whole host: the packaged unit runs `agensio -t` before it starts the
server, so a misspelt key in one customer's file kept every site down at boot, and every
reload (certificate renewals included) was refused until someone fixed it.

What sets a file aside:

- an error in it: TOML syntax, an unknown key (`unknown key 'refsue' (did you mean
  'refuse'?)`), a value out of range, a preset that does not fit;
- a certificate and key pair that does not load (section 14): a site that was serving keeps
  the certificate it loaded before, a new one is not served;
- an access log that cannot be opened (8c): a link planted below the log directory, a file the
  server's account cannot create on a reload, a path a file the server's account can write may not
  name; a site that was serving keeps the log it opened before. This is the one cause that sets aside
  a site of the main file, alone, the file's other sites served (0.1.0-alpha.130);
- something its sites need that does not load: the site's root additions file (section 15;
  a site is never served without the locations root added, which may be the ones that
  protect it), or a users file of a `[[site.auth]]` rule (19b). An additions file that does
  not load and names no site is named itself;
- a hosting rule its site breaks (section 11: a root others can write into, a socket of
  another account, ...; a credential file readable by others sets nothing aside, the helper
  makes it private). A site is served only by a
  version that passes every rule now, so on reload the version that runs is kept only when it
  passes: an edit that breaks a rule keeps it, a root opened to others while the site serves
  takes the site down;
- a conflict with another file: a name both claim on one address, two catch-all sites on
  one address, a TLS and a plain site on one address, two sites of one user that size its
  php-fpm pool differently. One of the two files yields, the rest of it with it: the main
  file never yields; between site files, the one the server serves keeps its place (unchanged
  before edited, edited before new), and at a tie the later file in load order (alphabetical
  within a pattern) yields. A conflict inside the main file fails the load. At a start, "the
  one the server serves" is the record the server keeps of its site files, `<state_dir>/.server/served`,
  rewritten after every start and reload, so a restart decides what the last reload decided: a
  file added while the server runs never takes a name at the next boot that the reload kept from
  it. Without the record (the first start, a lost state directory) load order decides, and the
  error log warns for each name it decided, as `agensio -t` does. Before 0.1.0-alpha.64 a restart always went by load order, so a file that
  sorted earlier took the name at the next boot;
- a name a file set aside for its own error claims: its names stay its own, so another file
  does not take one over without the broken file's access rules, passwords and root additions.
  A file claiming one on the same address yields with it when it would have yielded to the file
  loaded (it ranks lower, the record counting at a start, or as low and later in load order), and the name answers
  `421` there until the broken file loads; a site the server serves keeps its name, so a new
  broken file never takes one down. The names come from the file's `[[site]]` tables, or, when
  it is not TOML at all, from its `server_name`, `listen` and `default` lines; a site whose
  names cannot be read is said in the warning. In 0.1.0-alpha.62 a duplicate that had yielded
  to a file took its name over when that file broke, at the next start.

What happens then:

- **at start** the file's sites are not served; the server starts with the others (it
  refuses to start only when no site at all is left);
- **on reload** a file whose sites were being served keeps serving the version that loaded
  before (its *last good version*), and the other files' changes apply; a new file that does
  not load is simply not served. Fix the file and reload, and it loads like any other;
- every file set aside is a line in the error log (`... sites.d/b.example.toml set aside: ...
  (the version loaded before keeps serving its sites)`), a `site_file_held_back` error in
  health with the loader's message (`hosting_rule` when a hosting rule set it aside, with the
  owner or mode to fix), the file in `agensio ctl status`
  (`site_files_held_back`) and in `agensio ctl validate` (`held_back`, which says what the
  next reload would do with the files on disk, their certificates loaded as the reload loads
  them: `certificate` when that set the file aside, `hosting_rule` for a hosting rule);
- `agensio -t` prints a warning per file set aside and still exits 0, because the server
  would start and serve the other sites; `agensio -t --strict` exits 1 for the same, for
  scripts and CI that want every file to load. It loads each certificate and key pair as the
  start does (section 14), so a site the start would set aside for its certificate is named
  too; run it as the account that starts the server (root, with `server.user`), since run as
  another it cannot read a key only root reads and says it did not check it;
- the control plane never reports a change as done when its own file was set aside:
  `site-create`, `site-update` and `site-enable` reload with their file required to load,
  and on a refusal undo what they wrote (a new file removed, the previous version put back,
  an enabled file disabled again) and answer 409 with the loader's error;
- a file the control plane wrote that a newer version refuses (its form changed, as with
  `hsts` in 0.1.0-alpha.75 and the plain block in alpha.76) is set aside like any other, and
  `agensio ctl site-update NAME --yes` (MCP `site_update`, with any other fields or none) writes
  it again in this version's form from its first line and reloads, which health's
  `site_file_held_back` names for it. Before 0.1.0-alpha.78 `site-update` answered "no such site"
  for a site whose file was set aside; for a hand-written file set aside it answers 409 with the
  file and the loader's error since alpha.80, since only an edit by hand mends it.

```sh
agensio -t -c /etc/agensio/agensio.toml            # warning: .../sites.d/b.example.toml set aside, its sites not loaded: ...
agensio -t --strict -c /etc/agensio/agensio.toml   # the same, exit 1
agensio ctl health                                 # site_file_held_back, with the file, the error and what serves meanwhile
```

What still refuses the whole start or reload: the main file, a site in it, the server's own
account (section 11), a listen address that cannot be bound.

**The record of the site files served.** So that a restart decides a conflict between site files
the way the last reload did, the server keeps a small file, `<state_dir>/.server/served`
(`/var/lib/agensio/.server/served` by default): one line per site file whose sites it serves, a
digest of the text those sites were loaded from, then the file's path. The main file is never
listed, since it never yields:

```
13002516248778111997 /etc/agensio/sites.d/example.com.toml
4467891120098732211 /etc/agensio/sites.d/shop.example.com.toml
```

- **Written** after every start, once the privileges are dropped, and after every reload that
  switched; replaced whole (a temporary file renamed), so it is never half written. A refused
  reload leaves it as it was; a certificate refresh does not touch it. A site that keeps its last
  good version is listed with the digest of that version, not of the broken file on disk.
- **Read** at a start and by `agensio -t` (and before the helper writes the php-fpm pools), for one
  thing only: when two site files claim the same name on the same address, or both a catch-all,
  the file listed and unchanged since keeps it, then one listed but edited since, then one not
  listed; at a tie, the later in load order yields. The same ranking applies to the names of a
  file set aside for its own error. Without a conflict on the host it changes nothing.
- **Never** does it make a file load, add a site or bring back an older version: at a start
  there is nothing in memory to keep, so a file set aside is not served, as before.

Three cases:

1. *A newcomer at the next boot.* `example.com.toml` serves `example.com` with an access rule
   on `/`; a copy, `0old.toml`, is dropped into `sites.d/` claiming the same name on the same
   address. The reload sets `0old.toml` aside (health says so). The host reboots: the record
   lists `example.com.toml`, so it keeps `example.com` and `0old.toml` is set aside again.
   Without the record `0old.toml` sorts first and would serve `example.com`, without the access
   rule (what 0.1.0-alpha.63 and earlier did).
2. *A broken newcomer.* `shop.example.com.toml` serves its site; a new file with a typo claims
   `shop.example.com` too. The reload keeps the shop serving, and so does the next start: the
   record lists the shop's file, so the broken file's claim does not take the name down.
3. *No record.* The first start ever, a new `state_dir`, or the file deleted: load order
   decides, as before 0.1.0-alpha.64, and each conflict it decided is a warning in the error log
   (and from `agensio -t`) naming the name and the file that kept it: `no record of the site
   files served before (...): load order decided: example.com on 0.0.0.0:443 is claimed by two sites
   (0old.toml and example.com.toml); a name answers for one site on an address; 0old.toml keeps
   its place`. Check that file is the one you want, or fix the other. With no conflict the line
   is a note at level `info`. From then on there is a record. A `-t` run as an account that
   cannot read the record (it is the server account's, `0700`) says so instead: run it as root.

Nothing needs doing with it. `cat /var/lib/agensio/.server/served` shows which site files the
server serves. Deleting it only makes the next start decide conflicts by load order; it needs no
backup. If the server cannot write it (a `state_dir` its account cannot reach), the error log
says so once: `the record of the site files served could not be written (...)`. The record only
settles a conflict; the conflict itself stays a mistake to fix: health names the file set aside
the whole time, and removing or correcting it ends the conflict.

## 13. CGI

`handler = "cgi"` (or just a `cgi = { ... }` table) on a location runs the requested file
as a process per request with the CGI/1.1 environment, for the legacy applications that
still ship that way:

```toml
[[site.location]]
path = "/cgi-bin/"
alias = "/var/www/cgi-bin"
cgi = { max_connections = 8, read_timeout = 30, env = { "APP_ENV" = "production" } }

[[site.location]]                 # scripts that need an interpreter in front
path = "/legacy/"
cgi = { interpreter = "/usr/bin/perl" }
```

The script is the longest leading part of the path that names a regular file (Apache's
rule), the rest is `PATH_INFO`; a directory URI takes the location's `index`
(`index.cgi` by default, never the site's: before 0.1.0-alpha.70 a CGI location without one ran
the site's `index.html` as a script). The process runs in the script's directory with the same
variables the FastCGI handler sends (`REQUEST_METHOD`, `SCRIPT_NAME`, `PATH_INFO`,
`QUERY_STRING`, `CONTENT_LENGTH`, `REMOTE_ADDR`, `HTTPS`, `HTTP_*` and the rest), the
location's `env` entries, and a plain `PATH`. The request body is its stdin, its stdout
is the response (a CGI head with `Status:` or `Location:`, then the body until it exits),
its stderr goes to the error log. The options are those of section 7 with these
defaults: `max_connections = 8` processes per worker and `queue_depth = 32` waiting
(more are a 503), `read_timeout = 30` (no output for that long: the process is killed,
504), buffering and request buffering on. Every other descriptor of the server is closed
in the child. Not a fast path: a process per request is what CGI is.

## 14. TLS

The administrator's guide to certificates, automatic and your own, renewal, what health says and
troubleshooting, is [tls.md](tls.md); this section is the reference.

```toml
[[site]]
server_name = ["example.com"]
root = "/var/www/example"
tls = { cert = "/etc/ssl/example/fullchain.pem", key = "/etc/ssl/example/privkey.pem" }
```

A listen address is either plain or TLS for every site on it.

Each certificate and key pair is loaded once per start or reload, before the listeners are
built. A pair that does not load (a file the server's account cannot read, not PEM, a key that
is not the certificate's) sets its site's file aside, and the other sites start or reload
(section 12c); a site of the main file refuses the whole start or reload. `agensio -t` loads the
pairs the same way and names those files ahead of the start (before 0.1.0-alpha.65 it only
looked for the files), and `agensio ctl validate` and health ahead of the next reload, reading
them as the server's account does (0.1.0-alpha.66). A site that was
serving keeps the certificate it loaded before: a renewal whose key the server cannot read
(root's `0600` after the privilege drop) or a broken file never takes it down, the error log
says `the certificate loaded before keeps serving`, and health names the file until the files
load. Before 0.1.0-alpha.64 such a pair refused the whole reload, every other site's change
and renewal with it, and at start it kept the server from starting.

**A renewed certificate is picked up by itself.** The server stats every certificate and key
file once an hour and loads the pairs whose files changed (certbot replaces the target of its
`live/` links; a `cp` over the file counts too), through the certificate refresh: the running
configuration's certificates read again, no configuration file read, so a broken main or site
file never keeps a renewal waiting. `agensio ctl cert-renew NAME` (MCP `cert_renew`) loads a site's
own files at once and answers what happened (`loaded the certificate valid until ...`,
`unchanged`, or why it could not be loaded, the certificate served staying); a renewal hook can
run it instead of `agensio reload`. A pair that does not load keeps the certificate served and its
error goes to health (`certificate_not_loaded`). Before 0.1.0-alpha.64 nothing watched the files:
a renewal waited for a reload, which another file's error could refuse. `agensio ctl status` (MCP
`server_status`) shows the watch at work under `certificate_watch` (its last and next run, the pairs,
what it loaded), and health says `certificate_watch_stalled` when it is two runs late
([tls.md](tls.md) 3.3).

**A key the server's account must read.** With `server.user`, the start reads every certificate
and key as root and each reload after that as that account (its group and supplementary groups),
so a key only root can read, certbot's `0600` key in its `0700` `live/` and `archive/`
directories for one, works at boot and is never read again: renewals are not served until a
restart. `agensio -t`, the start (the error log) and health (`tls_key_unreadable`) check it ahead
of time, every directory on the way included, and give root's commands, for example `chgrp
agensio /etc/letsencrypt/live && chmod g+x /etc/letsencrypt/live; chgrp agensio
/etc/letsencrypt/live/example.com/privkey.pem && chmod 640 ...`; a reload that meets it says the
same beside `the certificate loaded before keeps serving`. Keys `tls = "auto"` writes are the
server account's already. Adding the server's account to a group that reads the keys (Debian's
`ssl-cert` for `/etc/ssl/private`) works too.

**What health says about certificates.** It judges the certificate each site serves, read from
the server's memory, not the file on disk (before 0.1.0-alpha.64 it read the file, so a renewal
written but not loaded looked fine while the expiring one kept being served):
`certificate_expired` and `certificate_expiring` (a managed certificate with under 14 days left)
give the served one's date; `certificate_not_issued` is an automatic site still on its
placeholder; `certificate_not_loaded` is a file on disk newer than the one served, with why (a
reload loads it, or the server could not load it, with the error); `acme_renewal_overdue` (an
error) is an automatic certificate more than a day past its renewal point, a third of its
lifetime left, with the CA's error from the last failed order; `acme_renewal_failed` (a warning)
is a failed order before that point, retried every hour.

### Automatic certificates

```toml
[server]
acme = { email = "admin@example.com" }

[[site]]
server_name = ["example.com", "www.example.com"]
root = "/var/www/example/public"

[[site]]
server_name = ["example.com", "www.example.com"]
root = "/var/www/example/public"
tls = "auto"
```

`tls = "auto"` makes agensio obtain and renew the certificate itself from an ACME
(RFC 8555) certificate authority, Let's Encrypt by default. There is no separate client
to install, no cron job and no reload hook: the server does the whole thing and switches
to the new certificate through the certificate refresh (the running configuration's
certificates loaded again, no configuration file read), so no request is interrupted and no
broken file elsewhere can hold it back.

What happens:

1. **Start.** If no certificate exists yet, a self-signed placeholder is written so the
   listener can come up at once. An order is placed immediately.
2. **Validation (HTTP-01).** The CA fetches
   `http://<name>/.well-known/acme-challenge/<token>` for every name in `server_name`.
   agensio answers that path itself, on any plain listener and before any site or location
   rule, so nothing in your configuration can get in the way. The names must therefore
   resolve to this server and **port 80 must be reachable from the internet** (the plain
   site above). Nothing else needs configuring: no location, no writable webroot.
3. **Issue.** A fresh P-256 key is generated per certificate, a CSR covering all the
   names is finalized, the chain is downloaded and both files are written atomically.
4. **Switch.** The server loads it through the certificate refresh (`certificates refreshed:
   site ...: loaded the certificate valid until ...` in the error log): new connections get the
   new certificate, connections in flight finish undisturbed.
5. **Renew.** Once an hour the certificates are checked and renewed when a third of
   their lifetime is left (day 60 of a 90-day certificate, day 4 of a 6-day one), so
   short-lived profiles work too. A failed order is logged with the CA's reason and
   retried an hour later; the current certificate keeps serving meanwhile. Adding a
   name to `server_name` triggers a new order at the next check (or at once on reload).

`[server] acme` keys:

| key | default | meaning |
|---|---|---|
| `email` | required | The account contact. The CA sends expiry warnings there; it never appears in a certificate. |
| `directory` | Let's Encrypt production | The CA's directory URL. Staging: `https://acme-staging-v02.api.letsencrypt.org/directory`; any RFC 8555 CA (ZeroSSL, Buypass, Google, a private step-ca or Pebble) works. |
| `storage` | `<state_dir>/acme` | Where the account key and the certificates live: `account.key`, then `<first server_name>/key.pem` (0600) and `<first server_name>/fullchain.pem`. Started as root with `server.user`, the tree is handed to that user so renewals work after the privilege drop. |
| `ca` | system trust store | A PEM file to trust for the directory's own TLS; only for private CAs and tests. |

### HTTPS only

```toml
[[site]]
server_name = ["example.com", "www.example.com"]
root = "/var/www/example/public"
tls = "auto"
hsts = "1y"
```

**Plain HTTP is the site's `http` key** (0.1.0-alpha.76, [redirects.md](redirects.md) 2), so one
block serves both schemes:

| `http` | what a request over plain HTTP gets |
|---|---|
| left out, TLS on port 443 | `"redirect"`: the site also listens on port 80 at the same addresses (`0.0.0.0:443` gives `0.0.0.0:80`, `[::]:443` gives `[::]:80`) |
| left out, TLS on another port | `"off"`: no plain listener (a table below names one) |
| left out, no TLS | `"serve"`: a plain site, as before |
| `"redirect"` | a `308` to `https://` with the same name, path and query |
| `"serve"` | the site itself, over both schemes; refused with `hsts` (it tells browsers to use HTTPS only) |
| `"off"` | no plain listener: port 80 belongs to something else on the machine |
| `{ listen = ["0.0.0.0:8080"] }` | the plain addresses of a TLS site on another port; the redirect names the TLS port (`https://example.com:8443/...`); `mode = "serve"` serves them instead |

The redirect is a `308`, which keeps the method (a form's POST stays a POST), with
`Cache-Control: max-age=86400`: without a lifetime Chromium keeps a permanent redirect forever,
so a mistake could never be undone for the visitors who saw it. The `Location` names the site's
own spelling of the name; a name only a catch-all took (the client chose it) is written as sent
and carries `Cache-Control: no-store`. Certificate validation is answered before it: agensio's
own ACME tokens first, then the site's files under `/.well-known/acme-challenge/` and
`/.well-known/pki-validation/` (certbot's webroot mode, a CA's file check), so no setting here
breaks a certificate's issue or renewal. Only files: a regular file under the root is served, and
anything else there is a `404`, never a redirect, with nothing run (no front controller, no PHP,
no `try_files` fallback, no proxied application; a proxied preset, whose root is a project
directory, answers `404` to all of it), so no application answers plain HTTP there. Before
0.1.0-alpha.77 those requests went through the site's locations.

**An application's own `http://` redirects.** An application that does not trust agensio as
its proxy builds its redirects from what it sees, plain HTTP: `Location:
http://example.com/login`. On a site whose `http` is `"redirect"`, such a Location naming one of
the site's names (without a port, with port 80, or with the TLS port, as the Host the application
was given) goes out as `https://` on the site's TLS port, for proxied, PHP and CGI answers alike
(nginx's `proxy_redirect http:// https://`), so the visitor takes no hop through the plain port.
Any other Location passes as the application sent it. The application is still better told to
trust the proxy (section 10), so its links and cookies are right too. Since 0.1.0-alpha.79.

The plain addresses meet the other sites there as a plain site does: a name answers for one
site on an address, an address has one catch-all and is plain or TLS for every site on it. A
separate plain `[[site]]` for the same names on port 80, the form before 0.1.0-alpha.76, is
refused with the conflict, which names `http = "off"`; `redirect = "https"` itself is refused,
naming this key. Remove the plain block when you move a file over.

**Behind a proxy that holds the certificate** (a load balancer, a CDN's "Flexible" mode), every
request reaches agensio over plain HTTP. Such a site has no `tls`, and `http = "redirect"`
redirects only the visitors who really used plain HTTP: a request from a `trusted_proxies`
address marked `X-Forwarded-Proto: https` is served (with the site's HSTS), one marked `http`,
or a client that is not a trusted proxy, gets the `308` (section 10, [redirects.md](redirects.md) 2.4).
A trusted proxy that sends no `X-Forwarded-Proto` at all is taken as plain HTTP, never as HTTPS on a
guess, so its HTTPS visitors would loop; the error log (once a minute) and health
(`proxy_scheme_missing`, 0.1.0-alpha.86) name the proxy and the site.

**One canonical host: `canonical`** (0.1.0-alpha.81, [redirects.md](redirects.md) 3). One block
lists every name; `canonical` names the one the others redirect to:

```toml
[[site]]
server_name = ["example.com", "www.example.com"]
canonical = "www.example.com"
root = "/var/www/example.com/web"
tls = "auto"                        # one certificate covering both names
```

| request | answer |
|---|---|
| `https://example.com/x?y` | `308 → https://www.example.com/x?y` |
| `http://example.com/x?y` | `308 → https://www.example.com/x?y`, scheme and host in one hop |
| `http://www.example.com/x?y` | `308 → https://www.example.com/x?y` |
| `https://www.example.com/x?y` | served |

The redirect keeps the path and the query and is kept a day (`Cache-Control: max-age=86400`);
over HTTPS, and on a site that serves plain HTTP, the scheme and the port the client used are
kept: the port its Host field names, which a browser always sends for a port other than 80 or
443 (a test with `curl -H 'Host: www.example.com' http://127.0.0.1:8080/` names none, so its
redirect goes to the default port; `--resolve` keeps the port in Host). With `hsts` on, a plain request for another name goes to that name's HTTPS first, which then
redirects to the canonical name with HSTS, so the other name learns HSTS too (redirects.md 4.3).
`canonical` must be one of the site's exact `server_name` entries; only the names the site lists
redirect, so a request by IP address or for a name only a catch-all takes is answered as before,
and certificate validation over plain HTTP is answered on every name. Set the application's own
address to the canonical `https://` one (WordPress `home` and `siteurl`, Laravel `APP_URL`,
Drupal `$base_url`), or the two redirect each other (health asks each such site for its home page
and reports `app_redirects_elsewhere` with the setting, redirects.md 3.4); the base URL agensio hands Django's settings
and the tasks is the canonical one. The same with the names swapped makes the bare name canonical.
A managed site sets it with `site_update` `canonical` (`agensio ctl site-update NAME --canonical
www.example.com`).

**A domain moved away** to another host is a site of its own with one rule from `/`
(section 14b): every request goes there with a `301`, path and query kept. It needs a certificate
for its names too (browsers check it before following any redirect), which `tls = "auto"`
provides, and its port 80, which comes with port 443, goes straight to the new host in one hop:

```toml
[[site]]
server_name = ["example.net", "www.example.net"]
tls = "auto"

[[site.redirect]]
from = "/"
to = "https://www.example.org"
status = 301
```

Until 0.1.0-alpha.82 this was the string key `redirect = "https://www.example.org"`, refused now
with the rule to write.

**HSTS.** `hsts = "1y"` sends `Strict-Transport-Security: max-age=31536000` (a year, this host
only) on every answer the site gives over HTTPS: pages, files, PHP, a proxied application, error
pages and redirects. An application's own copy is replaced, so browsers see one; one that commits
browsers to more (a longer `max-age`, `includeSubDomains`, `preload`) is noted in the error log and by
health (`hsts_narrows_application`, 0.1.0-alpha.86), and `hsts = "application"` lets it through. A plain-HTTP
answer never carries it (RFC 6797 7.2); behind a proxy that ends TLS, an answer the proxy marks
`X-Forwarded-Proto: https` from `trusted_proxies` does. It is deliberately not automatic: once a
browser has seen it, it refuses plain http for that host until `max-age` expires, so set it when
the https site is known to work. The value is the lifetime itself, the commitment browsers make
(RFC 6797 11.2: set willfully, never by default); `hsts = true`, which named none and meant a year,
is refused since 0.1.0-alpha.101, naming the form:

```toml
hsts = "1w"                                    # a duration: s, m, h, d, w, y ("1y", "2y"); at most ten years
hsts = 604800                                  # or seconds, the form applications publish
hsts = { max_age = "2y", subdomains = true }   # every subdomain too (includeSubDomains)
hsts = 0                                       # tells browsers to forget it: keep it for as long as the old lifetime
hsts = "application"                           # agensio sends none; the application's own goes out unchanged
hsts = "none"                                  # none on any answer: an application's own is removed
```

`subdomains` (`includeSubDomains`) makes every subdomain HTTPS-only in browsers that saw it,
including ones on other servers; a subdomain without TLS becomes unreachable. Raise it in stages
(`"5m"`, `"1w"`, `"30d"`, `"1y"`, each after the one before ran its whole lifetime); on a managed site
health's `hsts_ramp` names each next stage ([redirects.md](redirects.md) 4.4). Preload is not
offered. A location's `add_headers` cannot carry `Strict-Transport-Security` (refused at load):
until 0.1.0-alpha.75 it did, and reached neither the PHP pages nor the error answers. A managed
site sets it with `site_update` `hsts: "1y"` (`agensio ctl site-update NAME --hsts 1y`, `--hsts-subdomains`
for `includeSubDomains`; at most two years there). Health suggests
it (`hsts_suggested`, info) once the site has served a real certificate for a week with no
certificate finding, or says the application already sends its own (`hsts_from_application`, with
its value, which `hsts = "1y"` would replace, and the value that matches it); `hsts = "application"` (`hsts:
"application"`, `--hsts application`: the application decides) and `hsts = "none"` (`hsts: "none"`, `--no-hsts`: none,
guaranteed) each record the decision and silence that (0.1.0-alpha.104; `hsts = false`, which meant what `"application"`
does, is refused naming it), and with `hsts` on the certificate findings `certificate_expiring` and `acme_renewal_failed`
are errors ([redirects.md](redirects.md) 4.2). On a managed site that sends a lifetime, `false` first
renders `hsts = 0` until the last lifetime it sent has ended (the answer's `hsts_note`, the file's
comment and health's `hsts_clearing` name the date; `hsts_cleared` after it), refuses a second `false`
before that date and writes `hsts = "none"` after it, the application's field cleared too when it sends
one; `"application"` hands over to the application at once, the application asked for `/` first when
none of its answers was seen since the start ([redirects.md](redirects.md) 4.5, 0.1.0-alpha.102 to .104).

Rules checked by `agensio -t`: `tls = "auto"` needs `[server] acme`; `server_name` must
list real host names (no `*`, no wildcards: those need DNS-01, which is not in this
release); an `email` is required. `agensio -t --explain` prints the resolved file paths.
Manual certificates on other sites, `tls = { cert, key }`, coexist with automatic ones.

Backups: the `storage` tree is all there is to keep. Restoring it on another machine and
starting agensio there continues renewals without a new account or order. Deleting a
site's directory orders a new certificate at the next start.

Not in this release: TLS-ALPN-01 (for servers with no port 80), DNS-01 and wildcards,
OCSP stapling, external-account binding. They follow on the roadmap (H3a) in the order
users ask for them.

Testing against a local CA: `tests/acme.sh build/agensio` starts Pebble (Let's Encrypt's
test server, `bench/acme/docker-compose.yml`), orders a certificate for
`host.docker.internal` over port 5002, verifies the served chain against Pebble's root
and checks that a restart keeps the certificate.

## 14b. Path redirects: `[[site.redirect]]`

The design, with the reasons and what the research of nine servers and many applications found, is
[redirects.md](redirects.md) section 5. A rule sends one path, or a section, somewhere else:

```toml
[[site.redirect]]
from = "/blog"          # a section: /blog, /blog/ and /blog/2024/post, never /blogger
to = "/news"
status = 301            # required: 301, 302, 307, 308 or 410

[[site.redirect]]
from = "/about-us"
match = "exact"         # this path alone
to = "/about"
status = 301

[[site.redirect]]
from = "/index.php?page=contact"   # an old address that put the page in the query: exact rules only
match = "exact"
to = "/contact"
status = 301

[[site.redirect]]
from = "/press-2019"
status = 410            # gone, no new address: search engines drop a 410 sooner than a 404
```

| request | answer |
|---|---|
| `/blog/2024/post?x=1` | `301 → /news/2024/post?x=1` |
| `/blogger` | served (not the segment `blog`) |
| `/about-us?ref=mail` | `301 → /about?ref=mail` |
| `/index.php?lang=el&page=contact` | `301 → /contact` (any order, other parameters ignored, the old query dropped) |
| `/press-2019/photos` | `410 Gone` |

| field | values | default |
|---|---|---|
| `from` | a normalised path, case-sensitive; an exact rule may add the query parameters it requires | required |
| `match` | `"prefix"` (whole segments) or `"exact"` | `"prefix"` |
| `to` | a path on this site, or an `https://` or `http://` URL | required, none with `410` |
| `status` | `301`, `302`, `307`, `308`, or `410` | required |
| `remainder` | `"keep"` or `"drop"` (prefix rules) | `"keep"` |
| `query` | `"keep"` or `"drop"` | `"keep"`; `"drop"` for a rule whose `from` names query parameters |
| `cache` | a duration (`"1d"`, `"30d"`, seconds) or `"none"`; permanent statuses only | `"1d"` |

- **The most specific rule decides, never the order:** the longest `from`, and an exact rule
  before a prefix of the same path. Two rules with the same `from` are refused. People used to
  other platforms expect "the first match wins": it does not apply here.
- **Matching is case-sensitive**, as on every hosting platform: `/Blog` is another address, so a
  rule that only fixes the case is allowed. An exact rule matches its own path only: exact `/docs`
  does not match `/docs/`, so a rule from exact `/docs` to `/docs/` is legal.
- **Rules match the path the client asked for**, normalised once, never a target `try_files` or a
  directory's index reached internally: a rule from `/index.html` to `/` cannot catch a
  single-page application's fallback to its shell.
- **What a rule keeps:** a prefix rule's rest of the path follows its target (`remainder =
  "drop"` sends a whole section to one page); the request's query follows the target's own after
  `&` (`query = "drop"` leaves old tracking parameters behind); a fragment in `to` is sent, and
  without one the browser keeps the one it had (RFC 9110 10.2.2).
- **Which status:** `301` or `308` when the move is final, `302` or `307` while testing or for
  something temporary; `307` and `308` keep a POST a POST, `301` and `302` turn it into a GET in
  every browser. Permanent redirects carry `Cache-Control: max-age=86400` unless `cache` says
  otherwise: without a lifetime Chromium keeps a `301` or `308` forever, and a mistake could never
  be undone for the visitors who saw it.
- **Where rules stand:** certificate validation over plain HTTP first (section 14, never
  redirected), then the scheme (`http`) and the host (`canonical`), then `refuse` (a refused path
  is a `404`, never redirected), then the rules, then the access and password rules (a redirect
  reveals no content, and its target meets its own rules), then the locations. Scheme, host and
  rule are one hop: `http://www.example.com/blog/x` goes straight to
  `https://example.com/news/x` with the rule's status. With `hsts` on, a plain request for a name
  that is not canonical goes to that name's HTTPS first (4.3 of the design).
- **The `Location` is written by agensio, byte by byte:** a target on the site stays relative (it
  never depends on the Host the client sent); the rest of the path and the query are
  percent-encoded again, so no control character, space or backslash reaches it; one `/` at the
  join (`from = "/old/"`, `to = "/"`: `/old/x` goes to `/x`); a path that spelled a separator as
  `%2F` or `%5C` is not redirected by a prefix rule.
- **Refused at load:** a rule that would redirect forever or rules that redirect each other in a
  circle (each rule's target is followed through the site's own rules), the same `from` twice, a
  rule a `refuse` pattern makes unreachable, a `to` with a user name, another scheme, `..`
  segments, a space or a control character, `cache` on a temporary status, more than 1,000 rules
  in a site.
- **Noted** by `agensio -t`, the error log, health, `site_show` and, on a managed site, the answer of
  the `site_create` or `site_update` that made it (`redirect_notes`, alpha.85): a chain (a target the site redirects
  again: point the first rule at the final target), a rule from `/` with `remainder = "drop"` (every
  old page to one address, which search engines read as a soft 404), a rule under an access or
  password rule (it answers first, so anyone sees where it sends), a rule over the certificate
  validation paths.
- **Cost:** exact rules are found in a hash table and prefix rules behind a test of the path's
  first byte, so a site with many rules pays a lookup, and one without pays one test.

A site that only redirects, a rule from `/` to another host, needs no `root`. Since 0.1.0-alpha.82,
when the string key `redirect = "https://host"` went.

**On a managed site** (0.1.0-alpha.83) the rules are `site_update`'s `redirects`, the list sent whole
and judged by the same parse and checks as a site file's; `agensio ctl site-update NAME --redirect
"/blog /news 301" --redirect-exact "/about-us /about 301" --gone /press-2019` (the target and the
status the last two words), `--redirects-file rules.json` for a migration's list, `--no-redirects`
to clear. `path_check` (`agensio ctl path-check NAME PATH`) names the rule that decides a path,
the `Location` it sends and, over plain HTTP, the one hop; with proposed rules (`--redirect ...` on
`path-check`, MCP `path_check` `redirects`) it answers as if they applied and changes nothing, so a
list is checked before it goes live. `site_show` lists the rules in force and what the load noted.

## 14c. Response headers: `[[site.response_headers]]`

0.1.0-alpha.89, the design in [headers.md](headers.md). Rules set, default or remove fields by path,
on **every answer the site gives**: a file, a PHP page, a CGI script, a proxied application,
agensio's own error pages (404, 403, 405, 413, 502, 504...), the password prompt, a redirect, an
`OPTIONS` answer, a `304`. A request takes the same fields whichever location answers it and whatever
internal hops it makes (`try_files`, a directory's index): rules match the path the client asked for.
Not covered, because no site is known yet or the answer is not a site's: a malformed request (400), a
name the listener does not serve (421), an ACME challenge, a `1xx`, the bytes of a WebSocket.

```toml
[[site.response_headers]]
path = "/"
set = { "Referrer-Policy" = "strict-origin-when-cross-origin", "X-Content-Type-Options" = "nosniff" }
default = { "X-Frame-Options" = "SAMEORIGIN" }
remove = ["X-Powered-By"]

[[site.response_headers]]
path = "/embed/"
remove = ["X-Frame-Options"]          # a page another site may frame

[[site.response_headers]]
path = "/assets/"
when = "success"
set = { "Cache-Control" = "public, max-age=31536000, immutable" }

[[site.response_headers]]
path = "/"
endings = ["svg"]                     # the SVG files agensio serves: no script runs in one opened alone
set = { "Content-Security-Policy" = "script-src 'none'" }
```

| key | values | default |
|---|---|---|
| `path` | a normalised path: a prefix covers it and everything below it on a segment boundary, in any capitalisation (`/assets`: `/assets/x`, never `/assetsx`); `"/"` the whole site | required |
| `match` | `"prefix"` or `"exact"` | `"prefix"` |
| `set` | field names and values: sent with this value, replacing every copy the answer had | none |
| `default` | field names and values: sent only when the answer has no copy | none |
| `remove` | field names: every copy deleted | none |
| `when` | `"always"`, or `"success"` (2xx and 304 only) | `"always"` |
| `endings` | file endings (`["svg"]`, `["woff", "woff2"]`, `"tar.gz"`; any case, a leading dot allowed): only the files agensio serves whose name ends so | none: every answer |

- **Per field, the most specific rule decides.** For each field the rule with the longest path that
  names it decides (at one path an exact rule before a prefix one); rules naming different fields
  all apply, and the order they are written in never matters. A deeper rule changes the fields it
  names and no others: `/embed/w.html` above keeps `Referrer-Policy` and `nosniff` from `/` and loses
  `X-Frame-Options`. This is the opposite of nginx's `add_header`, where a nested block drops every
  inherited field.
- **`set` replaces, `default` fills a gap, `remove` deletes**, whoever put the field there: the
  application, a location's `add_headers`. With `set` the browser never sees two copies; with
  `default` the application's own value wins (WordPress's admin sends its own `X-Frame-Options`).
  For a Content-Security-Policy on an application site use `default`: `set` would replace the
  application's policy, often with nonces its pages need (noted by `-t`).
- **`endings` reads the file agensio serves, not the address** (0.1.0-alpha.90): a rule with
  `endings` applies to an answer agensio makes from a file on disk, after `try_files` and a
  directory's index, when that file's name ends with one of them; never to an application's answer
  or an error page. So `/about/`, served from `about/index.html`, is an `html` answer, a single-page
  application's routes served from its shell are too, and a `/sitemap.xml` that PHP makes is the
  application's, untouched by a rule for `xml` files, as nginx's `location ~ \.xml$` loses its
  fields when the request falls back to PHP. At one path a rule whose endings the file has decides
  before one without; a longer path still decides before both. An ending inside another counts for
  it (`gz` for `a.tar.gz`), so two rules at one path naming one field with such endings are
  refused, as are endings the site never serves itself: `php` where PHP runs it, an ending its preset
  answers 404 for (`inc`, `log`, `sql` on a PHP preset).
- **`when = "success"`** applies a rule to 2xx and 304 answers only; on any other answer the next
  rule naming the field decides. A `Cache-Control` or `Expires` that lets caches keep the answer
  (`max-age` above 0, `s-maxage`, `public`, `immutable`) is refused without it, so a 404 is never
  kept for a year; `no-store`, `no-cache`, `private` and `max-age=0` are accepted anywhere.
- **What no rule loosens:** behind a password (`[[site.auth]]`) the answer stays `Cache-Control:
  private` and the CDN fields stay dropped, so the rules leave those fields alone there; the fields
  agensio writes on its own 401, 403 and 503 (`no-store`, `Retry-After`) stand. On an application's
  answer (0.1.0-alpha.99, [headers.md](headers.md) 2.4): its `Cache-Control` saying `no-store`,
  `private` or `no-cache` stands over a rule's `set` or `remove` whose value does not say them too
  (`no-store` says all three), and a rule's `Expires` and lifetime in `CDN-Cache-Control` and the
  other CDN fields are left out over it or over such a word in any of its CDN fields (alpha.100); an
  answer that is one user's (it sets a cookie, varies on `Cookie` or `Authorization` or is `Vary: *`
  (alpha.100), or answers a request with `Authorization`) gets a rule's `Cache-Control` lifetime as
  `private` (`private, max-age=3600` for `public, max-age=3600`), no rule's `Expires` or CDN lifetime,
  and `Cache-Control: private` where the rules leave it none, a `remove` included (RFC 9111 7.3, 3.5).
  A lifetime of a day or more, or `immutable`, on a path whose location falls back to a file agensio
  serves (a single-page application's `try_files = ["$uri", "$uri/", "/index.html"]`) is noted by
  `-t` (`header_cache_over_fallback`, alpha.101): a path there that is no file gets the shell, which
  browsers and CDNs would keep under that address; give the directory its own location with
  `try_files = ["$uri", "=404"]`. A `set` of a lifetime over an
  application site is noted by `-t`: `default` keeps the application's own value, and a page it marks
  with nothing is kept by a CDN whatever it shows.
- **Refused at load, naming what to use instead:** the framing fields (`Connection`,
  `Transfer-Encoding`, `Content-Length`...), the representation's (`Content-Type`, `ETag`, `Vary`,
  `Date`...), `Location` and `Refresh` in any verb, `remove` included (a `[[site.redirect]]`: a 301
  without `Location` has no target), `Strict-Transport-Security` in `set` or `default` (`hsts`;
  `remove` strips an application's own), `Server` in any verb (`[server] server_header`, `""` for
  none: agensio writes it on every answer), `Alt-Svc` in `set` or `default` (`remove` strips an
  application's own), `Set-Cookie`, `Clear-Site-Data`, `Service-Worker-Allowed`, the password fields, the
  obsolete pinning fields; a value that is empty, longer than 4 KB, holds a control character or a
  `$` (no variables; request fields with variables are `proxy = { request_headers }`);
  `X-Frame-Options` other than `DENY` or `SAMEORIGIN`; an `Access-Control-Allow-Origin` that is not
  one origin or `*` (`null` is refused: any page can claim it), and `*` with
  `Access-Control-Allow-Credentials: true`; the same field
  twice at one path and match, or in two verbs of one rule; more than 64 rules or field names, or
  16 KB of values.
- **Noted by `-t`, the error log and health:** a `set` of `Content-Security-Policy` on a site with
  an `app` other than `static`; `X-XSS-Protection` other than `0`.
- **Over HTTP/2 and HTTP/3** the names go in lower case, as those protocols require.
- **Cost:** a site without rules pays one test; with rules, the request finds its path's fields
  once, behind a test of the path's first byte, and a cached file over HTTP/1 takes them as one
  prebuilt block. Rules with `endings` add one comparison of the served file's name per ending a
  rule of its path names, made when agensio picks the file.

**The security baseline** (0.1.0-alpha.94, [headers.md](headers.md) 4). A site with `app` gets,
without a rule, only what cannot break a page that works today:

| field | on which answers |
|---|---|
| `Referrer-Policy: strict-origin-when-cross-origin`, as a `default` | every answer that has none: what current browsers do without the field, told to older ones and scanners; an application's own value (Django's `same-origin`) wins |
| `X-Content-Type-Options: nosniff`, as a `default` | the files and error pages agensio serves, whose type it set itself; never an application's answer, where a script sent with the wrong type would stop working |
| `X-Powered-By` removed | every answer: no client reads it (a framework's, as `Express` or `Statamic`; PHP's own is off in the pools agensio writes) |
| `Cache-Control: no-cache`, as a `default`, success only | on `app = "static"`: the `.html` and `.htm` files it serves (a page, a directory's index, a single-page application's shell), so a deploy shows at once; browsers revalidate and get a `304` when nothing changed |
| `Content-Security-Policy: script-src 'none'`, as a `default` | the `.svg` and `.svgz` files agensio serves (0.1.0-alpha.100): an SVG opened alone or framed runs no script on the site's origin, the stored-XSS path of an uploaded one; in `<img>` an SVG never runs one, so pages look the same |

```toml
[[site]]
server_name = ["shop.example.com"]
app = "wordpress"
response_headers_baseline = false    # the baseline off; true gives a site without app the static site's
```

A rule naming one of these fields decides instead, at any path, `/` included, and its `endings`
rule too: `set = { "Referrer-Policy" = "no-referrer" }` at `/` replaces the baseline's,
`remove = ["X-Content-Type-Options"]` drops it. A location's `add_headers` copy of a field answers
the baseline's `default` (a cached directory's own `Cache-Control` stays). What the baseline leaves
out (a frame field, a Content-Security-Policy, `Permissions-Policy`, `nosniff` on an application's
answers) can break a working page and is the owner's decision, one at a time (headers.md 4.1). A site
without `app` (a hand-written minimal site, the benchmark templates) gets no baseline; a managed
static site names `app = "static"` in its file since 0.1.0-alpha.94, written at its next change.
`-t --explain` says the baseline in a comment, `path_check` names it as the source of each field
(`referrer-policy: strict-origin-when-cross-origin unless the answer has its own (baseline
wordpress)`). Together with a site's rules it may name at most 64 fields. Cost: the site's answers take
its fields as rules at `/` do, one prebuilt block on a cached file over HTTP/1.

**What a path gets:** `path_check` (`agensio ctl path-check NAME PATH`, MCP `path_check`, 0.1.0-alpha.92)
lists every field the site decides on that answer, with its verb, value and the deciding rule
(`cache-control: public, max-age=3600 (rule /embed, success only)`, `x-frame-options: removed (rule
/embed)`, `strict-transport-security: ... (hsts, over HTTPS)`): for a file it serves, the fields for
its ending; for an application's answer those of a successful one and, where they differ, of any
other status. With proposed rules (MCP `path_check` `response_headers`, the rules as objects) it
answers as if they replaced the site's, checked as the load would, and changes nothing.

**On a managed site** (0.1.0-alpha.94, [headers.md](headers.md) 6): `site_create` and `site_update`
(MCP, the control API) take `response_headers`, the rules as objects with the keys above, sent whole
(`[]` clears them), judged by the load's own parse and checks, and `response_headers_baseline`
(`false` turns the baseline off, `true` or `null` back on); the managed file carries them as
`[[site.response_headers]]` tables, `site_show` lists them in the same form, and the change's answer
carries `response_header_notes`. `agensio ctl site-update NAME`:

```sh
agensio ctl site-update example.com --response-header "/ set X-Frame-Options=SAMEORIGIN" \
    --response-header "/ default Content-Security-Policy-Report-Only=default-src 'self'" \
    --response-header-remove "/embed/ X-Frame-Options" --yes --reason "security headers"
agensio ctl site-update example.com --response-headers-file rules.json --yes   # match, when, endings
agensio ctl site-update example.com --no-response-headers --yes                # the rules removed
agensio ctl site-update example.com --no-response-headers-baseline --yes       # the baseline off
```

The flags of one command make the whole list (the flags naming one path one prefix rule, then the
file's rules), as `--redirect` does; `agensio ctl site NAME` shows the list in the file's JSON form.
`path_check` on a page also lists `response_headers_offer`: the fields of headers.md 4.1 nothing the
site decides sends there, each with what it could break, for the agent to offer one at a time.

**What a live site's home page goes without** (0.1.0-alpha.94): for each live HTTPS site (TLS, an
`app`, a real certificate served for a week) health asks the home page once, over loopback off the
workers, and reports `response_headers_suggested` (info) naming the fields of headers.md 4.1 its
answer lacks: a frame field (or `frame-ancestors` in a CSP), a CSP (report-only counts),
`Permissions-Policy`, `nosniff`; an application's own fields count, a redirect or an error is not
judged. What the owner decided against goes in the site key `response_headers_offer_declined`:

```toml
response_headers_offer_declined = ["X-Frame-Options"]   # other sites embed its pages
```

It names only those four fields (any case; HSTS is declined with `hsts = "application"` or `hsts = "none"`), sends and removes
nothing, and the finding and `path_check`'s offer leave them out; managed: `site_update`'s field of
the same name, `agensio ctl site-update NAME --decline-response-header X-Frame-Options`
(`--no-declined-response-headers` clears the list). `hsts`
stays its own key ([redirects.md](redirects.md) 4), and a location's `add_headers` keeps adding its
fields to that location's successful answers; a rule's `set` and `remove` act on those too.

## 15. Control socket

```toml
[control]
socket = "/run/agensio/control.sock"   # default on Linux; macOS: /usr/local/var/run/agensio/control.sock
admins = "agensio-admin"               # groups; root and server.user are always admin
operators = "agensio-ops"
viewers = "agensio-view"
audit = "/var/log/agensio/audit.log"   # default: audit.log next to the error log
sites_root = "/var/www"                # where site-create suggests document roots
provision = true                       # the root helper and its reader: accounts, layout, pools, installs, tasks; reads and approval codes apart (false: commands are handed back)
install = true                         # site-install may download from https URLs (false: only uploaded archives are installed)
install_private = false                # true: site-install may fetch from loopback, private and link-local addresses (internal mirrors, test beds)
install_ca = "/etc/ssl/mirror-ca.pem"  # PEM bundle site-install trusts instead of the system store (private mirrors); default: the system store
upload_max = "512M"                    # the largest archive `agensio ctl upload` may store
site_limits = { max_body_size = "512MB", memory_limit = "512M", max_execution_time = 300, max_input_time = 300, children = 32, max_requests = 1000000 }
                                       # the ceilings site-create / site-update may raise a site's limits to (these are the defaults)
runtimes = { ruby = "/usr/bin" }       # where site tasks find ruby, gem and bundle (also node, php, python3); root's files only; reload applies it
task_limits = { timeout = 1200, processes = 512 }   # a task's wall-clock seconds and the processes its account may have
task_downloads = true                  # tasks that download packages (gem, bundle, pip, npm) may run; no other limit on the network
trash_keep = 60                        # days a site deleted with its files stays in <sites_root>/.trash; 0 keeps entries until trash-delete
file_history = { versions = 5, days = 30 }   # what the file tools replace or remove, kept in <sites_root>/.history for an undo
```

The control API is how `agensio ctl`, the MCP bridge (`agensio mcp`) and any local tool
inspect and, in later steps, configure the running server. It exists only when the
`[control]` table is present. It is a unix domain socket, never a port: nothing on the
network can reach it, and a site listener can never route to it because it is a separate
listener with its own code path.

**Who may connect.** Every connection is checked by its peer credentials, the uid and
gid the kernel reports for the process at the other end, whatever the file mode says.
`root` and the account in `server.user` are admins. Members of the `admins` group are
admins, members of `operators` may reload, purge and read logs, members of `viewers` may
only read. Anyone else is disconnected at accept and the attempt goes to the audit log
with its uid. The socket's directory is created by the server, owned by it and never
writable by others, so a site user cannot replace the socket path. With only `admins`
configured the socket file is `0660` for that group; with several groups it is `0666`
and the credentials alone decide.

**Audit.** One line per refused connection and, from F3 on, per mutating command: time,
uid, gid, role, command and outcome. Rotated with the other logs (`SIGUSR1`).

**Commands** (`agensio ctl <command>`, or HTTP/1.1 + JSON on the socket, `GET /v1/...`):

| command | role | answer |
|---|---|---|
| `status` | viewer | version, pid, uptime, configuration path, workers, open connections, listeners, sites (names, listen, root, app, user, tls, redirect), whether ACME is on, and the caller's uid/gid/role |
| `sites` | viewer | every site: names, listen, root, app, user, redirect, access log, and its certificate (mode, issuer, names, days left, whether it is still the placeholder) |
| `site NAME` | viewer | one site in full (`handler` is `deny` for a path answered 404 whatever exists, and a location lists the endings it `refuses`): the above plus index, php socket and generated pool, upstreams, and every location after the preset expanded (path, match, handler, root/alias, upstream, added headers, which preset added it) |
| `presets` | viewer | the application presets: for each `app` value the served root, whether every `.php` runs or only the front controller, refused suffixes, directories that never run PHP, files never served, `secrets` (the credential files among them: what the hosting rules check and every write path creates `0600`), and `source`, the official archive `site-install` takes when the preset has one |
| `validate` | viewer | loads the file on disk again and runs the hosting rules: `ok`, `errors`, site count, and the restart-only settings that differ from the running server |
| `logs` | viewer | `--site NAME` (default: all sites plus the error log), `--since 3h` (`m`, `h`, `d`, `w`, seconds, or a local `YYYY-MM-DDThh:mm:ss`; default 1h), `--level error|warn|info` for the error log (default warn = error+warn), `--status 5xx|4xx|all|NNN` for access logs (default 5xx; a class means that class and above, `NNN` that status and above; anything else is refused with a 400), `--limit N` (default 200, newest). Reads at most 2 MB per file from the end; `truncated` says when that cut in. A line's `source` is `error`, `access` (the server-wide `[log] access` file, which every site without an `access_log` of its own writes into, so a line there is no site's in particular) or the site's name (a file it alone writes); `--site NAME` for a site sharing the server-wide file answers `shared: true` with a note, JSON lines filtered to the site's host names, combined ones not attributable |
| `uploads` | viewer | the archives stored with `upload` (`file`, `bytes`, `uploaded`), ready for `site-install --file` |
| `trash` | admin | the sites deleted with their files, one entry each (`<domain>-<date>-<time>`): site, preset, account and whether any site still uses it, deleted and expiry times, size and file count, the pieces with their original paths; the whole is read by the helper, so 503 `busy` while a task runs |
| `site-unit NAME [--raw \| --out FILE]` | viewer | a Laravel site's scheduler (section 3: two units, `--out` writes the one its file name names), or the systemd unit that runs a Rails or Redmine site's Puma, a Django or Wagtail site's Gunicorn (section 4e), or a Node site's node (section 4f), rendered from the site and `[control] runtimes`, with the root commands that install it (`--raw` prints the unit alone, to read; `--out FILE` writes it in place, whole and `0644`, and leaves the file as it was when the render fails); 409 for a site without its own account or a non-loopback upstream |
| `site-service NAME` | viewer | for a Laravel site its scheduler (section 3: the timer as installed, cron lines that run `schedule:run`, the recorded runs, `duplicate`); otherwise whether a Rails, Redmine, Django, Wagtail or Node site's application service runs: `agensio-app-USER.service`, derived from the site's account, read by the provisioning helper with `systemctl show` (`state`: `LoadState`, `ActiveState`, `SubState`, `Result`, `ExecMainStatus`, `MainPID`, the enter timestamps, `MemoryCurrent`, `NRestarts`, `UnitFileState`), with `summary` and `next_steps` (`site-unit` when the unit is missing, `site-service-logs` and `systemctl restart` when it failed, `systemctl enable --now` when it is stopped); 409 for a site without its own account, a non-Rails site or a server without the helper; 503 `busy` while the helper runs a task |
| `site-service-logs NAME [--lines N] [--since 3h] [--raw]` | admin | the unit's journal (`journalctl -u UNIT -n N -o short-iso`, N from 1 to 1000, 200 by default; `--since` a number and `s`, `m`, `h` or `d`), newest last, the newest 256 KB at most; every read audited; `--raw` prints the lines alone |
| `site-task-output NAME [--offset N] [--length N] [--raw]` | admin | the whole output of the site's last task (see `site-task`), up to 64 KB per call from `offset`, with `next_offset` (null at the end), `kept_all` (false when the task printed more than the 1 MB kept) and the task's name and time; 404 when no task ran since the server started |
| `site-tasks NAME` | viewer | the named tasks the site's preset offers (`app = "rails"`: seven; `"redmine"`: eight; `"django"` and `"wagtail"`: nine each, with the site's `project` and `virtualenv`; `"node"`: two, with its `entry`; `"laravel"`, or a Laravel application on `"php"`: eight, in the release that holds `artisan`), each with its summary, its parameters (name, meaning, pattern, required), whether it downloads, whether the directory must be empty, its effective time limit (the row's, capped by `[control] task_limits.timeout`) and its `interpreter`: the program, whether the interpreter rule accepts it and, when not, why and the package command; `run_as_root` at the top lists every missing package once, so root installs them before the first task; the account that runs them (`runs_as`), the directory, the task running now; a site of another preset has none |
| `settings [NAME]` | viewer | the per-site limits `site-create` and `site-update` accept under `settings`: for each key its type, unit and spellings, meaning, default and its origin, minimum, the ceiling from `[control] site_limits`, what changing it costs (agensio reload, php-fpm reload) and what it derives; with a site, the current value and whether it comes from the site, the server or a built-in default. `site NAME` reports the same `settings` |
| `health` | viewer | findings with `severity`, `code`, `site`, `message`, `fix` (also `files_unreadable`: files under a document root, the preset's upload directory first, that the server's account cannot open and that answer 404 with no log line; `php_tmp_missing`; `php_fpm_hard_reload`; `php_pool_resident`, judged from the pool file php-fpm runs; `preset_mismatch`: the files under a site's directory belong to another application than its `app` says, with the application detected and the `app` to set; `archives_in_root`: backup archives and database dumps under a served tree, the directories a preset never answers excepted; `site_env_unsafe`: the site environments' directory is not root's alone, or a site's file is open to others, not root's or has a second link (checked by the helper, read-only), with the `chown`/`chmod` line; `site_env_orphan`: a deleted site's environment file, with its `rm -f`; `site_env_unchecked`: the helper was busy with a task): configuration on disk invalid or failing the hosting rules, restart-only settings changed, running as root, certificate unreadable / still the placeholder / expired / expiring within 14 days (manual), `tls = "auto"` with nothing answering plain HTTP on port 80 for the names, a TLS site on another port than 443 whose plain HTTP is not redirected, application sites sharing the server's account, generated pools out of date, errors in the last 24 hours. `ok` is true when nothing above info level was found |

`agensio ctl` prints the JSON answer and exits 0 on a success, 1 otherwise, and 2 for a usage error
(an unknown argument, or a flag without its value: none, an empty one, or the next flag, so `--out
--nft` writes no file named `--nft`; a value that starts with `--` is written `./--name`, and a path,
the value of `-c`, `--config`, `--out` or `--socket`, that starts with `-` likewise: `-c ./-t`). `agensio
protection`, `pools`, `mcp` and `passwd` say a missing value the same way, one line on stderr. With `--raw`, and with `protection
--nft`, `--jail`, `--unit` or `--filter NAME`, stdout carries the text alone: a refused call prints
nothing there and says why on stderr, so `> file` never catches an error. A file root loads is written
with `--out FILE`, never with `>` (section 18).

**Changes** (`POST` with a JSON body; every one needs `"confirm": true`, takes a
`"reason"` that goes to the audit log, and answers 428 without the confirmation; `site-create` and
`site-update` answer 400 for a field they do not read, naming the nearest):

| command | role | what it does |
|---|---|---|
| `reload` | operator | the same as `agensio reload`: validate the file on disk, bind, switch; 409 with the reason when refused, nothing changed then |
| `logs-reopen` | operator | reopen every log file (what `SIGUSR1` does) |
| `site-create` | admin | writes `sites.d/<domain>.toml`, validates, reloads. Fields: `domain`, `aliases`, `https` (`auto`, `none`, or `{cert, key}`), `redirect_http` (default true: plain HTTP redirects; false is `http = "serve"`, refused with `hsts`), `hsts`, `canonical` (the domain or an alias the other names redirect to; `""` clears it), `redirects` (path redirects, section 14b: a list of `{from, to, status, match, remainder, query, cache}`, sent whole), `user` (an account name; `no_user: true` or JSON `null` for none; the words null, none, nil and system accounts are refused, never turned into commands), `group`, `app`, `root`, `upstream`, `project` (app = django or wagtail: the project's Python package), `php_socket`, `php_children`, `php_version`, `listen_plain`, `listen_tls`, `rules` (an application's own server guidelines as bounded rules, below). Until `https`, `root` (or `upstream`), `app`, `user` and, for a Django site, `project` are decided it answers 422 with the open questions and a suggestion each (a user name from the domain, the app the files under root suggest); when the account or the root directory does not exist it answers 409 with the commands to run as root and waits for the same command again. A new site is HTTPS-only, one block for both schemes: its plain port redirects (the site's `http`). |
| `site-create` answers | | 422 with `needs` while decisions are open; 409 `prerequisites missing` with `problems` (every one at once, each with a `code`, a `detail` and its `run_as_root` command: `missing_account`, `missing_group`, `root_missing`, `root_unreadable`, `certificate_missing`) plus the flat `run_as_root` list; 409 `listen_unbound` when the site would take an address below 1024 the server does not hold (the main file's `listen_tls` and `listen_plain` with a restart, or a port above 1023, under `run_as_root`; before 0.1.0-alpha.120 a 202 promised a restart the reload could not keep); 201 with `next_steps` (separate commands: `agensio pools`, then the php-fpm reload) and `warnings`. `dry_run: true` runs every check and returns the file that would be written without writing or reloading |
| `site-update NAME` | admin | the same fields on a site `site-create` wrote (the file carries its spec on its first line); a hand-written file is refused with 409, edit it yourself. It writes the file in this version's form whatever fields it is given, none included, also when the file was set aside (a form an earlier version wrote that this one refuses); a hand-written file set aside is refused with 409, naming the file and the loader's error. `settings = {key: value}` (CLI `--set KEY=VALUE`, repeatable) sets the per-site limits: `max_body_size` (any site), and for a PHP site with its own user (a generated pool) `memory_limit`, `max_execution_time`, `max_input_time`, `children`, `pm`, `max_requests`. Each value is checked against `[control] site_limits` and refused above it naming the key, the value and the ceiling; a key outside that list (`extra`, `open_basedir`, any ini name) is refused as unknown, whatever it is. The answer's `done` lists what was written and reloaded: the site file and agensio, and the php-fpm pool and php-fpm when a pool key changed (a php-fpm reload briefly affects every PHP site unless `process_control_timeout` is set) |
| `site-disable NAME`, `site-enable NAME` | admin | renames the file to `.disabled` and back, reloads |
| `site-delete NAME [--files]` | admin | removes the file (a `.bak` stays) and sets the site's root additions file aside the same way (`<domain>.root.toml.bak`, still root's; `root_additions_set_aside` in the answer), reloads; never touches the root or the account. With `--files` (`files: true`) everything of the site goes into root's trash first (below): its directory, the account's state directory (or the site's virtualenv when another site shares the account), its access log with its rotations, its environment file, and the site file's text into the entry's manifest; refused while the site's service runs (with the `systemctl` lines for root) or when the directory is not below `sites_root`; a reload that fails afterwards puts everything back. The account is kept |
| `site-restore ENTRY` | admin | brings an entry of the trash back: every piece to its original path, the site file from the manifest, a reload; only into an empty place (refused when the site exists again, its file is there, or any original path exists and is not empty), and only with the account at the uid the files carry (else the `useradd --uid` line for root). The application's service is not restored: `site-unit` renders it again |
| `trash-delete ENTRY` | admin | removes one entry now, for good |
| `trash-expire` | admin | removes the entries older than `trash_keep` now (worker 0 does it every hour) |
| `site-files NAME [PATH]` | admin | the entries of one directory of the site, as its account (the site's files, below) |
| `site-file-read NAME PATH [--offset N] [--tail N] [--base64]` | admin | one file, as its account, at most 180 KB a call; a credential or database file waits for approval |
| `site-file-write NAME PATH [FILE] [--overwrite] [--executable]` | admin | writes the file whole from FILE or standard input; waits for approval |
| `site-file-edit NAME PATH --old TEXT --new TEXT` | admin | replaces text that occurs once; waits for approval |
| `site-dir-create NAME PATH [--parents]`, `site-path-move NAME FROM TO [--overwrite]`, `site-path-delete NAME PATH [--recursive]` | admin | a directory, a move within the site, a delete into the history; each waits for approval |
| `site-file-history NAME PATH`, `site-file-restore NAME PATH VERSION [--overwrite]` | admin | the versions the history keeps of a path, and putting one back (waits for approval) |
| `cert-renew NAME` | operator | orders the site's automatic certificate again now; for a site with its own certificate files, loads them now and answers what happened (section 14) |
| `upload NAME [FILE]` | operator | stores FILE (stdin by default) as `<state_dir>/uploads/NAME`, the server's own directory (0700); `PUT /v1/uploads/NAME` with the raw bytes on the socket; no `--yes`; at most `upload_max`; names are plain file names (letters, digits, `.`, `_`, `-`, no leading dot); a partial transfer leaves nothing |
| `uploads-delete NAME` | operator | removes a stored upload |
| `site-install NAME` | admin | puts an application's files into the site's directory (the `root` as given, above a preset's `public/` or `web/`; `--path SUB` for a subdirectory such as `wp-content/plugins/NAME`, with `--create-path` when it does not exist yet) **as the site's account**, from one source: `--url https://...` (a `.tar.gz`, `.tar` or `.zip`), `--file UPLOAD` (a stored upload), or nothing, which takes the preset's official archive (`presets` lists it under `source`; `--version V` picks a release, default the newest; WordPress and Drupal have one, Laravel is made with composer). `--sha256 HEX` refuses an archive whose digest differs. `--strip 0|1` keeps or unwraps a single top directory (default: unwrap when there is exactly one). `--dry-run` takes the same walk as the real call, as the same account, and answers with the target, the account and `would_create`, or with the refusal the real call would meet; nothing is downloaded or written. Answers 201 with `files`, `bytes`, `sha256`, `unwrapped`, `created` (each directory made, with owner and mode), `facts` for an install into the site's directory itself (`gemfile`, `credentials`: Rails' `config/credentials.yml.enc` or `config/credentials/production.yml.enc`, `ruby_version`: what `.ruby-version` pins), `next_steps` (for `app = "rails"`: the pinned Ruby, then `bundle_install`, `db_prepare`, `assets_precompile` and Puma; for the others the application's own setup in the browser; for every site but a static one its request-body limit), and `done` when a Rails archive without credentials got its `SECRET_KEY_BASE` generated into the site's environment (once: an existing value is kept); 409 with the reason and nothing left behind; 403 when `install = false` and a URL was given; 422 when no source can be found |
| `site-copy NAME --from SUB --to SUB` | admin | copies one regular file of the site to another path of the same site **as the site's account**: the drop-in files applications ship as templates (`wp-content/db.php` from the SQLite plugin's `db.copy`, `advanced-cache.php` or `object-cache.php` from a caching plugin, Drupal's `sites/default/settings.php` from `default.settings.php`). Both paths are relative to the site's directory and reached by the same walk as an install; `from` must be an existing regular file (no directory, no symlink); the destination's directory must exist (`site-install --create-path` makes one); an existing destination is refused unless `--overwrite`, and the answer then reports the replaced file's size and mtime. The new file gets the directory's pattern (`0640` in a `2750` directory, the execute bits when the source has them), or `0600` when it is one of the preset's credential files (`secured: true`); written under a temporary name and linked or renamed into place, so a refusal leaves nothing; the configuration is validated afterwards (see below). Never across sites, never content from the caller, never a directory, no chmod or chown. `--dry-run` runs the same checks. Answers 201 (200 when replaced) with `from`, `to`, `as`, `bytes`, `mode`, `replaced`; 409 with the reason |
| `site-task NAME TASK [--param KEY=VALUE]...` | admin | runs one named task of the site's preset **as the site's account** in the site's directory (`root`; Laravel's rows in the release that holds `artisan`, with the site's own PHP version, section 3): a row of the task table, never a command line (below). `--dry-run` answers with the exact argv, the account, the directory, the environment and the limits, and runs nothing. `pip_install` (Django and Wagtail) runs only on the user's own confirmation (section 4e): ctl prints the warning and the `--yes` typed is the confirmation; without one the answer is 428 with the warning and the command. Answers 200 when the task exited 0, 409 when it failed, was stopped at its time limit or was refused, each with `argv` (what ran, the interpreter resolved), `as`, `cwd`, `env` (the site's own variables as `NAME=<site environment>`, never their values), `exit` or `signal`, `timed_out`, `duration_ms`, `summary` when the output has one (`N migrations applied`, `Bundle complete! ...`, `Default configuration data loaded.`, `public/assets holds N files`), `output` (stdout and stderr together: its last 4 KB when the task succeeded, its first 4 KB and last 12 KB when it failed, the cut marked; `truncated`, `output_bytes` and `output_kept`, the part kept for `site-task-output`), `next_steps` with root's restart line of the site's service after `bundle_install`, `db_migrate`, `db_prepare`, `plugins_migrate` or `assets_precompile`, `secured` (credential paths made private), `hint` when the failure has a known cause (Rails' "Missing secret_key_base": generate one into the site's environment; "Your Ruby version is X, but your Gemfile specified Y": a Ruby for one application, below), and `run_as_root` when the interpreter is missing; 400 for an unknown task or a parameter that does not match; 422 for a preset without tasks; 409 while another task runs on the same site |
| `site-env NAME [--reveal KEY]...` | admin | the site's environment (`app = "rails"`, `"redmine"`, `"django"`, `"wagtail"`, `"node"` or `"proxy"`; a Laravel site's own `.env`, its `env_file`, section 3): `variables` with each name, its `length` and its `fingerprint` (16 hex digits of a keyed hash: the same fingerprint means the same value), no value; a value only for each `--reveal KEY` (`?reveal=KEY,KEY` on the API), audited as `REVEALED`; `exists` false when the site has no file yet; `tightened` when the helper made the directory or the file private on the way. Every call is audited with the names it returned. 422 for a site of another preset; 409 with `run_as_root` when the directory or the file cannot be trusted |
| `site-env-set NAME [--set KEY=VALUE]... [--unset KEY]... [--generate KEY]...` | admin | changes the site's environment (a Laravel site's `.env`, root's `0640` with the site's group, `--generate APP_KEY` in Laravel's form, section 3): `--set` adds or replaces, `--unset` removes, `--generate` puts a random secret (128 hex digits) under a name that is missing and keeps an existing one; a name in both `--unset` and `--generate` is rotated. Answers 200 with the names under `set`, `unset`, `generated`, `kept`, `absent` and `names` (every name now in the file), never a value, and the restart of the application's service as a next step; 400 for a name or value the rules refuse (below), 409 when the helper refuses |

**Application rules** (`rules`, 2026-10-01). A PHP application without a preset of its own
ships server guidelines (Kanboard: "deny `app/` and `data/`, run only `index.php` and
`jsonrpc.php`"; its `.htaccess` files say the same to Apache). A managed site under
`app = "php"` (or `"static"`) carries them as one bounded object the control plane checks
and renders into ordinary locations, so the file stays one `--explain` can show and no
hand-written location or root edit is needed:

```json
"rules": {
  "private": ["/app/", "/data/", "/libs/", "/vendor/", "/cli", "/web.config"],
  "entry_points": ["/index.php", "/jsonrpc.php", "/healthcheck.php"],
  "cache": [{"path": "/assets/", "max_age": 604800}, {"path": "/build/", "max_age": 31536000, "immutable": true}],
  "front_controller": "/index.php"
}
```

`private` paths (a directory with a trailing `/`, or one file) answer 404 whatever exists
there, before any suffix location (`final = true`, `handler = "deny"`); a private `.php` file
with path info too (`/install.php/x`, section 6). `entry_points`
(PHP presets only) are the only `.php` files that run, with their path-info URLs
(`/index.php/old/link`); every other `.php` anywhere under
the root is 404, never served as source (the preset's `.php` suffix location is replaced
by a denying one). `cache` (PHP and static sites) names directories served straight from
disk with `Cache-Control: public, max-age=N` (0 to a year), where nothing runs and no
source backup is served (`deny_suffixes` = the PHP endings plus `.inc`, `.bak`, `~`,
`.log`, `.sql`, `.sqlite`, `.sqlite3`, `.db`; below a directory the preset shields, Grav's
`user/` or `wp-content/uploads/`, the shield's own refusals stay too, and a directory the preset
never answers, Grav's `logs/` or `cache/`, is refused: 0.1.0-alpha.120, section 4). `immutable: true` (0.1.0-alpha.101) adds
`immutable` (RFC 8246): while the lifetime lasts a browser's reload asks nothing, which Firefox
and Safari honour over HTTPS (Chrome no longer revalidates on a reload anyway). It is for a
directory whose file names change with their content (a build's `app.3f9a1c.js`), since a file
that keeps its name would stay old for the whole lifetime; it needs `max_age` above 0, the one
time it holds. An entry takes `path`, `max_age` and `immutable` only; another field is refused,
naming the nearest (before alpha.101 it was dropped). `front_controller` (one of
`entry_points`) makes a path the site has nothing to serve for (no file, and no directory
with an index it serves: a directory whose `index.php` is not an entry point included) reach
that script with the query string (Kanboard's nice URLs, TYPO3's `/typo3/`). Every rule only narrows what the bare preset serves: a path under a private
one cannot be an entry point or cached, at most 64 private paths, 16 entry points and 16
cached directories, a path is `/`-rooted plain characters without `..`, and `/` itself is
refused. `rules` replaces the whole object (`{}` clears it); a later `app` change the rules
no longer fit is refused until they are cleared. `site-install` reports the directories an
archive's own `.htaccess` files deny whole (`Require all denied`, `Deny from all`, outside
`<Files>` blocks) as `facts.htaccess_denied` and suggests the matching `private` rule in
its next steps; agensio never reads `.htaccess` when serving and never applies the rule
on its own. On the command line: `--private PATH`, `--entry-point /x.php`, `--cache
PATH=SECONDS` or `--cache PATH=SECONDS,immutable` (repeatable), `--front-controller /x.php`, `--no-rules`. Each flag replaces its own
part and `agensio ctl` sends the site's other rules back with it, so `--cache` alone keeps the
address rules, passwords and refused paths (before 0.1.0-alpha.61 those four flags given alone
dropped them); `--no-rules` clears every rule.

**Access by client address** (`rules.restricted`, 2026-10-07, section 19): on any app, a list
of `{"path": "/wp-admin", "allow": ["203.0.113.7", "@office"]}` with optional `"match":
"exact"` and `"mode": "report"`, rendered as `[[site.access]]` tables marked `# rules:
restricted`; `path` may be `/` (the whole site). `--restrict PATH=ADDR[,ADDR...]` and
`--restrict-exact` replace that list and keep the other rules, `--no-restrict` clears it;
`access-check SITE PATH ADDRESS` (MCP `access_check`) says what the rules decide for one
client before they are applied.

**Admin panels by address** (`rules.admin`, 2026-10-07, section 19): on `app = "wordpress"`
and `"drupal"`, `{"allow": ["@office"]}` with optional `"login": true` (the login page too),
`"languages": ["fr"]` (Drupal's URL prefixes, at most 16) and `"mode": "report"` restricts the
preset's administration paths, which `presets` lists as `admin_paths`, rendered as
`[[site.access]]` tables marked `# rules: admin`. Nothing restricts an admin by default.
`--restrict-admin ADDR[,ADDR...]`, `--admin-login`, `--admin-language L` (repeatable) and
`--no-restrict-admin` replace that object and keep the other rules; refused on another app,
and on a path `rules.restricted` names too.

**Passwords** (`rules.auth`, 2026-10-09, section 19b): on any app, a list of `{"path": "/"}` with
optional `"match": "exact"`, `"realm"`, `"skip_for": ["@office"]` and `"plain_http": true`, or
`{"path": "/health.html", "open": true}` for a path below a protected one that needs no
password, rendered as `[[site.auth]]` tables marked `# rules: auth` that read the site's own
users file (`users = "../auth/<site>.users"`, the control plane's). At most 16 rules; an open
rule must lie below a protected one; `skip_for` never `"any"`. Refused until the site has a
user (`site-auth-user-set` first), and on `site-create`. `--auth PATH`, `--auth-exact PATH`,
`--auth-open PATH` (repeatable) with `--auth-realm TEXT`, `--auth-skip ADDR[,ADDR...]` and
`--auth-plain-http` replace the list and keep the other rules; `--no-auth` clears it.

**Refused paths** (`rules.refuse`, 2026-10-08, section 6b): on any app, a list of
gitignore-style patterns (`"/vendor/"`, `"*.yaml"`, `"/ext/*/Resources/Private/"`,
`"/a/**/*.ts"`) rendered as the site's `refuse` key, marked `# rules`; each pattern is
compiled when the change arrives, so a bad one is answered with what to write instead (a `/`
inside without a leading one, a `?` or a brace, a percent escape), and one that would refuse
the site's index, its front controller or an entry point is refused when the change is
validated, the site keeping the rules it had. `--refuse PATTERN` (repeatable) replaces the
list and keeps the other rules, `--no-refuse` clears it. It is where an application without a
preset gets the deny rules its official server configuration lists; `path-check SITE PATH`
(MCP `path_check`, viewer) says what the site does with one path and which pattern, location,
`try_files` step or index decides it, as the server would, without fetching anything:

```
$ agensio ctl path-check cms.example.com /typo3conf/ext/news/Configuration/TypoScript/setup.typoscript
404: /typo3conf/ext/news/Configuration/TypoScript/setup.typoscript is refused by the site's refuse pattern '*.typoscript'
$ agensio ctl path-check cms.example.com /typo3/module/web/layout
runs /index.php (location /index.php (exact, fastcgi, from rules))
```

**Root additions to a managed site** (`sites.d/<domain>.root.toml`, 2026-10-02). A site the
control plane manages is regenerated by every `site-update`, so a location added to its file
by hand unmanages it (409 "hand-written or edited"). Root's freedom lives in a second file
beside it instead, which the control plane never writes or reads:

```toml
# sites.d/shop.example.com.root.toml   (root's, 0644)
site = "shop.example.com"

[[location]]
path = "/old-tracker/"
upstream = "http://127.0.0.1:9100"

[[location]]
path = "/downloads/"
alias = "/srv/downloads/"
add_headers = { "X-Robots-Tag" = "noindex" }
```

`site` names the managed site (its domain; the file name is the convention `site-show`
reports), and every `[[location]]` takes any key of section 6. The locations are parsed after
the site file's own and before the preset expands, so they count as hand-written: one at a
preset's path replaces the preset's, one with only `add_headers` joins it (section 5), and
one at a path the site file already has (a rule of this section, say) is a duplicate that
sets the site's file aside, naming the file (section 12c; a `site_update` that would collide is
refused and undone). `--explain` marks them `# from root:<file>`; `site-show`
reports `root_additions` (the file's path, present or not, the locations it added), so an
agent asked for what no field covers hands you this block instead of editing the managed
file. The file must be a regular file owned by the owner of the main configuration (root in
production) and writable by nobody else, or the site is set aside with the line to run (never
served without its additions; the other sites load, section 12c): the server's own account,
which writes the managed files, cannot add one. A file whose site is
disabled or deleted is kept and ignored with a warning (`-t`, the error log, health
`root_additions_orphan`); a plain `site-delete` renames it `.bak` beside the site file's
`.bak` (still root's; rename both back to return the site), and `site-delete --files`
moves it into the trash with the site, from where `site-restore` brings it back.

**What `site-task` enforces.** A task is a row of `src/services/tasks.cpp`: a preset, a
name, an interpreter (a runtime and a program in it), a fixed argument list, typed
parameters and a time limit. The caller names the task and gives parameters; no flag,
option or command comes from the caller, and a parameter that does not match its pattern
(`rails_new`'s `name`: a letter, then letters, digits and underscores; `gem_install_rails`'s
`version`: an exact 8.x release) is refused naming it, so `rails new -m URL` and every
other option are simply not expressible. The Rails rows:

| task | runs | notes |
|---|---|---|
| `gem_install_rails` | `gem install rails --no-document --version VERSION` (default `~> 8.0`) | into the account's own `<home>/gems`; downloads, compiles native extensions |
| `rails_new` | `ruby <home>/gems/bin/rails new . --name=NAME --database=sqlite3 --skip-git --skip-docker --skip-thruster --skip-ci` | the directory must be empty; installs the application's gems (Rails 8 skips its importmap, Hotwire and Solid installers without them); Kamal's files are kept because Rails 8.1 writes the production databases' paths only with them; downloads |
| `bundle_install` | `bundle install` | after a Gemfile change, or an application installed from an archive; downloads |
| `db_prepare`, `db_migrate` | `bundle exec rails db:prepare` / `db:migrate` | the production databases |
| `assets_precompile` | `bundle exec rails assets:precompile` | with `SECRET_KEY_BASE_DUMMY=1`, so an application without its master key compiles too |
| `database_config` | no program: writes `config/database.yml` from a fixed template | the database from `DATABASE_URL` in the site's environment (required first), `0600`, only when the file is missing |
| `gemfile_local` (redmine) | no program: writes `Gemfile.local` (`gem "puma"`) | only when missing |
| `load_default_data` (redmine) | `bundle exec rake redmine:load_default_data` with `REDMINE_LANG=LANG` | `lang` a language code (`en`, `pt-BR`) |
| `plugins_migrate` (redmine) | `bundle exec rake redmine:plugins:migrate` | after a plugin's install and `bundle_install` |

Every Rails task runs with `RAILS_ENV=production`, `BUNDLE_PATH=vendor/bundle` and
`BUNDLE_WITHOUT=development:test`: the gems of the application live in the project, only
the production groups are installed, and what the tasks prepared is what Puma loads with
the same environment (`docs/examples/puma.service`). `GEM_HOME` and `GEM_PATH` both name
the account's own `<home>/gems`, so a task sees the account's gems and Ruby's default gems
and never what root installed system-wide (before 0.1.0-alpha.26 a host-wide `gem install
rails` satisfied every dependency, `gem_install_rails` installed the meta-gem alone and
`rails_new` found no `rails` command; running `gem_install_rails` again completes an
account made then).

A task that needs an earlier task's result is refused before it runs, dry run included,
naming the missing file and what to run: `rails_new` needs the `rails` command
`gem_install_rails` writes into `<home>/gems/bin`, and the four bundle tasks need the
application's `Gemfile`. A task that exits 0 without leaving what the next one needs
(`gem_install_rails` without the `rails` command) answers 409 saying so, never ok.

The interpreter comes from `[control] runtimes` in root's file (`/usr/bin` by default):
the program, the file it resolves to and every directory above both must belong to root
and be writable by nobody else, and must lie outside `sites_root`; otherwise the task is
refused naming the component, so no site can put its own `ruby` in the way. A missing
interpreter is refused with the package command under `run_as_root` (Debian: `apt-get
install -y ruby ruby-dev ruby-bundler build-essential libyaml-dev`). What the interpreter
then loads from the site (the Gemfile, `vendor/bundle`, `bin/rails`) is the site's code
and runs as the site's account.

**A Ruby for one application.** An application whose Gemfile says `ruby file:
".ruby-version"` (Writebook and most applications made with Rails 7.1 or later) needs
exactly that version, and `bundle_install` stops at once with "Your Ruby version is 3.3.8,
but your Gemfile specified 3.4.7" otherwise (its answer's `hint` says what follows here).
`site-install` names the pinned version in its next steps. Root builds it once under
`/opt`, then points the key at it; a reload applies it, no restart:

```sh
apt-get install -y build-essential autoconf libssl-dev libyaml-dev zlib1g-dev libffi-dev libgmp-dev rustc
cd /usr/local/src
curl -fsSLO https://cache.ruby-lang.org/pub/ruby/3.4/ruby-3.4.7.tar.gz
sha256sum ruby-3.4.7.tar.gz                # compare with https://www.ruby-lang.org/en/downloads/
tar xzf ruby-3.4.7.tar.gz && cd ruby-3.4.7
./configure --prefix=/opt/ruby-3.4.7 --enable-shared --disable-install-doc
make -j"$(nproc)" && make install
# /etc/agensio/agensio.toml, [control]: runtimes = { ruby = "/opt/ruby-3.4.7/bin" }
agensio reload
```

`/opt/ruby-3.4.7` is root's and writable by root alone, which is what the interpreter rule
checks; `site-tasks NAME` then shows every task's interpreter under it with `ok: true`,
and the tasks run with that directory first on `PATH`, which matters because `bundle
exec rails` starts `bin/rails` through `#!/usr/bin/env ruby`. The Puma unit needs the same
directory first on its `PATH` and its `bundle` in `ExecStart` (`docs/examples/puma.service`).
`rustc` is only for YJIT; one runtime directory serves every site of the host, so sites
that pin different versions share the newest only when their Gemfiles allow it.

A task runs as the site's `user`, or for a site without one as the owner of the site's
directory when that is a site account or the server's own, the account rule of
`site-install`; never as root or a login account. With the provisioning helper the helper
looks the site up in the configuration on disk itself (its app, directory and user: the
server sends names and parameters only), creates the account's home when it is missing
(`<state_dir>/<user>`, `0700`, with `tmp/`) and runs the task in a child that has become
the account; without the helper it runs as the server's own account, in a directory that
account owns. The environment is built, never inherited: `PATH` (the runtime's directory
first), `HOME`, `TMPDIR`, `LANG=C.UTF-8`, the preset's variables, then the site's own from
its environment file (below), which never replace one of these. The working directory
is reached without following a symlink; stdin is `/dev/null`; the umask is `027` (files
`0640`, directories `2750` in the site's tree, readable by the server through its
group). Limits: `[control] task_limits` (`timeout`, 1200 s by default, after which the
task's process group gets SIGTERM and ten seconds later SIGKILL; `processes`, 512, the
`RLIMIT_NPROC` of the account while the task runs, threads included), 4096 open files,
no core files. When the program exits, whatever it left running in its process group is
killed. One task per site at a time. `[control] task_downloads = false` refuses the tasks
that download packages (each listed with `downloads: true`); it keeps no task off the network. The three keys apply on reload: the helper reads them from root's file for
every task (only the main file can hold `[control]`; included files carry sites alone).

After every run the credential sweep makes the preset's credential files the site's
alone: the hosting rule's list (for Rails `config/master.key`, `config/credentials/`,
`config/database.yml`, `config/secrets.yml`, `storage/`, `.env`, `.git`) plus `config/credentials.yml.enc`,
`config/credentials/*.key`, `.env.*`, `.kamal/secrets*` and the SQLite files under `db/` and `storage/`;
files become `0600`, directories lose their group's read and write and everything for
others (`0710`: the kernel drops the set-gid bit when the account is not in the
directory's group), never through a symlink. Then the configuration is validated as for
`site-install`: a task whose result `agensio -t` would refuse answers `409` with the
validator's `errors`. The audit log gets one line before the task starts (the task and its
parameters) and one after, with the exact argv that ran, the account, the directory and
how it ended; the output stays out of it. A task keeps up to 1 MB of its output (its
first 256 KB and last 768 KB beyond that) in the server's memory until the site's next
task or a restart; `agensio ctl site-task-output NAME [--offset N] [--length N] [--raw]`
(admin, MCP `site_task_output`) reads it in slices of up to 64 KB, `next_offset` leading
to the next.

**Deleting a site with its files.** `site-delete NAME --files` (MCP `site_delete` with
`files: true`) moves everything of a site into `<sites_root>/.trash/<domain>-<date>-<time>/`,
a directory root owns alone (`0700`), so no account and not the server can read another
tenant's deleted files: the site's directory (the first directory below `sites_root` on its
root's path, `/var/www/example.com` for `/var/www/example.com/app`, unless another site's root
lies under it), the account's state directory `<state_dir>/<user>` (its gems, virtualenvs,
sessions; the site's virtualenv alone when another site shares the account), its access log
with its rotations, its environment file with its secrets, and the text of its site file in
the entry's `manifest.json`. Everything moves by rename, so nothing is copied; a piece on
another filesystem goes to a trash beside it (`<state_dir>/.trash`, `<logs>/.trash`) or, a
small file, is copied. The account is kept, because the files carry its uid and a restore
needs it; `trash` says when no site uses an account any more, for root's `userdel`. The
delete is refused while the site's application service runs (a process whose directory is
renamed keeps writing into the trash): the answer carries `systemctl disable --now` for root.
`site-restore ENTRY` puts every piece back and the site file with it, then reloads, but only
into an empty place: never over files that appeared since. Entries expire after `[control]
trash_keep` days (60 by default, applied to what is in the trash when it changes; 0 never),
removed by worker 0's hourly check or `trash-expire`; `trash-delete ENTRY` removes one now.
Without `--files` `site-delete` removes the configuration alone and leaves every file where
it is, as before. The whole is the provisioning helper's: a server started without it
answers 409 and the files are removed by hand.

**The site's files.** `agensio ctl site-files`, `site-file-read`, `site-file-write`, `site-file-edit`,
`site-dir-create`, `site-path-move` and `site-path-delete` (MCP `site_files_list`, `site_file_read`,
`site_file_write`, `site_file_edit`, `site_dir_create`, `site_path_move`, `site_path_delete`) do with
one site's files what an SFTP login as the site's account would, without a shell (0.1.0-alpha.120;
`docs/design-site-operations.md` 3 and 27.6). Every operation runs as the site's account, below the
site's directory (its project root) and nowhere else; each path is walked component by component
without following a symlink, every component the account's, so a link the application planted can
never send a write elsewhere; a write goes to a temporary name and is linked or renamed into place,
takes its directory's mode (an existing file keeps its own, a credential file is made `0600`), and
never gets a set-uid or set-gid bit; nothing is ever run. Content travels through the control socket,
at most 180 KB a call (text, or base64 for other bytes); larger files go up with `agensio ctl upload`
and `site-install`. Listing and reading are made at once, except a credential or database file
(the preset's credential files, `.env*`, `.git/`, `*.key`, `*.pem`, SQLite files, and SSH keys: anything below
`.ssh/`, `id_rsa`, `id_ecdsa`, `id_ed25519` and their kin, and since 0.1.0-alpha.124 any file whose first line is a
private key's, whose first read answers nothing of it and whose next read waits), whose read waits
for approval and is handed out once; every change waits for a person's approval with a code from
their authenticator app (`docs/approvals.md`), and what waits shows the change itself: the diff
against the file there (for a credential file, its names and each value's length, never a value,
context lines included), and what the site does with the path (served as a file of what type, or
RUNS as a script); a `dry_run` of a write or an edit answers the same, `diff` and `site_does`, never
the texts whole (until 0.1.0-alpha.121 the file there and the new text, each whole: the alpha.120
report). What a change replaces or removes goes into `<sites_root>/.history/<domain>/`
(root's alone, never served): a replaced file by hard link, a deleted file or tree by rename, so
nothing is copied whatever its size. `site-file-history NAME PATH` lists what is kept, and
`site-file-restore NAME PATH VERSION` puts a version back (with `--overwrite` keeping what is there
first). `[control] file_history = { versions = 5, days = 30 }`: the versions one path keeps, the
oldest going first, and for how many days worker 0's hourly check leaves them; `versions = 0` keeps
nothing, and a delete then removes for good, at most 10,000 entries a call.

**What waits for a person's approval.** Through the control plane, a change that can run code,
move a secret or data off the host, grant access or destroy beyond undo is not made on the caller's
`confirm` alone: it waits for a person's code from an authenticator app (`docs/approvals.md`). Among
the commands here: `site-install`, `site-copy`, `site-env-set`, `site-env --reveal`,
`site-auth-user-set`, `trash-delete`, `trash-expire`, every file change, and a `site-update` that
changes `app`, `root`, `served_dir`, the entry points or the front controller, changes `upstream`,
redirects to a host that is none of the site's names, or removes or widens a password or address
rule; a `site-create` only when a static or PHP site's root is not empty, its upstream is off this
host, or a redirect leaves. Typed at a terminal, such a command asks for the code at once.

**The site's environment.** An application reads settings and secrets from its
environment: a Rails application without credentials (every ONCE application such as
Writebook, every Kamal or twelve-factor deployment) reads `SECRET_KEY_BASE` there and
stops with "Missing secret_key_base" without it; others read `DATABASE_URL`, a mail
password or an API key; a Django project `DJANGO_SECRET_KEY` and its first admin's
`DJANGO_SUPERUSER_PASSWORD` (section 4e). A site with `app = "rails"`, `"redmine"`,
`"django"`, `"wagtail"`, `"node"` or `"proxy"` has one file for them,
`env/<site>.env` beside the main configuration (`/etc/agensio/env/ag6.example.com.env`),
in systemd's `EnvironmentFile` syntax (`NAME="value"` lines), which the site's tasks get
after the variables agensio sets and its application service loads
(`EnvironmentFile=-/etc/agensio/env/<site>.env` in `docs/examples/puma.service`). It is
written through the control plane (`site-env-set`, MCP `site_env_set`) and read back by an
admin (`site-env`, `site_env`) as names, lengths and fingerprints; a value is returned
only when asked for by name, because a value returned is in the agent's context and
transcript from then on:

```sh
agensio ctl site-env-set ag6.example.com --generate SECRET_KEY_BASE --set DATABASE_URL=sqlite3:storage/db/production.sqlite3 --yes --reason "Writebook"
agensio ctl site-env ag6.example.com                              # names, lengths, fingerprints
agensio ctl site-env ag6.example.com --reveal DATABASE_URL        # that one value, audited as REVEALED
systemctl restart agensio-app-ag6          # the application reads it at start; the tasks from their next run
```

The fingerprint is HMAC-SHA256 under a key kept beside the files (`env/.fingerprint.key`,
made on first use): two sites or two moments with the same fingerprint hold the same
value, and a weak password cannot be found from its fingerprint with a dictionary.

The file is root's, `0600`, in a directory root owns alone (`0700`), written and read by the
provisioning helper: systemd reads an `EnvironmentFile` as root, so a file the site's
account could replace would let it link any root-readable file into its own environment,
and the server itself cannot read it (a compromised server reads it through the helper,
as an admin can). A server started without the helper keeps the same file under its own
account instead. Names are upper-case letters, digits and `_`, never one agensio sets for a
task or one that changes which program runs or what it loads (`PATH`, `HOME`, `TMPDIR`,
`LANG`, `RAILS_ENV`, `SECRET_KEY_BASE_DUMMY`, `GEM_*`, `BUNDLE_*` other than a private gem
source's credentials such as `BUNDLE_GEMS__CONTRIBSYS__COM`, `LD_*`, `DYLD_*`, `RUBYOPT`,
`RUBYLIB`, `NODE_OPTIONS`, `NPM_CONFIG_*`, `PYTHON*`, `PIP_*`, `VIRTUAL_ENV`, `DJANGO_SETTINGS_MODULE`,
`AGENSIO_*`, `GIT_*`, `BASH_ENV`, the systemd socket variables; on a Node site also `HOST`,
`PORT` and `NODE_ENV`, which its unit sets);
values are one line of UTF-8, at most 4 KB, 128 variables in all. A file root edits by hand
is read the way systemd reads it (quoted or not, comments), but a line that goes on over
the next one or a name the rules refuse stops every task of the site with the reason. The
directory and the files must be root's: a directory open to others (a `mkdir -p` under a
lax umask) and a file others could only read are tightened by the helper, which says so
under `tightened`; a file others could write, one with a second hard link, or another
owner is refused with the `chown`/`chmod` line under `run_as_root`, and `health` reports
`site_env_unsafe`, for the directory and for each site's file (the helper checks the files
for it, read-only, since the server cannot look inside root's directory), and a deleted
site's file as `site_env_orphan`. A file others can read counts as a warning, with the
advice to rotate what it holds, when its directory is open to others too, and as info when
the directory is root's alone. Whatever closes an open directory (a task or `site_env` on
any site) makes every file in it that others could read 0600 in the same pass and records
its variables in `env/.exposed` (names and fingerprints, never values), so health keeps
warning "readable by others ... rotate them" for that site until each of those values has
changed (`site-env-set` with the new value, or `--unset` and `--generate`), and the
error log has the same warning. `site-env-set` answers `still_exposed` with what is still to
rotate; a deleted site's kept file with such values is a warning in health and named under
`exposed` in `site-delete`'s answer; entries of a name with neither a site nor a file are
pruned. Unsetting the last variable removes the file, and the
answer says so; `site-delete` names the file it keeps only when the site has one. `site-install` generates `SECRET_KEY_BASE` itself when a
Rails archive came without credentials (never for one with them: an environment value
would override the application's own secret and sign its users out); `--generate` never
replaces a value, and rotating one is `--unset NAME --generate NAME` in one call. The file
stays when the site is deleted, as the site's files do; `site-delete` names it and gives the
`rm -f` line.

**What `site-install` enforces.** The account that installs is the site's `user`, or for
a site without one the owner of the site's directory, which must be a site account
(`nologin`, home in the state directory) or the server's own account; root, a login
account and another site's account are refused, so an install can never write as anyone
else. The target is the site's directory or `--path` below it (normalised, `..` refused),
reached by a walk that opens every component without following symlinks and requires
each existing one to belong to that account. The leaf must be empty: a whole application
goes into the fresh site directory, a plugin or theme into its own new directory. A
missing directory is refused unless `--create-path` is given, which creates the missing
levels as the account with the parent's permission bits (the set-gid bit and group come
down from the parent, as for extracted files); an existing directory is never emptied.
A refusal at any point, a symlink on the way, another account's directory, a bad
archive, a wrong digest, removes every directory the call created, so the tree is as it
was.

**Credential files and validation.** A site directory is `2750` with the server's group,
so everything created under it is readable by the server, which is what serving needs
and exactly what hosting rule 3 forbids for a credential file. The two are reconciled by
the preset table: each preset names its `secrets` (`wp-config.php`; Drupal's
`settings.php`, `settings.local.php`, `services.yml`; Rails' `config/master.key`,
`config/credentials/`, `config/database.yml`, `storage/`; `presets` shows them), the hosting
rule checks precisely those files plus `.env` and `.git` (Laravel: the project's `.env`,
`config/`, `storage/`), and `site-install` and `site-copy` create precisely those files
`0600` whatever the directory's pattern gives the rest, and take the group's read and
write and everything for others from those that are directories, listing both under
`secured` (before 2026-09-26 an archive that carried such a directory, `.git` for one,
could not be installed at all).
Each call then checks the hosting rule on what it wrote and validates the whole
configuration before answering: when the result would be refused by `agensio -t`, the
answer is `409` with `written: true` and the validator's `errors`, never a bare ok. A
file the application writes itself (WordPress's own setup writing `wp-config.php`)
follows php-fpm's umask, not agensio's; `health` reports it as `hosting_rule` with the
fix.

**php-fpm reloads.** Writing a pool (`site-create` with a user, `agensio pools`) reloads
that PHP version's php-fpm. Unless its `php-fpm.conf` sets `process_control_timeout` (php-fpm's
default is 0), the master kills its children at once and every PHP request in flight on
every site of that version answers 502. `health` reports `php_fpm_hard_reload` with the
one-line fix (`process_control_timeout = 10s`), a switch between versions is refused without it
unless `cut_requests` (section 7b), and `site-create`'s `done` entry says the reload happened. Downloads are `https://` only, with the
certificate and host name verified (the system store, or `install_ca`); every address of
every hop, redirects included, is checked against the private-address fence (loopback,
link-local, RFC 1918, ULA, shared 100.64/10, multicast, the IPv4-mapped forms) unless
`install_private = true`; at most 5 redirects, 1 GB, 15 minutes. Archives are unpacked by
agensio's own extractor: an entry that is a symbolic link, hard link, device or fifo, an
absolute path, a `..` segment, a backslash, a control character, an encrypted or zip64
entry, a tar checksum or zip CRC that does not match, more than 200 000 entries or 4 GB,
each ends the install with the reason, and the directory is emptied again. Files are
created `O_EXCL | O_NOFOLLOW`, never through a symlink, with modes derived from the
directory's own (a `2750` site directory gets `0640` files and `2750` directories; a
`0755` one gets `0644` and `0755`); set-uid bits are never kept. A download is written
to an unlinked temporary file inside the target and is gone with the process. The audit
log carries the source and the sha256 of what was installed.

A change that does not validate is undone before the answer: the file is removed or the
previous one restored, and the old configuration keeps serving.

**Root work.** With `provision = true` (the default) a server started as root forks a
small helper before it drops privileges. It holds the other end of a socketpair, never a
path, and does six things and nothing else: create a site account (`useradd --system`,
`nologin`, home in the state directory), lay out a site's directories under `sites_root`
(`owner:<server group> 2750`, walked without following symlinks, refused when a directory
belongs to another site), hand a per-site log to the site's group, write the php-fpm
pools and reload php-fpm, restart the service after a change that needs one, run a
`site-install` or a `site-copy` in a child that has become the site's account (the helper
opens an upload as root, the child drops to the account before reading a byte), and run a
`site-task` the same way, after creating the account's home when it is missing. Programs
run by absolute path with a fixed argument list and no shell; every argument is checked
again inside the helper with the same rules; every action is audited. Beside it a second
root process, its reader, forked the same way on a socketpair of its own, answers the reads
(health's checks of the environment files, the services and the host's protection,
`site-service`, `site-service-logs`, `trash`, the PHP versions) and checks approval codes, and
nothing else; the helper refuses those, so a task that holds the helper for minutes holds none
of them (before 0.1.0-alpha.127 they answered busy, and a code waited for the task).
`site-create` then does the whole job in one call and lists what it did under `done`. With `provision =
false`, or a server not started as root, what needs root comes back as commands, as
before, and `site-install` runs on a thread of the server as its own account, so it can
only fill directories that account owns. `docs/security-control-plane.md` states what a
compromised server could and could not do through the helper.

Unknown commands answer a JSON 404, a wrong method a 405 with `Allow`, a role that is too
low a 403 naming the role needed. `curl --unix-socket /run/agensio/control.sock
http://control/v1/status` is the same call by hand.

`agensio mcp` exposes the same commands to an AI agent host as Model Context Protocol
tools, locally or over SSH: see `docs/mcp.md`.

`agensio -t` on a shared host warns when a php-fpm pool, proxy origin or CGI location
runs as the server's own user or as a member of the admin group: with everything under
one account the peer-credential check cannot tell sites apart. Per-site users (section
11) are what makes the control socket safe on a shared host.

## 16. HTTP/2

HTTP/2 (RFC 9113) is on for every TLS listener: a client that offers `h2` through ALPN
gets it, any other client gets HTTP/1.1 on the same port. A site may name its own
`protocols` when its listeners must differ from the server's (a TLS port kept at HTTP/1.1
next to one offering h2; the sites sharing an address must agree), and every HTTP/2
limit derives from keys you already know. The design, the
comparison with nginx, Caddy, lighttpd and HAProxy, and the threat model are in
`docs/design-http2.md`.

```toml
[server]
protocols = ["h2", "h1"]          # the default; order = ALPN preference
# protocols = ["h1"]              # HTTP/2 off, for instance during an incident
# protocols = ["h2c", "h2", "h1"] # also accept prior-knowledge HTTP/2 on plain listeners
http2 = { max_concurrent_streams = 128 }
```

| key | default | meaning |
|---|---|---|
| `protocols` | `["h2", "h1"]` | what TLS listeners offer through ALPN, in order of preference (Caddy's names; `"http/1.1"`, the ALPN identifier, is accepted for `"h1"`). `"h2c"` in the list makes plain listeners accept HTTP/2 with prior knowledge (the connection preface; `curl --http2-prior-knowledge`, `h2load`, a backend behind a proxy). Browsers never use h2c, so it is off by default. `"h3"` adds HTTP/3 over QUIC on every TLS listener's port number, over UDP (section 17). |
| `http2.max_concurrent_streams` | 128 | streams a client may have open at once on one connection (`SETTINGS_MAX_CONCURRENT_STREAMS`, nginx's default); a stream beyond it is refused, the connection stays |
| `protocols` on a `[[site]]` | the server's | the same list for this site's listeners only: `protocols = ["h1"]` on a TLS site keeps that port at HTTP/1.1 while another offers h2, `["h2c", "h1"]` on a plain site accepts the preface there alone. Every site on an address must list the same, or `-t` refuses the file. |

What derives from the other keys, so that HTTP/2 needs no tuning of its own:

| HTTP/2 limit | comes from | value at the defaults |
|---|---|---|
| `SETTINGS_MAX_HEADER_LIST_SIZE`, the decoded size of a request's fields, and the size of a compressed header block | `max_header_size` | 16 KB each; a block over either closes the connection (`ENHANCE_YOUR_CALM`), a peer doing that is not a browser |
| streams on one connection before `GOAWAY` | `max_requests_per_connection` | 1000, like a keep-alive connection's requests |
| a connection with no stream open, or a stream whose head or response makes no progress | `idle_timeout` | 15 s |
| a write the client does not take (it stopped reading), whatever it sends meanwhile | four `idle_timeout`s | 60 s, then the connection is closed (nginx's `send_timeout`); a cycle is at most 64 KB over TLS, so 1.1 KB/s keeps it |
| a body announced but not arriving | `body_timeout` | 60 s |
| the request-body limit and the size of the receive windows | `max_body_size`, or the site's own | 1 MB per stream and per connection at most, so an upload runs at the pace of the disk or the origin rather than 64 KB per round trip |
| `SETTINGS_MAX_FRAME_SIZE`, `SETTINGS_HEADER_TABLE_SIZE` | fixed | 16 KB, 4 KB |

Two counters per connection close it when a client misbehaves, whatever the shape of the
attack (Rapid Reset, MadeYouReset, CONTINUATION floods, PING and SETTINGS floods, empty
frames, window-update dribbles, HPACK bombs; the list is in the design document): 100
protocol glitches (a `GOAWAY` is sent at 75 so a slightly broken client can reconnect and
carry on), and 128 streams cancelled before a response within one second, by either
side. Every `GOAWAY` and `RST_STREAM` the server sends is one line in the error log at
level info with the client address, the stream id, the error code and the reason.

Requests over HTTP/2 are logged as `"GET /path HTTP/2.0"` (`"proto":"HTTP/2.0"` in JSON),
and PHP sees `SERVER_PROTOCOL=HTTP/2.0`. `agensio ctl status` names the protocols of each
listener. Server push is not implemented (browsers removed it), nor the RFC 7540
priority tree (deprecated; PRIORITY frames are ignored), nor `Upgrade: h2c`.

## 17. HTTP/3

HTTP/3 (RFC 9114) over QUIC (RFC 9000) is agensio's own transport, with OpenSSL 3.5's
QUIC TLS API for the handshake and its ciphers for the packets; the design, the
comparison with the other servers and the threat model are in `docs/design-http3.md`,
the specifications in `docs/rfc/`. It is on where `protocols` lists `"h3"`, server-wide or
on a TLS site, and then every TLS listener of that list also answers on the same port
number over UDP, and every HTTP/1 and HTTP/2 answer of it carries `alt-svc` so browsers
switch on their next connection:

```toml
[server]
protocols = ["h2", "h1", "h3"]   # h2 and h1 over TCP through ALPN, h3 over QUIC on the same ports
```

**Which builds have it.** HTTP/3 needs OpenSSL 3.5.1 or later (the QUIC TLS API; 3.5.0 dropped the
transport parameters when the SNI callback switched the certificate's context) and Linux; a build
without it serves TLS, HTTP/1 and HTTP/2 and refuses `"h3"` naming why. Each release carries two
`.deb` files: the one with `deb13` in its name is built on Debian 13 against its OpenSSL 3.5 and has
HTTP/3 (it installs on Debian 13 and later); the other is built on Ubuntu 22.04 for Debian 12, Ubuntu
22.04 and later, whose OpenSSL 3.0 has no QUIC API, and has none. The Arch package and a source build
on Debian 13, Ubuntu 26.04, RHEL 9.7 or 10.1, Fedora 43 and later have it too (`docs/install.md`).
`server_status` (`agensio ctl status`) says what the running build serves under `protocols`, with the
OpenSSL it loaded and, without HTTP/3, why; health's `http3_package_available` (information) names a
build without HTTP/3 on a system whose OpenSSL has the QUIC API (the Debian 12 package on Debian 13).

What it needs from the host: UDP open on the listener's port in the firewall (the TCP
port alone gives a client nothing to reach), a build with OpenSSL 3.5 or later on Linux
(`-t` refuses `"h3"` on any other, so a configuration file moves between hosts
predictably); h2load and curl choose `--alpn-list=h3` / `--http3-only` directly, a
browser follows the `alt-svc` field. With `reuse_port` (Linux, the
default) every worker has its own UDP socket on the port and a classic BPF program on the
group delivers each packet to the worker that issued its connection id, so a connection
never changes worker (design 6.1); where the kernel refuses the program the 4-tuple hash
routes each connection to one worker instead. Without `reuse_port` one socket on worker 0
serves the listener.

**Turning it on by a reload.** A reload opens the UDP sockets of a listener that gains `"h3"` before
it switches, as it binds a new TCP address. On a privileged port (443) a server that started as root
and dropped to `server.user` can no longer bind them: the reload then applies everything else,
serves that listener over HTTP/2 and HTTP/1 without `alt-svc` (so no browser is sent to a port
nothing answers), and says that HTTP/3 there waits for a restart, in its answer (`restart_needed`:
`h3 on udp 0.0.0.0:443`), in the error log and as health's `h3_waits_for_restart`. A restart binds
it as root. Before 0.1.0-alpha.111 that reload ended the server (the socket was opened after the
switch, and the failed bind was thrown out of worker 0), and systemd restarted it.

A bind that fails for another reason, a UDP port another process holds above all, is not a matter for
a restart: a start that cannot bind its h3 sockets does not start, and so serves no site. The reload
applies the rest the same way and says what holds the port (`ss -lunp 'sport = :PORT'` names it) and
to reload once it is free: in its answer's `next_steps`, not under `restart_needed`, in the error log,
and as health's `h3_not_bound`. Every reload tries the bind again, so the next one after the port is
freed opens HTTP/3 with nothing changed on disk. Status's listener carries `h3_waiting` with the bind's
error in both cases until then. Until 0.1.0-alpha.113 every failed bind was said to be a privileged port
waiting for a restart (the alpha.112 report).

The sockets ask the kernel for 4 MB receive and send buffers. Linux grants at most
`net.core.rmem_max` and `net.core.wmem_max`, 208 KB on an untuned host, and the startup
line (and the error log) then says so: `receive buffer 208 KB (raise net.core.rmem_max
for bursts of handshakes; 4 MB asked)`. A burst of handshakes larger than the buffer
loses Initials, which the clients retry after their probe timeout, one to three seconds
later (256 connections opening at once do that on loopback), so a server that expects
hundreds of connections to open together raises both limits as root and persists them:

```
sysctl -w net.core.rmem_max=8388608 net.core.wmem_max=8388608
printf 'net.core.rmem_max = 8388608\nnet.core.wmem_max = 8388608\n' > /etc/sysctl.d/90-agensio-quic.conf
```

The buffers are set when a socket opens: at start and at a reload that adds h3 to a
listener; a running socket keeps what it got.

Every HTTP/3 limit derives from keys you already know:

| HTTP/3 limit | comes from | value at the defaults |
|---|---|---|
| streams a client may have open on one connection (`initial_max_streams_bidi`, then `MAX_STREAMS` as they close) | `http2.max_concurrent_streams` | 128 |
| the field section limit (`SETTINGS_MAX_FIELD_SECTION_SIZE`) and a request stream's first window | `max_header_size` | 16 KB |
| the window a request body gets, and the connection's | `max_body_size`, or the site's own | up to 1 MB |
| the idle timeout (`max_idle_timeout`) and the handshake's bound | `idle_timeout` | 15 s |
| a body announced but not arriving | `body_timeout` | 60 s |
| the QPACK dynamic table a client's encoder may fill (`SETTINGS_QPACK_MAX_TABLE_CAPACITY`) and the field sections that may wait for it (`SETTINGS_QPACK_BLOCKED_STREAMS`) | fixed | 4 KB, 16 streams (each holding at most `max_header_size` of encoded section) |
| the QPACK dynamic table our answers use on the client's side (`server`, `date`, `content-type` as one index byte each after the first) | fixed, and at most what the client announces | 1 KB; none for a client that announces no table (curl) |
| the datagram size | 1,200 bytes until the path is probed after the handshake (a padded PING, outside the congestion window; acknowledged, the size is the probe's and the next probe doubles it; lost, the search stops); probed again when the client's address changes | 1,472 bytes over IPv4 and 1,452 over IPv6 on a 1,500-byte path; up to what the client announces (65,527 at most) on loopback or a jumbo-frame network |
| connection ids issued to a client, and accepted from it | fixed (RFC 9000 5.1) | 4 each; a retired id is replaced, at most 64 per connection |
| handshakes in progress per worker | fixed | 1,024; see `http3.retry` |
| stream resets a client may send per second (`RESET_STREAM`, `STOP_SENDING`) before the connection closes with `H3_EXCESSIVE_LOAD` | `http2.max_concurrent_streams` | 128 |
| protocol glitches (flow-control or stream credit that does not raise the limit) before `PROTOCOL_VIOLATION` | fixed | 100 |

The one key of its own:

```toml
[server]
http3 = { retry = "auto" }   # "auto" | "always" | "never"
```

| key | default | meaning |
|---|---|---|
| `http3.retry` | `"auto"` | whether a new client must first answer a Retry (RFC 9000 8.1.2): a stateless packet carrying a token bound to the client's address, the original connection id and the time, valid ten seconds, that the client repeats in its next Initial; the round trip proves the address before the server spends a TLS session on it. `"auto"` sends Retry once a worker has 512 handshakes in progress and drops further Initials at 1,024; `"always"` for a host under a handshake flood (every new connection pays one round trip); `"never"` for a benchmark that must not pay it. An Initial whose token does not open is answered with `INVALID_TOKEN` and forgotten |
| `http3.alt_svc` | `true` | every HTTP/1 and HTTP/2 answer of a TLS listener that also speaks h3 carries `alt-svc: h3=":port"; ma=86400`, which is how a browser learns to switch to HTTP/3 on its next connection (design 7.4); `false` removes the field, and clients that know the port (`curl --http3-only`, h2load) still connect over QUIC |

What else the transport does without a key: a client whose address changes (a NAT
rebinding) keeps its connection, the new path is validated with a `PATH_CHALLENGE`
before more than three times the bytes received on it are sent to it, and the previous
address is used again if the validation fails; a client that updates its keys (RFC 9001
6) is followed, a second update before the first is acknowledged is `KEY_UPDATE_ERROR`,
and the server updates its own keys at the AEAD's confidentiality limit; a packet for a
connection nobody here knows (a client of a server that restarted) is answered with a
stateless reset (RFC 9000 10.3), smaller than the packet, at most 1,000 per second per
worker, and the reset token of every id is derived from a per-process secret, so any
worker can answer for any id.

Requests over HTTP/3 are logged as `"GET /path HTTP/3.0"` and PHP sees
`SERVER_PROTOCOL=HTTP/3.0`; `agensio ctl status` lists `h3` among a listener's protocols.
A reload that removes h3 from a listener (or the listener itself) tells that listener's
HTTP/3 connections GOAWAY and closes them with H3_NO_ERROR, then closes its UDP sockets;
a reload that adds h3 to a TLS listener opens them. Not yet (the design's I1b to I4):
request bodies from unbuffered upstreams over h3, 0-RTT, ECN, NEW_TOKEN for later
connections.

## 18. Connection limits

**The server's part: a ceiling per worker.** `[server] max_connections` is the number of
connections one worker holds at once, TCP (HTTP/1, HTTP/2) and QUIC together. Unset (0),
it comes from the open-file limit the server raises at start: `(limit - 2048) / workers`,
never below 128, so a worker can never run itself out of descriptors (2048 are kept for the
cache's open files, the logs and the connections to php-fpm and origins). A connection
accepted above the ceiling is refused at once: a plain listener answers `503 Service
Unavailable` with `Retry-After: 2` and closes, a TLS listener closes before any handshake
work, and a new HTTP/3 connection is refused with QUIC's `CONNECTION_REFUSED` in one small
Initial packet, before Retry or any handshake work (RFC 9000 20.1; until alpha.116 QUIC
handshakes went past the ceiling), counted once per attempt though a ClientHello with a
post-quantum key share takes two Initial packets, so a flood buys no CPU. The control socket's
own connections are never refused and never counted. What happened is kept for whoever investigates, without a
shell: the error log line (once per worker per ten seconds) says how many connections the
worker holds and how many of those have been idle for two seconds or more, how many it
refused since the last line and since start, from which addresses (the most refused first)
and on which listener; `server_status` shows `max_connections`, `connections_refused`,
`connections_idle` and, per worker under `workers_detail`, the same addresses, listeners
and times; health reports `connections_refused` with a fix that follows from the shape:
most refusals from one address (the firewall's job, nothing to raise), workers full of
connections idle for two seconds or more (slow or stuck clients: compare with the access
log's request rate, lower `idle_timeout`), or many addresses with busy workers: real load or
slow clients, which send a request head or body a byte at a time and never count as idle; few
completed requests in the access log for that many connections says which (load: raise the limit;
slow clients: limit connections per address in the firewall, lower `body_timeout` or
`idle_timeout`, which bounds an unfinished head). Set it when the derived value is wrong
for the host: smaller to cap memory (an idle HTTP/1 connection costs about 13 KB, HTTP/2
19 KB), larger only with a larger `LimitNOFILE`.

```toml
[server]
max_connections = 20000   # per worker; 0 = from the open-file limit
```

**What the server does not do: per-address limits.** Counting connections or requests per
client address across workers would cost on the accept path exactly where agensio saves
its microseconds, and the kernel already keeps that table. Put those limits where each
belongs:

- Connections and connection rate per address, SYN floods: the firewall. With nftables, a
  rule such as `tcp dport { 80, 443 } ct state new meter per-ip { ip saddr limit rate over
  30/second } drop` and `ct count over 200` per source address stop a single client before a
  byte reaches the server; your provider's DDoS protection or a CDN handles what fills the
  pipe.
- Brute force on logins and APIs (`wp-login.php`, `xmlrpc.php`, Kanboard's `jsonrpc.php`):
  fail2ban or CrowdSec reading the access log, whose line and escaping are Apache's and
  nginx's (`vhost_combined` with the host in front, or `combined`, section 8) so the shipped
  filters, and with `combined` their stock ones, apply, banning through the firewall for a while.
- Slow and idle clients, protocol abuse (HTTP/2 reset floods, QUIC address validation):
  agensio's own timeouts and budgets, which only the server can judge (sections 16 and 17).

**Shipped: the ruleset, the jails, and the check** (2026-10-02). agensio does not apply any of
this, but it renders both pieces for the host it runs on and reads back whether they are in
place. The administrator's guide to the fail2ban side, with what each application type gets
and what to add in the application, is `docs/fail2ban.md`. `agensio ctl protection` (the MCP tool `protection_show`, and `agensio protection -c
FILE` with no server running) answers with the files, root's commands and what the kernel
and fail2ban do now; `--nft`, `--jail`, `--unit` and `--filter NAME` print one file alone,
for root to redirect into place. The packaged copies under `/usr/share/agensio/` are the
rendering for ports 80 and 443 (`agensio protection --defaults`); nothing is installed into
the live firewall or into `/etc/fail2ban` by a package, ever.

*The firewall.* The ruleset lives in a table of its own, `table inet agensio`, with the
host's public ports (every listener not on loopback; QUIC's UDP port when `h3` is on): per
source address, more than 30 new connections a second are dropped (bursts of 60 allowed),
the 201st connection held is refused with a reset, and more than 50 QUIC handshakes a second
(long-header packets, the first byte's top two bits, RFC 9000 17.2) are dropped, while a
connection's data packets are never limited; IPv6 is counted per /64, one subscriber.
Nothing outside that table is touched, no other table, chain or policy, so the
distribution's firewall, a panel's rules, ufw and firewalld keep theirs and this keeps its
own, and `nft delete table inet agensio` removes every trace. Loading the file twice is
harmless (it deletes and recreates its own table). Root applies it the way network gear
does, commit-confirmed, so a mistake undoes itself:

```sh
agensio ctl protection --nft --out /run/agensio-firewall-trial.nft   # the ruleset for this host's ports, to try
nft -f /run/agensio-firewall-trial.nft                               # in the kernel only; a reboot drops it
systemd-run --on-active=10min --collect --unit agensio-firewall-trial /usr/sbin/nft delete table inet agensio
#   ... the site answers, this SSH session is alive, `agensio ctl protection` says covered ...
systemctl stop agensio-firewall-trial.timer || true                  # keep it: cancel the undo (gone once it fired)
agensio ctl protection --nft --out /etc/agensio/firewall.nft          # the kept ruleset
systemctl enable agensio-firewall.service                            # loaded at every boot
systemctl reload-or-restart agensio-firewall.service                 # and now
```

The trial has a file of its own and never touches the kept one. On a host that keeps a ruleset
already (`agensio-firewall.service` enabled with its file: a new port, or `h3` turned on, renders it
again), the timer's command is `/usr/sbin/nft -f /etc/agensio/firewall.nft` instead: it goes back to
the kept table, never to none, so a keep missed for ten minutes leaves the host as it was. Until
0.1.0-alpha.112 the trial wrote the kept file and its timer deleted the whole table, the limits kept
for weeks included (the alpha.111 report). `agensio ctl protection` and the health fixes give the
right command for the host, and a site change's next steps and health's re-render fixes are this
same trial. Keep works in every state: before or after the timer fired, on a unit active since boot
or one not started yet. `systemctl enable --now` starts nothing on a oneshot that is already active,
so on a host that kept a ruleset it loaded no new file. A timer that fired is unloaded, and `systemctl
stop` then exits 5 ("not loaded"), hence the `|| true` (bash, dash and fish 3 and later): keep's steps,
run each once the one before it succeeded, go on past it (until 0.1.0-alpha.113 they stopped there,
the alpha.112 report). `--collect` unloads the timer's unit even when its command failed;
otherwise its name stays taken, and the next trial's `systemd-run` would refuse it with that trial's
ruleset already loaded.

`agensio-firewall.service` (packaged) is a oneshot that runs `nft -f /etc/agensio/firewall.nft`
after the distribution's firewall and before agensio; `--unit` renders it for a
configuration kept elsewhere. A manual `systemctl restart nftables` on Debian runs
`/etc/nftables.conf`, which usually begins with `flush ruleset`: `systemctl reload-or-restart
agensio-firewall` puts the table back (health names an enabled unit whose table is gone), or add
`include "/etc/agensio/firewall.nft"` to that file instead of the unit.

*fail2ban.* Jails over agensio's access logs (the `vhost_combined` and `combined` formats, the
host:port prefix optional in every filter; the filters do not read JSON logs) and its error log,
rendered for this host's logs, ports and sites: `agensio-login`
counts credentials posted to the sites' login paths, ten in ten minutes bans for an hour (a
failed and a successful login look alike in an access log, so this counts attempts: no one
types ten passwords in ten minutes, every tool does); `agensio-auth` the error log's `auth
failed` lines, the failed passwords on `[[site.auth]]` paths (section 19b), never a 401, which
is the challenge every browser meets first (until alpha.58 it counted every 401 and 403, and
so banned the people with a site's password; it needs the error log in a file at `warn`, the
package's default); `agensio-denied` bursts of 403 (an address outside an access rule, an
application refusing); `agensio-scan` bursts of 404 (forty in five minutes); `agensio-post` bursts of POST to any
path (120 in two minutes), the catch-all for a login nobody named, with an `ignore`
parameter for an API posted to that often (`filter = agensio-post[ignore="/api/|/jsonrpc\.php"]`).
Bans go through nftables into fail2ban's own table (`banaction = nftables-multiport`); a
host whose firewall is managed otherwise overrides that in a `jail.local`. The five filters
are static and shipped; the jail file carries what is the host's:

```sh
install -m 644 /usr/share/agensio/fail2ban/filter.d/agensio-*.conf /etc/fail2ban/filter.d/
agensio ctl protection --jail --out /etc/fail2ban/jail.d/agensio.conf     # this host's logs, ports, login paths
fail2ban-client reload
```

**Files root loads are written by agensio itself** (0.1.0-alpha.95): `--out FILE` on `agensio ctl
protection --jail`, `--nft`, `--unit` and `--filter NAME`, on `agensio protection` (the render from the
configuration alone) and on `agensio ctl site-unit NAME` writes the file whole, `0644` whatever root's
umask, through a temporary file renamed into place. When the render fails (the server stopped, the
socket unreachable, a refused call) the file is left as it was and the command exits non-zero, so the
reload after it is not run when the steps are chained with `&&`. A finding's fix carries its steps
joined that way; the lists `protection_show` and `site-unit` answer (`fail2ban.install`,
`firewall.trial`, `firewall.keep`, `run_as_root`) are the same steps one per item, to run in order,
each only after the one before it succeeded. A shell's `>` did neither: the file took
root's umask (`0664` under a umask of `0002`, writable by root's group, and root loads it), and the
shell emptied it before `agensio` ran, so a failed render left an empty jail that `fail2ban-client
reload` then loaded. Health's `root_file_writable` names the jail, the ruleset, the firewall unit, a
site's application unit or a generated php-fpm pool that its group or anyone may write (a warning for
the group, an error for anyone), with the `chmod go-w` that fixes it; `agensio pools` rewrites a pool
file of a loose mode.

The login paths come from two places. A preset knows its application's: `wordpress`
`/wp-login.php` and `/xmlrpc.php` (one `system.multicall` tries hundreds of passwords; a
client that posts there more than ten times in ten minutes, the WordPress mobile application
without Jetpack, is banned for an hour), `drupal` `/user/login`, `laravel` `/login` and
`/cp/auth/login`, `grav` `/admin`, `redmine` `/login`, `django` and `wagtail` `/admin/login/`.
A site whose preset cannot know (`php`, `rails`, `node`, `proxy`, `static`) names its own
with `login_paths`, a `[[site]]` key the control plane also writes (`site_update`
`login_paths`, `agensio ctl site-update NAME --login-path /login`, `--no-login-paths`):
plain URL paths, at most 16, nothing served or refused by them, so an agent can set them
from the application's documentation after asking the user. An application that routes its
login through the query string is named with it, and the jail matches the query from its
start, whatever follows: Kanboard `/?controller=AuthController&action=check`, Roundcube
`/?_task=login`, phpBB `/ucp.php?mode=login`; the bare `/` is refused, since every form
post of such an application goes there. A query holds letters, digits and `._~/=&+:-`.
The jail matches each path in every spelling the server and the applications accept, since
the log holds the request as the client sent it (the alpha.44 and alpha.45 reports found
twenty spellings of the login URLs that reached the form and escaped a literal match): every
character literal or percent-encoded in either case's code, slashes and dots literal or
encoded, repeated slashes, `./` and `seg/../` segments, any case, for a PHP preset's path
an optional `/index.php` front controller before it and path info after a `.php` file, for
a Rails or Redmine path an optional `.format` suffix, and for a login routed through the
query string its parameters in any order with others allowed. Nothing more: `/index.php`
alone or with another query is no login, nor is `/admin.php` on a Grav site, so an
application's ordinary form posts are never counted. The grammar is unambiguous, so a 16 KB
request line of slashes or dot segments costs linear time whether the login path is plain or
routed through the query (the first grammars took seconds and minutes; fail2ban's regex
holds the daemon's lock while it matches, so every jail would have waited). The
rendered regex spells `%` as `\x25`, so the jail file never meets configparser's
interpolation; the separator grammar is written once, as the filter's `sep` variable that
every path refers to as `<sep>`, and a letter's two percent codes are one hex class, so a
path's entry is about a hundred characters. This is the attempt-counting tier that needs
nothing from the application.

*The failure tier.* An application that logs its own failed logins gives fail2ban the better
signal: failures, not attempts, with the client address in the line and no URL spelling to
match. Where a preset's application does, `agensio ctl protection --jail` renders a jail over
that log with the filter fail2ban or the application ships: WordPress through the WP fail2ban
plugin, which logs every failed login, form and XML-RPC, to the auth facility
(`/var/log/auth.log`, `/var/log/secure` on RHEL) and brings its own `wordpress-soft` and
`wordpress-hard` filters, rendered as `agensio-wordpress-soft` (five failures in ten minutes
ban for an hour) and `agensio-wordpress-hard` (what the plugin logs as hostile at the first
hit, a day); Drupal through its core Syslog module (`/var/log/syslog`, `/var/log/messages` on
RHEL) with fail2ban's own `drupal-auth` filter, `agensio-drupal-auth`. On a host where no
syslog daemon writes files (journald only, Debian 13's default; told by the daemons' pid
files under `/run`) the jail reads the journal instead, `backend = systemd` with a
`journalmatch` on each site account's uid (`_UID`, a field journald sets from the sender's
credentials, with Drupal's identity or the php-fpm unit beside it; never the identity alone,
which any process may claim, the alpha.49 report), so neither application needs rsyslog and
a stale file that nothing writes never passes for a log; a site without an account of its
own has no trusted field and is listed as `unidentified`, not read, until it gets one; an
account of an ordinary uid (1000 or above, a panel's web user) gets `backend =
systemd[journalflags=1]`, since journald files its lines under the user's journal, which
fail2ban reads only with that flag (`docs/fail2ban-ref/`). Each such jail is rendered enabled only when its filter file exists, and
with a syslog daemon its log too, since fail2ban refuses a configuration naming either when
missing; otherwise it is written disabled with its `needs`: the plugin installed and
activated from the WordPress admin panel and root's copy of its two filter files into
`/etc/fail2ban/filter.d/`, taken from the plugin's release rather than from the site's
directory, which the site's account can write; Drupal's Syslog module enabled under Extend;
then the jail rendered again. agensio installs no
plugin and changes no application: `site_install` of WordPress or Drupal puts those steps in
its `next_steps`, health reports `fail2ban_failures_unseen` while they are open, and
`protection_show` lists the jails under `failure_jails`. On a journald-only host, where a
jail is enabled before the application writes anything, the helper asks the journal for one
line matching the jail's own `journalmatch` from the last 30 days, `journalctl` with fixed
arguments, and the finding stays while there is none, with the application's step as
its fix (`journal_seen` in `protection_show`). The attempt tier keeps counting
meanwhile. There is one login jail per access log, `agensio-login` for the server-wide
log and `agensio-login-<site>` for a site's own, each with the login paths of the sites
writing that file, so one application's paths are not counted on another's log. `site_show` lists the effective ones. The jail file is
rendered from the sites that exist, so adding a site, a log or a login path makes the
installed file stale; health says so (`fail2ban_jail_stale`) and the two lines above
refresh it.

```toml
[[site]]
server_name = ["kanboard.example.com"]
app = "php"
login_paths = ["/?controller=AuthController&action=check"]   # where Kanboard's form posts
```

*The check.* On a host with a public listener, `health` asks the root helper (nft needs
`CAP_NET_ADMIN`, fail2ban's socket is root's) what is in place, with fixed arguments: `nft
-j list ruleset`, `systemctl show` of the two agensio units and the firewall services, and
`fail2ban-client status` per jail. The findings and their fixes: `firewall_limits_missing`
(no per-source limit on a public port in any table; a panel's or the administrator's own
counts as protection, so a host that already limits is never nagged; or `agensio-firewall.service`
enabled while its table is gone, after a trial's timer, `nft delete table` or a flush, fixed by the
unit's `reload-or-restart`), `firewall_limits_trial` (loaded, the timer pending: back to the kept
ruleset or, with none kept, no table), `firewall_limits_unsaved` (loaded, not enabled at boot, or
unknowable without systemd), `firewall_quic_unlimited` (the table predates `h3`),
`fail2ban_missing` (not installed, not running, or no jail reads agensio's logs),
`fail2ban_jail_stale`, `fail2ban_filter_stale` (an upgrade changed a shipped filter and the
installed copy is the old one: the jails match what the older build matched, so the install
line comes first; comment lines are not compared, so a file whose comments alone differ, from an
upgrade or a note added by hand, is named as such, information with no reload; rendering replaces
the file, so settings and notes of your own belong in `/etc/fail2ban/jail.d/agensio.local`;
`protection_show`'s `firewall.file_state` says the same of the ruleset file), `fail2ban_log_format` (JSON logs), `fail2ban_blind` (a site without
an access log), `protection_unchecked` (no helper). Nothing is reported for a host whose
listeners are all on loopback. `agensio ctl protection` shows the same with the detail: the
ports each table limits, each of agensio's rules with its hit counter, the jails with the
files they read and the addresses banned now and since start.

```toml
[control]
host_protection = "check"    # "external": a panel manages the firewall and fail2ban, findings
                             # are informational; "off": no probe, the files still render
```

*Hosting panels.* On a host a panel runs, the panel owns the firewall and fail2ban; agensio
behaves like any other service there: a jail drop-in with its filters, the shape Postfix,
Dovecot and sshd ship, which appears in the panel's fail2ban page; a firewall table that
coexists with the panel's rules; detection that counts the panel's own limits; the
renderer and the check reachable without the MCP bridge (`agensio ctl protection`, the
control API's `GET /v1/protection`, `agensio protection -c FILE` offline), so a panel that
writes the site files itself can script the install, trial step included; and
`host_protection = "external"` to say the panel has it.

## 19. Access by client address

A path, or a whole site, answered only to some client addresses: an administration area kept
to the office or the VPN, a staging copy kept to the team. Everyone else gets `403` with the
address the server saw.

```toml
[addresses]                      # top level of the main file: named sets, root's
office = ["203.0.113.7", "2001:db8:5::/64"]
vpn    = ["10.8.0.0/16"]

[[site]]
server_name = ["shop.example.com"]
app = "wordpress"
root = "/srv/www/shop.example.com/web"

[[site.access]]
path = "/wp-admin"               # /wp-admin, /wp-admin/ and everything below; never /wp-administrator
allow = ["@office", "@vpn"]

[[site.access]]
path = "/wp-login.php"
match = "exact"                  # this path, and the script run as /wp-login.php/...
allow = ["@office", "@vpn"]
```

**What a rule covers.** A rule on a directory's index file holds at the directory too: `/`
answering with `/index.html` is judged as a request for `/index.html` (alpha.55). A prefix rule covers its path and everything below it on a segment
boundary, in any capitalisation (some filesystems and applications answer `/WP-ADMIN/` with
`/wp-admin/`); `match = "exact"` covers the path and the requests that run it as a script
(below); `path = "/"` covers the whole site. The
longest rule that covers a path decides, and rules never merge: `allow = ["any"]` on a longer
path reopens it below a restricted one. Every rule is an allow list, so nothing is open by
omission, and an empty list is an error rather than "everyone" or "no one".

**Exact rules and scripts run with path info.** An exact rule covers its path and every request
agensio runs as that same script. A PHP location with `path_info` (the default) runs
`/wp-login.php/x` as `/wp-login.php` with `PATH_INFO = /x`, and a CGI location runs
`/cgi-bin/report/2026` as `/cgi-bin/report` when `report` is the file, so an exact rule on the
script holds for those requests too; one on a directory's index served by PHP
(`/legacy/index.php`) holds for `/legacy/`. Nothing else widens it: `/info.phpx`,
`/info.php.bak/x`, `/info.html/x` and a PHP location with `path_info = false` run no such script,
and the rule leaves them alone. The split is the one the PHP and CGI handlers use themselves
(`core/script_split.hpp`), so the rules and the handlers cannot disagree on which script runs.
`path_check` names the script a path runs (`script`). In front of a proxied application agensio
runs nothing and an exact rule judges its path alone; only the application knows whether it runs
`/x.php/y` as `/x.php`, so `-t`, the error log and health note an exact rule on a `.php` path
there (`exact_rule_proxied_script`), and a prefix rule covers both forms. This is stricter than
nginx's `location =`, Caddy's exact `path` and HAProxy's `path`, which cover the path alone, the
forms WordPress's hardening page gives for `wp-login.php`. Before 0.1.0-alpha.59 an exact rule
here covered the path alone too, and `/wp-login.php/x` reached the login page past it.

**Why it is not a location key.** The rules are checked on the normalised path after the site
is found and before any location is chosen, so whichever location would serve the request (a
`.php` suffix location, a proxy, a static file, a `try_files` fallback) is covered. In nginx,
`allow`/`deny` inside `location /wp-admin/` does not protect `/wp-admin/admin.php`, because the
`location ~ \.php$` regex wins that request; that trap cannot happen here. The other ways an
application may read the same path are judged too: a `;parameter` in a segment (Tomcat and
Jetty read `/x/..;/admin/` as `/admin/`), a percent sign left after decoding (an origin that
decodes twice), and the path after a script (`/index.php/admin` reaches the route `/admin` of
a front controller).

**WordPress.** Its public pages call `/wp-admin/admin-ajax.php` (search, carts, comment
forms), and the login page loads its styles, scripts and logo from `/wp-admin/css/`,
`/wp-admin/js/` and `/wp-admin/images/` (WordPress's `script-loader.php`; WooCommerce's
account page takes the password meter from there too), or, as WordPress usually does,
concatenated through `/wp-admin/load-styles.php` and `/wp-admin/load-scripts.php`
(`script_concat_settings` on `login_init`). So when `/wp-admin` is restricted and the whole site
is not, the preset keeps those three scripts (exactly: `/wp-admin/load-styles.php/x` stays
restricted) and those three directories open to anyone (`agensio -t --explain` shows the rules,
`# from preset:wordpress`); before 0.1.0-alpha.61 the two concatenating scripts were not among
them, and the login page came unstyled or asked for a password. The directories hold
WordPress's own static files and the preset runs no script there (section 4). The two
concatenating scripts are WordPress core files every installation keeps public: they load no
plugin, no database and no login and print only core styles or scripts named in the query.
Asking `load-scripts.php` for every script at once costs the server some work, a known
WordPress trait (CVE-2018-6389) the firewall's per-address limits answer (section 18). Write
your own rule for one of those paths to change that.

**Admin panels.** A site's administration is open to everyone by default, as WordPress and
Drupal ship it: their own login, the fail2ban jails (section 18) and the firewall's limits
protect it, and agensio never restricts it on its own. Keeping it to some addresses is the
site owner's choice, one field on a managed WordPress or Drupal site, `rules.admin` (section
15):

```json
"rules": {"admin": {"allow": ["@office", "2001:db8:5::/64"]}}
```

renders the preset's administration paths as `[[site.access]]` tables marked `# rules:
admin`. WordPress: the prefix `/wp-admin` (with the openings above), and with `"login": true`
the exact `/wp-login.php`. Drupal: the prefix `/admin`, the scripts `/update.php`,
`/core/install.php`, `/core/authorize.php` and `/core/rebuild.php`, and with `"login": true`
the prefix `/user/login`; `"languages": ["fr", "pt-br"]` adds `/fr/admin`, `/fr/user/login`
and so on for a site that negotiates the language by URL prefix, because Drupal answers its
routes under every prefix and a rule on `/admin` alone would leave `/fr/admin` open. `"mode":
"report"` tries it first. The presets catalogue (`agensio ctl presets`, MCP `presets_list`)
lists each preset's `admin_paths`, the login one marked. Two things the login rule does not
cover: WordPress also accepts a password at `/xmlrpc.php` (the mobile app and Jetpack use it;
restrict it with `rules.restricted` when nothing does), and a Drupal "User login" block placed
on public pages posts to those pages (remove the block when the login is restricted).

**Which address.** The connection's peer, or behind `[server] trusted_proxies` the forwarded
client (section 10). An IPv4 client of a `[::]` listener is matched as IPv4. Behind a CDN or
another proxy that is not in `trusted_proxies`, every request comes from the proxy: a rule
without its ranges refuses everyone, one with them admits everyone. Put the proxy in
`trusted_proxies` and allow the clients. "Only my CDN may reach this origin" is a different
need: the firewall's (section 18), on the peer, with authenticated origin pulls when it must
mean "through my account".

**The answer.** `403 Forbidden`, with `Cache-Control: no-store` (it differs per client) and a
line naming the address that was tested, so a user whose address changed can say which one the
server saw. The error log gets one `warn` line a second per worker, `access refused: site S
rule /wp-admin allows @office; client 198.51.100.4 GET /wp-admin/`; the refusals held back are
counted, `(N more refusals since the last such line, not written)`, written with the next line
or on its own once the second is over. The access log has every 403 with its client as usual,
and the `agensio-denied` fail2ban jail (section 18) bans an address that keeps hitting a
restricted path from outside.

**Trying a rule first.** `mode = "report"` serves everyone and logs `access would refuse:`
for each client the rule would refuse: every rule and client once a minute, whatever else is
refused, with the requests it made since its last line; past 16 new clients a second per worker
the rest are counted on a closing line. `agensio ctl access-check SITE PATH ADDRESS` (MCP
`access_check`) answers what the rules decide for one client without sending a request:
`refused by /wp-admin (allow @office): 198.51.100.4 is in none of its entries`. Check your own
address before you restrict a path you use.

**Managed sites.** `site_update` takes the same rules as `rules.restricted` (section 15):
`[{"path": "/wp-admin", "allow": ["@office"]}]`, with optional `"match": "exact"` and `"mode":
"report"`; `agensio ctl site-update SITE --restrict /wp-admin=@office,203.0.113.7` (and
`--restrict-exact`, `--no-restrict`) changes that list and keeps the site's other rules, and
`--restrict-admin @office,203.0.113.7` (with `--admin-login`, `--admin-language fr`,
`--no-restrict-admin`) does the same for `rules.admin`. A path in both lists is refused, and
together they hold at most 32 rules. `site_create` and `site_update` answer with the notes
`-t` would give for the new rules (`access: ...`). The
sets themselves are root's, in the main file; `config_reference` (MCP and `agensio ctl
reference`) shows each with its entries under the key `addresses`, and the trusted proxies'
ranges under `trusted_proxies`. The MCP server's instructions tell an agent to check the user's
own address with `access_check` before it applies a rule, and where refusals appear
(`logs_query`).

**What `-t` and health say.** An `allow` entry that holds a trusted proxy (a request the proxy
sends without `X-Forwarded-For` would pass), a loopback entry while no local proxy is trusted
(a tunnel such as cloudflared would make every client pass), a list of IPv4 addresses on a site
that listens on IPv6 too, a single IPv6 address (privacy addresses change daily: allow the
`/64`), and a whole site restricted (meant for staging). Refused outright, so the server does
not start or reload with them: an unknown key in `[[site.access]]` (a misspelt key would leave
the path open), an empty list, an unknown set, a zone id and an unnormalised path.

**Limits and cost.** At most 32 rules a site and 64 addresses a rule once the sets are
expanded; a longer list (a country, a cloud's ranges) belongs in the firewall, which keeps such
tables in the kernel. Deny lists are not offered: blocking one address is the firewall's and
fail2ban's job (section 18), and allow lists cannot be misread. A site without rules pays one
test per request; on a site with rules a path no rule can cover pays one bit test, and the
client's address is read only when a rule covers the path. Lists change with `agensio reload`,
which drops no connection.

A server older than 0.1.0-alpha.52 ignores `[[site.access]]` without a word: after an
upgrade, check with `agensio -t --explain` that the rules are listed.

## 19b. Passwords: `[[site.auth]]`

A password in front of a path: a staging site, an admin area, a tool without a login of its
own. The rules sit beside the access rules and are matched the same way, before any location
is chosen; an exact rule on a script covers it run with path info too (section 19). Every
method is asked but a CORS preflight on a path agensio serves itself (0.1.0-alpha.101): an
`OPTIONS` with `Origin` and `Access-Control-Request-Method` never carries credentials, so it gets
`204`, `Allow` and the site's response-header fields (the CORS fields among them) without the
password; on an application's path it is asked ([auth.md](auth.md) 5.1).

```toml
[addresses]
office = ["203.0.113.0/24"]

[[site]]
server_name = ["staging.shop.example"]
app = "wordpress"
root = "/srv/www/staging.shop.example/web"
tls = "auto"

[[site.auth]]
path = "/"                                              # the whole site
users = "/etc/agensio/auth/staging.shop.example.users"
realm = "Shop staging"
skip_for = ["@office"]                                  # the office gets in without a password

[[site.auth]]
path = "/api/health"
match = "exact"
open = true                                             # no password for the monitor
```

The user file is htpasswd's format, so a file made with `htpasswd -B` works as is, with two
optional fields after the hash:

```
anna:$y$j9T$...:expires=2026-10-22:note=Anna, Acme (client review)
dev:$2y$12$...:note=Our developer
old:!                                                   # a locked user
```

From the `expires` date (UTC) the user is refused even with the right password; `note` says
whose login it is, in `--explain`, `site_show` and the log lines. Accepted hashes: yescrypt
(`mkpasswd -m yescrypt`, Debian's default), bcrypt (`htpasswd -B -C 12`), sha512crypt,
sha256crypt, scrypt. Refused at load, with the command to use instead: MD5 (`$apr1$`, `$1$`,
htpasswd's old default), `{SHA}`, `{SSHA}`, `{PLAIN}` and DES. The file belongs to the owner
of the main configuration (root), is not writable by group or others and not readable by
others (`chmod 640`, the server's group may read it), and is read at load and at every
reload. On a WordPress site, a protected `/wp-admin` keeps `admin-ajax.php` and the login
page's own css, js and images open, as the access rules do. A build of agensio without
libxcrypt refuses a configuration with `[[site.auth]]` instead of leaving the paths open.

**Making a user file.** `agensio passwd anna >> /etc/agensio/auth/staging.users` asks for the
password twice at a terminal (or reads one line from stdin) and prints `anna:$y$...` (yescrypt;
`--method bcrypt --cost 12` or `--method sha512` for the others), so no Apache tools are
needed; append `:expires=` and `:note=` by hand.

**What a request meets.** The checks run in this order before any location: `refuse`, the
access rules, then the password. A client in `skip_for` goes on without one. Over plain HTTP
the browser would send the password in clear, so a request that is not on TLS, not from this
host and not forwarded as https by a trusted proxy is never asked: it gets `403` with a page
that says to use https, unless the rule says `plain_http = "allow"`. From a trusted proxy the
proxy's report decides: the request counts as https only with `X-Forwarded-Proto: https`, and
as this host's only when the client it names in `X-Forwarded-For` is; a tunnel or TLS
terminator on this host is loopback itself, which says nothing about the client it relays
(before 0.1.0-alpha.61 its loopback address got every client it relayed asked over plain HTTP).
Otherwise:

- no `Authorization`: `401` with `WWW-Authenticate: Basic realm="...", charset="UTF-8"` and
  `Cache-Control: no-store`; the same page for a malformed, a wrong and an unknown login;
- a login this worker verified in the last five minutes (or until the user's expiry, if that
  comes first): served at once, for the cost of one HMAC;
- any other login: verified on a small pool of threads while the request waits, never on the
  worker's loop; at most eight at a time per worker, `503` with `Retry-After: 1` beyond. An
  unknown user is checked against a real entry of the file (the first usable one), so the
  answer takes the same time and does not tell which users exist, as long as every hash of
  the file is of one method and cost: a user hashed otherwise answers a wrong password in
  another time, and `-t` and health say so (`auth_users_mixed_methods`, naming those users).
  A failure is never remembered.

A changed password takes effect at the next reload; the old one stops working at once, since
what a worker remembers is keyed by the stored hash too.

**What the application and caches see.** PHP gets `REMOTE_USER` and `AUTH_TYPE = Basic`;
`credentials = "pass"` (the default on a site that runs PHP: WordPress's loopback calls need
it) also leaves `Authorization` in, `"strip"` (the default elsewhere) takes it out, so a
proxied application never receives the site's password. A client let in by `skip_for` was never
asked, so its `Authorization` is always taken out, whatever `credentials` says: PHP never sees a
`PHP_AUTH_USER` nobody verified (before 0.1.0-alpha.61 it did on a site that passes
credentials). `forward_user = "X-Remote-User"` on a
proxy sends the verified name in that field, the client's own copy removed first. Every answer
on a protected path is one no shared cache may keep: a file agensio serves carries
`Cache-Control: private` in place of a preset's `public`; an answer of PHP, CGI or a proxied
application has `public`, `s-maxage` and `proxy-revalidate` removed from its `Cache-Control` and
`private` added, its other directives kept (`max-age`, `no-store`), and the fields only CDNs act
on dropped (`CDN-Cache-Control` and every `*-Cache-Control` targeted field, `Surrogate-Control`,
`Edge-Control`: a CDN follows those over `Cache-Control`, RFC 9213 2.2). This holds for a client
let in by `skip_for` too, whose request carries no `Authorization` and so gets no protection from
the cache's own rule for authenticated requests (RFC 9111 3.5).

**Logs.** The access log's user field (`%u`, the third field) is the verified user, `-`
otherwise, never a name a refused request claimed (JSON: `"user"`). Each failed login is one
`warn` line, the client first so a name the client chose cannot pass for another address:
`auth failed: client 198.51.100.4 site shop.example realm "Shop staging" user "anna" (wrong
password) GET /`. The reasons are `wrong password`, `unknown user`, `expired`, `locked user`
and `malformed credentials`; the challenge itself, which every browser meets before it sends
a login, writes nothing. The `agensio-auth` fail2ban jail (section 18, `docs/fail2ban.md` 2c)
counts these lines but `expired`, a right password: ten in ten minutes ban the address for an
hour; it reads the error log, so that must be a file at `warn` (the package's default; health
says `fail2ban_auth_unseen` otherwise). `status` reports `auth_verifications`, the hashes run
since the start.

**A managed site's users.** The control plane keeps one users file per managed site,
`<directory of the main configuration>/auth/<site>.users`: root's, the server's group, `0640`,
in a `0750` directory of root's, written by the provisioning helper through a temporary file
and a rename (a server started without the helper writes its own, under its own account). The
site's account can neither read it nor replace it, and the loader's checks above hold for it.

```sh
agensio ctl site-auth-user-set shop.example anna --generate --expires 2026-10-22 --note 'Anna, Acme' --yes --reason "client review"
agensio ctl site-auth-user-set shop.example bob --prompt --yes --reason "own password"   # asks here, sends only the hash
agensio ctl site-auth-user-set shop.example anna --lock --yes --reason "review over"     # --unlock gives the password back
agensio ctl site-auth-users shop.example                                                 # names, methods, expiry, notes; no hash
agensio ctl site-auth-user-delete shop.example bob --yes --reason "left"
```

A password never travels to the server. `--generate` has the server make one (sixteen
lower-case letters and digits in four groups, `xxxx-xxxx-xxxx-xxxx`, without `0`, `1`, `l` or
`o`: 80 bits, easy to read out) and answer it once; it is kept nowhere and a lost one is
replaced, never recovered. `--prompt` asks on the terminal where `agensio ctl` runs (twice, not
echoed; or one line of stdin), hashes it there with yescrypt and sends the hash. The MCP tools
`site_auth_users`, `site_auth_user_set` and `site_auth_user_delete` do the same for an agent,
which can only generate: it never receives a password the user typed, and the bridge drops a
hash it tries to send. Every call is admin only and audited with the user's name and what
changed, never a password or a hash. When a `[[site.auth]]` rule reads the file, a change
reloads the server, so it applies to the next request, and the last user of the file is kept
(lock it instead). A hand-written site is refused: its rules name their own files, which root
keeps with `agensio passwd`.

**A managed site's rule.** `site_update` with `rules.auth` (section 15) writes the rules into the
site file as `[[site.auth]]` tables reading the site's own users file:

```sh
agensio ctl site-auth-user-set shop.example anna --generate --yes --reason "staging"         # the first user
agensio ctl site-update shop.example --auth / --auth-realm "Shop staging" --auth-skip @office \
    --auth-open /health.html --yes --reason "staging behind a password"
agensio ctl path-check shop.example /cart        # names the rule; auth_note says what a request meets
agensio ctl site-update shop.example --no-auth --yes --reason "goes public"
```

The rule is refused until the site has a user: a rule whose users file is missing or empty
would make the next load refuse the whole configuration, so the answer names the command for
the first user instead. `site-create` refuses `rules.auth` altogether: a site gets its first
user, then its rule. `site_show` lists every rule in force (`auth`, with `from`: `rules`,
`preset:wordpress` or nothing for a hand-written one), its users file, `users_count` and
`usable` (who can log in now); the names are `site-auth-users`'. Deleting the site with its
files moves the users file into the trash with the rest, and a restore brings it back; deleting
it without its files leaves the file, which health then reports, and `site-create` under the
same name warns that it exists.

**What health says.** For every users file a rule reads (hand-written sites too):

| code | severity | when |
|---|---|---|
| `auth_users_unloadable` | error | the next load would refuse the file (gone, a symlink, another owner, a wrong mode, a line it cannot read): a reload keeps the site's running version and a restart does not serve the site (12c; a site in the main file: a reload is refused and a restart does not start the server), while the running one still asks with the users it loaded |
| `auth_no_valid_user` | warn | every user of the file is locked or expired: every login fails and the browser keeps asking |
| `auth_users_expired` | info | users past their `expires` |
| `auth_plain_http` | warn | a rule with `plain_http` on a listener the network reaches |
| `auth_users_orphan` | info | a file under `<config dir>/auth/` no site owns: a site created again under that name with a rule would let its users in |

The reference rows (`agensio ctl reference`, `docs/keys.md`) give every key; `docs/auth.md` is
the whole feature in one place, with its edge cases.


## 20. Response compression: `response_compression`

Off unless asked: agensio spends no CPU on compression until the configuration says so. The key
lives in two places with one name. The main file's `[response_compression]` table holds every
site's defaults and the encoders' tuning. A site's own `response_compression` overrides the
fields it names, and every field it leaves out comes from the main file. Every field applies at a
reload.

One site, with the defaults behind it, which are right for a WordPress, Laravel, Drupal, Rails or
Node site:

```toml
# sites.d/shop.example.toml
[[site]]
server_name = ["shop.example"]
app = "wordpress"
response_compression = true
```

Every site of the host, with one that keeps it off:

```toml
# agensio.toml, the main file
[response_compression]
enabled = true
```

```toml
# sites.d/downloads.example.toml
[[site]]
server_name = ["downloads.example"]
response_compression = false
```

With compression on, a site's answers go out compressed to a browser that takes it, whatever
produced them: cached static files (copies made once, in memory, counted in `cache.max_size` with
the file, on a thread of the server after the file's first request, so the first answers for a
file after a start or a reload, which starts the cache over, go out as the file is and the copy
serves from the request after it is made, some 60 ms per 100 KB later; a `.br` or `.gz` the
site's build left beside a file is served as before and gets no copy), and PHP, proxied and CGI
answers, compressed as they are sent, an application's error pages
included. agensio's own error pages (404, 405, 413, 502...) are sent as they are: a few hundred
bytes each, built once at start, with nothing for a coding to gain.
The coding is the browser's choice among those the site offers (`Accept-Encoding`, with its
q-values): zstd, brotli and gzip are built in, so there is no module to add, and a browser that
lacks one gets the next. What is compressed is decided by the media type (text of every kind,
JavaScript, JSON, XML, SVG, fonts that are not compressed already, wasm; never images, video,
audio or archives), judged without the type's parameters, so `application/json; charset=utf-8`
is JSON; answers under 1 KB are left alone; a 206 is never compressed; `Vary: Accept-Encoding`
goes on every answer that could have been compressed; an answer the application compressed itself
passes through untouched; `Cache-Control: no-transform` from the application is honoured. Every
answer compressed per request carries a random padding of 0 to 32 bytes, drawn per answer, so one
page's compressed length differs from request to request (what an attacker measuring it would need
constant; see BREACH below).

A site that needs more writes the table. In a site file it goes below its `[[site]]` as
`[site.response_compression]`, or inside it on one line as `response_compression = { ... }`:

```toml
[[site]]
server_name = ["store.example"]
app = "wordpress"

[site.response_compression]
enabled = true
exclude_paths = ["/my-account/", "/checkout/"]   # never compressed, whoever asks
```

Every key after `[site.response_compression]` belongs to that table until the next header, so
the site's other keys go above it; the inline form has no such trap. A bare
`[response_compression]` in a site file is refused: it would be the main file's table, every
site's defaults.

| field | main file | site | default | what it does |
|---|---|---|---|---|
| `enabled` | yes | yes | `false` | compression on or off; a site's `response_compression = true` or `false` says this alone |
| `exclude_paths` | no | yes | `[]` | path prefixes never compressed (at most 32, `/`-rooted) |
| `compress_signed_in` | yes | yes | `false` | compress the answers agensio knows to be a signed-in visitor's too (BREACH below) |
| `compress_event_streams` | yes | yes | `false` | compress `text/event-stream` too, each event sent as it comes where the location streams (`buffering = false`) |
| `offload` | yes | yes | `false` | keep `Accept-Encoding` from the application, so agensio compresses |
| `codings` | yes | yes | `["zstd", "br", "gzip"]` | the codings offered and their order; a site's list replaces the main file's |
| `levels` | yes | yes | `{ zstd = 3, br = 3, gzip = 5 }` | the levels of answers compressed per request; a site names the ones it changes |
| `min_size` | yes | yes | `"1KB"` | smaller answers are not compressed |
| `extra_types` | yes | yes | `[]` | media types beyond the built-in list; a site's are added to the main file's |

`agensio -t --explain` prints the main file's table and, for every site, its values with the
fields that are its own named in a comment, the rest marked as the main file's.

**A managed site** (0.1.0-alpha.119) gets its own `response_compression` through `site_create` and
`site_update`, or `agensio ctl site-update NAME --compression on --yes`: the switch, `exclude_paths`,
`compress_signed_in`, `compress_event_streams` (`--compression-events`), `offload`
(`--compression-offload`, both since 0.1.0-alpha.137) and `codings`, each field changed on its own
and the others kept, and `main` (or `null` in the field) handing a field back to the main file;
`--compression-reset` drops them all. The managed file carries only the fields set, so a later
change of the main file still reaches the rest. `levels`, `min_size` and `extra_types` stay the main
file's. `site_show` gives the values in force and, in `own`, the fields the site sets.

**BREACH, and what agensio does about it.** A compressed page that holds a secret (a CSRF token,
an account number) beside something the attacker got reflected into it leaks the secret, byte by
byte, to an attacker who can make the visitor's browser request the page over and over with the
visitor's own credentials. Static files and anonymous pages hold no secret of that kind, so they
are safe to compress. Every web server compresses for every visitor and leaves the rest to the
application (nginx, Apache, lighttpd, Caddy, h2o, LiteSpeed, IIS and the CDNs alike), and the
frameworks answer on their side: Django and Rails mask their CSRF tokens per answer, so a compressed
page leaks nothing useful; Laravel does not, and WordPress's nonces were not examined. agensio does
the same and adds two things no mainstream server does by default:

- *Random padding on every answer compressed per request*: 0 to 32 bytes drawn per answer, in a
  place every decoder skips (gzip's extra field, a zstd skippable frame, a brotli metadata block;
  a draw of 0 leaves the place out, which makes that answer the shortest). An
  attacker averaging the length pays with the square of the spread for every byte he guesses:
  hundreds of times the requests of an unpadded page. Rails' own proxy, Thruster, pads 32 bytes
  by default, Django's GZipMiddleware 100. It raises the attack's cost; it does not remove it.
- *The three credentials agensio itself sees* leave an answer uncompressed while
  `compress_signed_in` is `false`, the default: a path under a `[[site.auth]]` password
  (verified, or let in by `skip_for`), a request admitted by an address rule of `[[site.access]]`
  that refuses others (not `"any"`, not `mode = "report"`), and a browser-replayed `Authorization`
  (Basic, Digest, Negotiate, NTLM; a Bearer token is a script's, never attached by the browser on
  its own, so a JSON API authenticated that way is compressed). These are what the attacker's
  forged request carries without his doing. `compress_signed_in = true` compresses those answers
  too, for a site whose protected pages reflect no input.

An application's own login, its session cookie, is invisible to the server, as to every server:
agensio does not read cookies to decide (a design that counted the presets' cookie names was
dropped on 2026-10-31: Laravel, Rails and Symfony give every anonymous visitor a session, so it
switched compression off for most of those sites, silently). `exclude_paths` names the paths that
stay uncompressed whatever the visitor: on a Laravel or plain PHP site, the pages where a form
token sits beside what a visitor typed (an account page, a checkout, a search with its form). The
application can always opt an answer out with `Cache-Control: no-transform`.

`offload = true` keeps the browser's `Accept-Encoding` from the application (the proxied field,
and `HTTP_ACCEPT_ENCODING` for FastCGI and CGI), so an application that would compress itself
(Next.js, Ghost, Grafana, a PHP site with `zlib.output_compression` on) sends plain answers and
agensio compresses them, padded and under the guard above: the way a gzip-only application's
visitors get zstd or brotli, and the one way the guard reaches a PHP site whose `php.ini` turns
`zlib.output_compression` on. It acts only on a site that compresses. An application's own switch
does the same from its side: Next.js with `compress: false`, Ghost with `compress: false`, Grafana
with `enable_gzip = false`.

`compress_event_streams = true` compresses `text/event-stream` answers too, each event sent as it
comes where the location streams them: `buffering = false` in its `proxy` or `php` table. With
buffering on, the default, the whole stream is collected first and reaches the browser at its end,
compressed or not. It is off by default for a reason of its own: on one long stream every event's compressed
size is visible by itself, so a stream that carries a secret beside something a visitor sent gives
an attacker a sample per event, with no new request and no padding between them (the padding is
drawn once per answer). Turn it on for streams of live prices, metrics or notifications; leave it
off for a chat that echoes what users type next to a token. An event stream gets an encoder sized
for a stream held open: 386 KB with zstd 3, 872 KB with brotli 3, 86 KB with gzip, against 2.1 MB,
1.3 MB and 326 KB for a large answer.

The tuning applies to every site that compresses, and a site may set its own:

```toml
[response_compression]
codings     = ["zstd", "br", "gzip"]          # offered; the order decides when the browser accepts several equally
levels      = { zstd = 3, br = 3, gzip = 5 }  # for answers compressed per request
min_size    = "1KB"                           # smaller answers go uncompressed
extra_types = ["application/x-ndjson"]        # media types beyond the built-in list (every +json and +xml is in it)
```

The order matters only when a browser takes several codings equally, which Chrome and Firefox
do (`gzip, deflate, br, zstd`). zstd first is the default because it costs a quarter of brotli's
CPU for 1 to 8 % more bytes on HTML and 83 % of browsers take it; brotli serves the rest. A site
behind Cloudflare, CloudFront or Fastly does better with `codings = ["br", "zstd", "gzip"]` of
its own: those ask the origin for brotli and pass it on to visitors, and ignore an origin's zstd.
A site's `codings` also decides the copies of its cached files: brotli and gzip copies of the ones
it lists (no zstd copy is made: brotli 11 is smaller, and every browser that takes zstd takes
brotli), the `.br` and `.gz` files beside its files likewise when the list is written (in the main
file or on the site: the default list leaves out what the build cannot produce, not what the site's
build left on disk), and between those two brotli wins a tie whatever the order, since both are made
once at their best level. The levels are for answers
compressed per request (measured on real pages, `bench/results/compression-levels-20261030.md`:
zstd 3 within 2 % of gzip 6's size at eight times its speed; brotli 3 within 2 % of zstd 3's bytes
at a third of its speed, brotli 4 five to seven per cent smaller on HTML at 1.5 to 1.8 times
brotli 3's cost; gzip 5 gzip 6's size at 0.6 of its cost, gzip 1 seven to seventeen per cent larger
at half of gzip 5's). A buffered answer up to 256 KB is compressed whole on the worker (a CMS home
page is 70 to 82 KB; at 256 KB zstd 3 holds the worker 0.35 ms, gzip 5 2 ms) and goes out with its
exact length. A larger one, one spilled to a temporary file and a streamed one (`buffering =
false`, or an application streaming its answer) are compressed as they are sent, 64 KB of the
application's bytes at a time, framed chunked on HTTP/1.1 and in DATA frames on HTTP/2 (0.1.0-alpha.137):
while the application keeps sending, nothing is flushed, which gives the best ratio; when it pauses
(its `flush()`, the end of an event, a slow query), everything compressed so far goes to the client
at once, so a page that streams its head first still shows it first. A streamed answer is measured
against `min_size` only by the length it declares, as nginx's `gzip_min_length`. An HTTP/1.0 client
(no chunked framing) and an HTTP/3 one (no streamed body yet) get those answers as they came, with
`Vary`. A large answer gives the worker back after every 256 KB it compressed, so it holds the
worker no longer than a whole-compressed one (about 0.5 ms with zstd, 2 ms with gzip) and the
worker's other connections are served between its pieces. Each worker gives the encoders of such
answers at most 32 MB (about fifteen large answers at once with zstd 3, eighty event streams);
past it an answer goes as it came, with `Vary`, never refused, and `status`'s `compression` block
counts it (`streams_over_budget`, beside `streams_active` and `streams_started`): a site that sends
many large answers at once and shows the count growing does better with lower `levels`. The copies of cached files are
made once at brotli 11 and gzip 9, which is not a setting, and the encoders' windows are fixed for
the memory each stream takes. A coding the build lacks (`libzstd`, `libbrotli` missing at build
time) is refused by `agensio -t` when a list names it, naming the package; the default list holds
the codings the build has.

A change to any of these applies at a reload. A reload gives every reloaded site new cache
entries, so the copies of its files are made again under the new values; a site held back at a
reload (its file did not load, section 12c) keeps its last good version, compression included.

To check from outside, `curl -sS -o /dev/null -D - -H 'Accept-Encoding: zstd, br, gzip'
https://shop.example/` shows `Content-Encoding` and `Vary`. `path_check` will name the coding a
path gets, or the one reason none applies, with step 7 of `docs/design-compression.md` 11. The
design, with the research behind every default, is `docs/design-compression.md`.
